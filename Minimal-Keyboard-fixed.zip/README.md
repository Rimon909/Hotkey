# Minimal Keyboard

A minimalist Android keyboard (Kotlin, `InputMethodService`, min API 26) with a signature
opening animation, original synthetic typewriter sounds and fast text editing.

## Build with GitHub Actions
1. Create a repo on GitHub and upload `Minimal-Keyboard.zip` (the files sit at the zip root, so they land at the repo root: `app/`, `settings.gradle.kts`, ...).
2. In the repo choose **Add file > Create new file**, type `.github/workflows/build.yml` as the name (typing the slashes creates the folders), paste the contents of the separate `build.yml` file, and commit.
3. The build starts automatically on that commit. Open **Actions > Build Minimal Keyboard**; you can also start it with *Run workflow*.
4. When it finishes, download **Minimal-Keyboard-debug-apk** from the run's *Artifacts* section and unzip it.

> `gradle-wrapper.jar` is a binary that could not be bundled from the environment this project was
> generated in. The workflow detects this and generates the wrapper itself, so CI needs nothing from
> you. For local builds, run once: `gradle wrapper --gradle-version 8.9` (then `./gradlew assembleDebug`).

## Install
1. Copy `app-debug.apk` to the phone and open it (allow "install unknown apps" when asked).
2. Open **Minimal Keyboard**, tap **Enable keyboard**, switch it on, then **Choose keyboard**.

## Features
**Signature**
- **Card-shuffle opening** (0.96 s): keys wait as two loose piles in the bottom corners, leave them alternately like a riffle shuffle in a scrambled order and arc into place, with a card-riffle sound. Plays only when the keyboard appears; keys work immediately.
- **Typewriter keycaps** with metal rim, dished face and engraved typewriter lettering; every strike leaves a **brass ink mark**.
- **Paper strip**: a typewriter paper window above the toolbar shows what you just typed; the newest letter strikes in brass. Never reads password fields.
- **Select pad**: hold the space bar 0.5 s. The bar grows into a wide pad (keys shrink and blur behind it); slide sideways to select characters, up/down for lines; double-tap copies, flick down closes.
- **Font styles**: 16 Unicode styles (bold, italic, script, fraktur, outline, typewriter, circled, small caps, wide, strike, underline ...). The keys themselves re-letter, and what you type is styled in any app.
- **Text alchemy**: one tap transforms the selection (or last word): UPPER, lower, Title, Sentence, mOcK, reverse, snake_case, kebab-case, camelCase, tidy spaces, quotes, parentheses.
- **Expressions panel**: ~480 emoji in 7 categories with recents, plus a **kaomoji** tab (`¯\_(ツ)_/¯` and friends); scroll with momentum.
- **Margin bell**: like a real typewriter, a bell rings as your line gets long (can be turned off).
- **Typing rhythm**: key-sound pitch follows your typing speed, so fast bursts sound brighter.
- **4 sound packs** (Typewriter, Clicky, Soft, Marimba) plus interface sounds, all synthesised (`tools/generate_sounds.py`); variant, pitch and level vary on every press.
- **Snippets**: your own phrases (email, phone, address ...) one tap away.
- **Typewriter odometer**: lifetime key-strike count (a number only, never text).

**Everyday**
- Undo / redo, select all, copy, cut, paste, clipboard history (memory only) in a swipeable toolbar.
- Layouts: QWERTY, QWERTZ, AZERTY, Colemak; one-handed mode (left/right); numbers and symbols pages.
- Dot/comma long-press (0.23 s) opens a grid of useful symbols above your thumb; letters give accents and digits.
- Space-bar cursor slide, accelerating backspace (then by word), shift / caps lock, double-space period, auto-capitalise.
- Themes: System, Ivory, Graphite, Ribbon, Terminal, Midnight; three key heights.
- Independent sound/haptic controls and a master switch that disables every effect.

## Notes and limits
- No internet permission, no analytics, no text logging. Clipboard history is memory-only and skips items flagged sensitive.
- Cursor and selection use `InputConnection.setSelection`; editors that reject it fall back to arrow keys.
- **Swipe typing is not included**: it needs a dictionary/language model to be useful, and a placeholder would be misleading.
- Font styles use Unicode look-alike characters: some apps or fonts may not draw every style.
- Undo/redo asks the app to undo; apps that do not support it ignore it.
- Emoji are limited to Unicode 11 so they draw on every Android 8+ phone.
- Gesture-navigation bottom insets rely on the framework for target SDK 34; a hook for edge-to-edge (target 35+) is included. Not tested on physical devices.
- The select-pad "blur" is simulated (soft offset copies of the shrunken keys) so it works on every Android version.
- Line selection uses Shift+Up/Down key events; a few editors ignore them.
- English (US) layout only.
