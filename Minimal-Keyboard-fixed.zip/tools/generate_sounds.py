#!/usr/bin/env python3
"""
Generates all original synthetic sounds (4 key-sound packs + interface sounds) in app/src/main/res/raw/.
Everything is synthesised from noise bursts, decaying sine "thunks" and inharmonic metallic
partials - no samples, nothing copyrighted. Requires only numpy:  python3 tools/generate_sounds.py
"""
import math
import os
import wave

import numpy as np

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "res", "raw")


def lp(x, fc):
    a = 1.0 - math.exp(-2.0 * math.pi * fc / SR)
    y = np.empty_like(x)
    acc = 0.0
    for i in range(len(x)):
        acc += a * (x[i] - acc)
        y[i] = acc
    return y


def hp(x, fc):
    return x - lp(x, fc)


def burst(rng, n, tau, hp_fc, lp_fc):
    t = np.arange(n) / SR
    noise = hp(lp(rng.standard_normal(n), lp_fc), hp_fc)
    return noise * np.exp(-t / tau)


def thunk(n, f_start, f_end, tau):
    t = np.arange(n) / SR
    f = f_end + (f_start - f_end) * np.exp(-t / 0.018)
    phase = 2.0 * math.pi * np.cumsum(f) / SR
    return np.sin(phase) * np.exp(-t / tau)


def metal(n, freqs, amps, tau):
    t = np.arange(n) / SR
    out = np.zeros(n)
    for i, (f, a) in enumerate(zip(freqs, amps)):
        out += a * np.sin(2.0 * math.pi * f * t) * np.exp(-t / (tau / (1.0 + 0.35 * i)))
    return out


def add_at(buf, sig, at_s):
    off = int(SR * at_s)
    if off >= len(buf):
        return
    m = min(len(sig), len(buf) - off)
    buf[off:off + m] += sig[:m]


def finish(sig, peak=0.85):
    fade = int(SR * 0.008)
    sig[-fade:] *= np.linspace(1.0, 0.0, fade)
    sig = sig / (np.max(np.abs(sig)) + 1e-9) * peak
    return sig


def write(name, sig):
    path = os.path.join(OUT, name + ".wav")
    pcm = (np.clip(sig, -1, 1) * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    print("wrote", name, "%.0f ms" % (1000.0 * len(sig) / SR))


def letter(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.14)
    s = np.zeros(n)
    s += 1.0 * burst(rng, n, 0.0022, 1400, 7000)
    s += 0.75 * thunk(n, rng.uniform(165, 215), rng.uniform(105, 135), 0.028)
    freqs = [rng.uniform(2200, 2500), rng.uniform(3600, 4000), rng.uniform(5000, 5600)]
    s += 0.22 * metal(n, freqs, [1.0, 0.6, 0.35], 0.014)
    add_at(s, 0.35 * burst(rng, n, 0.0018, 900, 5000), rng.uniform(0.009, 0.015))
    return finish(s)


def space(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.20)
    s = np.zeros(n)
    s += 0.6 * burst(rng, n, 0.004, 300, 3500)
    s += 1.0 * thunk(n, rng.uniform(100, 125), 68, 0.06)
    s += 0.08 * metal(n, [rng.uniform(1700, 1900), rng.uniform(2900, 3200)], [1.0, 0.5], 0.02)
    add_at(s, 0.25 * burst(rng, n, 0.0015, 800, 4500), 0.018)
    add_at(s, 0.2 * burst(rng, n, 0.0015, 800, 4500), 0.034)
    return finish(s)


def back(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.15)
    s = np.zeros(n)
    s += 0.8 * burst(rng, n, 0.002, 1200, 6500)
    s += 0.45 * thunk(n, rng.uniform(200, 235), 150, 0.02)
    second = 0.6 * burst(rng, n, 0.002, 1500, 7000) + 0.4 * thunk(n, rng.uniform(250, 285), 190, 0.018)
    add_at(s, second, rng.uniform(0.032, 0.040))
    s += 0.12 * metal(n, [rng.uniform(2800, 3200), rng.uniform(4300, 4800)], [1.0, 0.6], 0.012)
    return finish(s)


def enter(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.5)
    s = np.zeros(n)
    s += 0.8 * burst(rng, n, 0.004, 400, 5000)
    s += 1.0 * thunk(n, 95, 60, 0.08)
    t = 0.05
    gap = 0.018
    while t < 0.22:
        add_at(s, 0.3 * burst(rng, n, 0.0012, 1800, 7500), t)
        t += gap
        gap = max(0.009, gap * 0.9)
    add_at(s, 0.18 * metal(n, [2600, 3900, 5230], [1.0, 0.55, 0.3], 0.16), 0.24)
    return finish(s)


def mod(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.09)
    s = np.zeros(n)
    s += 0.8 * burst(rng, n, 0.003, 500, 3000)
    s += 0.55 * thunk(n, rng.uniform(125, 145), 100, 0.02)
    s += 0.06 * metal(n, [rng.uniform(1400, 1600)], [1.0], 0.01)
    return finish(s)


# ------------------------------------------------------------------ mechanical (clicky switch)
def mech_letter(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.12)
    s = np.zeros(n)
    s += 1.0 * burst(rng, n, 0.0012, 2500, 9000)
    s += 0.25 * metal(n, [rng.uniform(4000, 4300), rng.uniform(5500, 5900)], [1.0, 0.6], 0.010)
    add_at(s, 0.8 * burst(rng, n, 0.003, 800, 4500) + 0.6 * thunk(n, rng.uniform(200, 230), 150, 0.018), rng.uniform(0.010, 0.015))
    return finish(s)


def mech_space(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.17)
    s = np.zeros(n)
    s += 0.9 * burst(rng, n, 0.0015, 1800, 8000)
    s += 0.9 * thunk(n, rng.uniform(125, 145), 88, 0.05)
    add_at(s, 0.5 * burst(rng, n, 0.003, 600, 4000), 0.016)
    add_at(s, 0.2 * metal(n, [2300, 3300], [1.0, 0.5], 0.03), 0.004)
    return finish(s)


def mech_back(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.12)
    s = np.zeros(n)
    s += 0.9 * burst(rng, n, 0.0012, 2800, 9000)
    add_at(s, 0.7 * burst(rng, n, 0.0012, 3000, 9500) + 0.3 * thunk(n, 240, 180, 0.012), rng.uniform(0.026, 0.034))
    return finish(s)


def mech_enter(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.26)
    s = np.zeros(n)
    s += 1.0 * burst(rng, n, 0.002, 1500, 8000)
    s += 1.0 * thunk(n, 110, 70, 0.07)
    add_at(s, 0.3 * metal(n, [2900, 4200], [1.0, 0.6], 0.06), 0.002)
    add_at(s, 0.6 * burst(rng, n, 0.004, 600, 4500), 0.02)
    return finish(s)


def mech_mod(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.07)
    s = np.zeros(n)
    s += 0.8 * burst(rng, n, 0.0015, 1800, 6000)
    s += 0.35 * thunk(n, rng.uniform(170, 190), 130, 0.014)
    return finish(s)


# ------------------------------------------------------------------ soft (rounded thock)
def soft_letter(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.13)
    s = np.zeros(n)
    s += 1.0 * thunk(n, rng.uniform(180, 205), rng.uniform(110, 125), 0.032)
    s += 0.5 * burst(rng, n, 0.004, 250, 2200)
    return finish(s, 0.8)


def soft_space(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.2)
    s = np.zeros(n)
    s += 1.0 * thunk(n, rng.uniform(115, 130), 78, 0.065)
    s += 0.4 * burst(rng, n, 0.006, 200, 1800)
    return finish(s, 0.8)


def soft_back(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.15)
    s = np.zeros(n)
    s += 0.8 * thunk(n, 200, 130, 0.025)
    add_at(s, 0.6 * thunk(n, 230, 150, 0.022), rng.uniform(0.04, 0.05))
    s += 0.3 * burst(rng, n, 0.004, 250, 2200)
    return finish(s, 0.8)


def soft_enter(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.3)
    s = np.zeros(n)
    s += 1.0 * thunk(n, 105, 62, 0.1)
    s += 0.5 * burst(rng, n, 0.008, 200, 1800)
    return finish(s, 0.8)


def soft_mod(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.08)
    s = np.zeros(n)
    s += 0.9 * thunk(n, rng.uniform(150, 165), 110, 0.02)
    s += 0.3 * burst(rng, n, 0.003, 250, 1800)
    return finish(s, 0.7)


# ------------------------------------------------------------------ marimba (musical taps)
def note(n, f, tau, bright=0.35):
    t = np.arange(n) / SR
    out = np.sin(2 * math.pi * f * t) * np.exp(-t / tau)
    out += bright * np.sin(2 * math.pi * f * 3.97 * t) * np.exp(-t / (tau * 0.35))
    out += 0.12 * np.sin(2 * math.pi * f * 9.2 * t) * np.exp(-t / (tau * 0.12))
    return out


def mari_letter(seed, f):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.24)
    s = note(n, f, 0.09)
    s += 0.25 * burst(rng, n, 0.001, 1500, 6000)
    return finish(s, 0.8)


def mari_space(seed, f):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.34)
    s = note(n, f, 0.16, 0.25)
    s += 0.3 * burst(rng, n, 0.002, 400, 3000)
    return finish(s, 0.8)


def mari_back(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.18)
    t = np.arange(n) / SR
    f = 330 + (700 - 330) * np.exp(-t / 0.03)
    s = np.sin(2 * math.pi * np.cumsum(f) / SR) * np.exp(-t / 0.05)
    s += 0.2 * burst(rng, n, 0.001, 1500, 5000)
    return finish(s, 0.75)


def mari_enter(seed):
    n = int(SR * 0.5)
    s = note(n, 523.25, 0.22) + 0.8 * note(n, 659.25, 0.22) + 0.7 * note(n, 783.99, 0.22)
    return finish(s, 0.8)


def mari_mod(seed, f):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.12)
    s = note(n, f, 0.04, 0.2)
    s += 0.2 * burst(rng, n, 0.001, 1500, 5000)
    return finish(s, 0.7)


# ------------------------------------------------------------------ shared interface sounds
def ui_pop(seed, f0, f1):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.09)
    t = np.arange(n) / SR
    f = f0 + (f1 - f0) * (1 - np.exp(-t / 0.018))
    s = np.sin(2 * math.pi * np.cumsum(f) / SR) * np.exp(-t / 0.028)
    s += 0.25 * burst(rng, n, 0.0008, 1500, 6000)
    return finish(s, 0.75)


def ui_swoosh(opening):
    rng = np.random.default_rng(77 if opening else 78)
    n = int(SR * 0.2)
    t = np.arange(n) / SR
    noise = hp(lp(rng.standard_normal(n), 5000 if opening else 3200), 500)
    x = t / 0.2
    env = np.sin(math.pi * np.clip(x, 0, 1)) ** 2
    if opening:
        env = np.where(x < 0.6, np.sin(math.pi / 2 * x / 0.6) ** 2, np.cos(math.pi / 2 * (x - 0.6) / 0.4) ** 2)
    else:
        env = np.where(x < 0.25, np.sin(math.pi / 2 * x / 0.25) ** 2, np.cos(math.pi / 2 * (x - 0.25) / 0.75) ** 2)
    s = noise * env
    s += 0.35 * thunk(n, 160, 110, 0.03) * (1.0 if not opening else 0.4)
    return finish(s, 0.7)


def ui_bell():
    rng = np.random.default_rng(91)
    n = int(SR * 0.9)
    s = np.zeros(n)
    s += 0.35 * burst(rng, n, 0.001, 2000, 9000)
    s += 1.0 * metal(n, [2093.0, 3140.7, 4186.0, 5350.0], [1.0, 0.55, 0.38, 0.2], 0.4)
    return finish(s, 0.75)


def ui_riffle():
    rng = np.random.default_rng(55)
    n = int(SR * 0.98)
    s = np.zeros(n)
    t = 0.0
    gap = 0.046
    k = 0
    while t < 0.80:
        tick = burst(rng, int(SR * 0.02), 0.0009, rng.uniform(1800, 2600), rng.uniform(6500, 9000))
        add_at(s, tick * rng.uniform(0.55, 1.0), t)
        t += gap
        k += 1
        gap = max(0.012, gap * 0.93)
    add_at(s, 0.7 * thunk(int(SR * 0.12), 230, 120, 0.03) + 0.5 * burst(rng, int(SR * 0.12), 0.003, 400, 5000), 0.80)
    return finish(s, 0.8)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    # Typewriter (default)
    for i in (1, 2, 3):
        write("key_letter_%d" % i, letter(100 + i))
    for i in (1, 2):
        write("key_space_%d" % i, space(200 + i))
        write("key_back_%d" % i, back(300 + i))
        write("key_mod_%d" % i, mod(500 + i))
    write("key_enter_1", enter(400))
    # Mechanical
    for i in (1, 2, 3):
        write("mech_letter_%d" % i, mech_letter(610 + i))
    for i in (1, 2):
        write("mech_space_%d" % i, mech_space(620 + i))
        write("mech_back_%d" % i, mech_back(630 + i))
        write("mech_mod_%d" % i, mech_mod(640 + i))
    write("mech_enter_1", mech_enter(650))
    # Soft
    for i in (1, 2, 3):
        write("soft_letter_%d" % i, soft_letter(710 + i))
    for i in (1, 2):
        write("soft_space_%d" % i, soft_space(720 + i))
        write("soft_back_%d" % i, soft_back(730 + i))
        write("soft_mod_%d" % i, soft_mod(740 + i))
    write("soft_enter_1", soft_enter(750))
    # Marimba
    for i, f in zip((1, 2, 3), (523.25, 659.25, 783.99)):
        write("mari_letter_%d" % i, mari_letter(810 + i, f))
    write("mari_space_1", mari_space(821, 261.63))
    write("mari_space_2", mari_space(822, 329.63))
    write("mari_back_1", mari_back(831))
    write("mari_back_2", mari_back(832))
    write("mari_mod_1", mari_mod(841, 587.33))
    write("mari_mod_2", mari_mod(842, 880.0))
    write("mari_enter_1", mari_enter(850))
    # Shared interface sounds
    write("ui_pop_1", ui_pop(901, 380, 820))
    write("ui_pop_2", ui_pop(902, 440, 960))
    write("ui_open_1", ui_swoosh(True))
    write("ui_close_1", ui_swoosh(False))
    write("ui_bell_1", ui_bell())
    write("ui_riffle_1", ui_riffle())
