package com.minimalkeyboard

import org.junit.Assert.assertEquals
import org.junit.Test

class TextAlchemyTest {

    private fun run(op: AlchemyOp, s: String) = TextAlchemy.apply(op, s)

    @Test
    fun caseOperations() {
        assertEquals("ABC", run(AlchemyOp.UPPER, "abc"))
        assertEquals("abc", run(AlchemyOp.LOWER, "ABC"))
        assertEquals("Hello World Foo-bar", run(AlchemyOp.TITLE, "hello wORLD foo-bar"))
        assertEquals("Hello. How are you? Fine", run(AlchemyOp.SENTENCE, "hELLO. how ARE you? fine"))
        assertEquals("hElLo", run(AlchemyOp.MOCK, "hello"))
    }

    @Test
    fun reverseAndTidy() {
        assertEquals("cba", run(AlchemyOp.REVERSE, "abc"))
        assertEquals("a b c", run(AlchemyOp.TIDY, "  a   b \n c "))
    }

    @Test
    fun identifierStyles() {
        assertEquals("hello_world_foo", run(AlchemyOp.SNAKE, "Hello World-Foo"))
        assertEquals("hello-world-foo", run(AlchemyOp.KEBAB, "Hello World-Foo"))
        assertEquals("helloBigWorld", run(AlchemyOp.CAMEL, "hello big world"))
    }

    @Test
    fun wrappers() {
        assertEquals("\u201Ca\u201D", run(AlchemyOp.QUOTE, "a"))
        assertEquals("(a)", run(AlchemyOp.PARENS, "a"))
    }

    @Test
    fun twelveOperations() {
        assertEquals(12, AlchemyOp.values().size)
    }
}
