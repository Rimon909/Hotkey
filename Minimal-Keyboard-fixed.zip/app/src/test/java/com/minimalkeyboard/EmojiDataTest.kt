package com.minimalkeyboard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EmojiDataTest {

    @Test
    fun categoriesAreWellFormed() {
        val cats = EmojiData.categories
        assertEquals(9, cats.size)
        assertTrue(cats[0].items.isEmpty()) // "Recent" is filled at runtime
        for (c in cats.drop(1)) {
            assertTrue(c.name, c.items.size >= 18)
            assertTrue(c.name, c.items.none { it.isBlank() })
        }
    }

    @Test
    fun onlyKaomojiIsWide() {
        assertEquals(listOf("Kaomoji"), EmojiData.categories.filter { it.wide }.map { it.name })
    }
}
