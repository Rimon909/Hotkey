package com.minimalkeyboard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FontStylesTest {

    private fun cp(text: String, style: FontStyle): Int = FontStyles.apply(text, style).codePointAt(0)

    @Test
    fun normalIsUnchanged() {
        assertEquals("Hello 123", FontStyles.apply("Hello 123", FontStyle.NORMAL))
    }

    @Test
    fun boldMapsToMathematicalBold() {
        assertEquals(0x1D400, cp("A", FontStyle.BOLD))
        assertEquals(0x1D41A, cp("a", FontStyle.BOLD))
        assertEquals(0x1D7CE + 7, cp("7", FontStyle.BOLD))
    }

    @Test
    fun italicHasTheSpecialSmallH() {
        assertEquals(0x210E, cp("h", FontStyle.ITALIC))
        assertEquals(0x1D44E, cp("a", FontStyle.ITALIC))
    }

    @Test
    fun scriptFrakturAndDoubleStruckExceptions() {
        assertEquals(0x212C, cp("B", FontStyle.SCRIPT))
        assertEquals(0x212F, cp("e", FontStyle.SCRIPT))
        assertEquals(0x1D4B6, cp("a", FontStyle.SCRIPT))
        assertEquals(0x212D, cp("C", FontStyle.FRAKTUR))
        assertEquals(0x1D51E, cp("a", FontStyle.FRAKTUR))
        assertEquals(0x211D, cp("R", FontStyle.DOUBLE_STRUCK))
        assertEquals(0x1D7D9, cp("1", FontStyle.DOUBLE_STRUCK))
    }

    @Test
    fun sansAndMono() {
        assertEquals(0x1D5A0, cp("A", FontStyle.SANS))
        assertEquals(0x1D5D4, cp("A", FontStyle.SANS_BOLD))
        assertEquals(0x1D68A, cp("a", FontStyle.MONO))
    }

    @Test
    fun circledFullwidthAndSmallCaps() {
        assertEquals(0x24D0, cp("a", FontStyle.CIRCLED))
        assertEquals(0x24EA, cp("0", FontStyle.CIRCLED))
        assertEquals(0x2460, cp("1", FontStyle.CIRCLED))
        assertEquals(0xFF21, cp("A", FontStyle.FULLWIDTH))
        assertEquals(0xFF01, cp("!", FontStyle.FULLWIDTH))
        assertEquals(0x3000, cp(" ", FontStyle.FULLWIDTH))
        assertEquals(0x1D00, cp("a", FontStyle.SMALL_CAPS))
        assertEquals(0x1D00, cp("A", FontStyle.SMALL_CAPS))
        assertEquals('x'.code, cp("x", FontStyle.SMALL_CAPS))
    }

    @Test
    fun strikeAndUnderlineAddCombiningMarks() {
        assertEquals("a\u0336b\u0336", FontStyles.apply("ab", FontStyle.STRIKE))
        assertEquals("a\u0336 b\u0336", FontStyles.apply("a b", FontStyle.STRIKE))
        assertEquals("a\u0332", FontStyles.apply("a", FontStyle.UNDERLINE))
    }

    @Test
    fun nonAsciiPassesThrough() {
        assertEquals("é", FontStyles.apply("é", FontStyle.BOLD))
    }

    @Test
    fun everyStyleTransformsLetters() {
        for (style in FontStyle.values()) {
            if (style == FontStyle.NORMAL) continue
            val out = FontStyles.apply("Hello", style)
            assertTrue(style.name, out != "Hello")
        }
    }
}
