package com.minimalkeyboard

/** One-tap transformations applied to the selected text (or the word before the cursor). */
enum class AlchemyOp(val title: String, val sample: String) {
    UPPER("Upper", "ABC"),
    LOWER("Lower", "abc"),
    TITLE("Title", "Abc"),
    SENTENCE("Sentence", "Abc."),
    MOCK("Mock", "aBcD"),
    REVERSE("Reverse", "cba"),
    SNAKE("snake", "a_b"),
    KEBAB("kebab", "a-b"),
    CAMEL("camel", "aB"),
    TIDY("Tidy", "a b"),
    QUOTE("Quote", "\u201Ca\u201D"),
    PARENS("Parens", "(a)")
}

object TextAlchemy {

    private val SEPARATORS = Regex("[^\\p{L}\\p{N}]+")

    fun apply(op: AlchemyOp, s: String): String = when (op) {
        AlchemyOp.UPPER -> s.uppercase()
        AlchemyOp.LOWER -> s.lowercase()
        AlchemyOp.TITLE -> title(s)
        AlchemyOp.SENTENCE -> sentence(s)
        AlchemyOp.MOCK -> mock(s)
        AlchemyOp.REVERSE -> StringBuilder(s).reverse().toString()
        AlchemyOp.SNAKE -> words(s).joinToString("_") { it.lowercase() }
        AlchemyOp.KEBAB -> words(s).joinToString("-") { it.lowercase() }
        AlchemyOp.CAMEL -> camel(s)
        AlchemyOp.TIDY -> s.trim().replace(Regex("\\s+"), " ")
        AlchemyOp.QUOTE -> "\u201C" + s + "\u201D"
        AlchemyOp.PARENS -> "($s)"
    }

    private fun words(s: String): List<String> = s.split(SEPARATORS).filter { it.isNotEmpty() }

    private fun title(s: String): String {
        val sb = StringBuilder(s.length)
        var startOfWord = true
        for (c in s) {
            if (c.isLetterOrDigit()) {
                sb.append(if (startOfWord) c.uppercaseChar() else c.lowercaseChar())
                startOfWord = false
            } else {
                sb.append(c)
                startOfWord = c.isWhitespace()
            }
        }
        return sb.toString()
    }

    private fun sentence(s: String): String {
        val sb = StringBuilder(s.length)
        var capNext = true
        for (c in s) {
            if (c.isLetter()) {
                sb.append(if (capNext) c.uppercaseChar() else c.lowercaseChar())
                capNext = false
            } else {
                sb.append(c)
                if (c == '.' || c == '!' || c == '?' || c == '\n') capNext = true
            }
        }
        return sb.toString()
    }

    private fun mock(s: String): String {
        val sb = StringBuilder(s.length)
        var upper = false
        for (c in s) {
            if (c.isLetter()) {
                sb.append(if (upper) c.uppercaseChar() else c.lowercaseChar())
                upper = !upper
            } else {
                sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun camel(s: String): String {
        val parts = words(s)
        val sb = StringBuilder()
        for ((i, w) in parts.withIndex()) {
            val lower = w.lowercase()
            if (i == 0) sb.append(lower)
            else sb.append(lower.substring(0, 1).uppercase()).append(lower.substring(1))
        }
        return sb.toString()
    }
}
