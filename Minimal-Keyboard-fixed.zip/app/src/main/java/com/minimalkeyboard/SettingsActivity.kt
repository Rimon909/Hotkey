package com.minimalkeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Setup + preferences screen, built in code to stay dependency-free. */
class SettingsActivity : Activity() {

    private lateinit var store: SharedPreferences
    private lateinit var pal: Palette
    private lateinit var statusView: TextView
    private lateinit var odometerView: TextView
    private val effectRows = ArrayList<View>()

    private val density: Float get() = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = KeyboardPrefs.shared(this)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        pal = if (night) Palette.DARK else Palette.LIGHT
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        if (!night) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        setContentView(buildUi())
        refreshEnabled()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        val n = store.getLong(KeyboardPrefs.K_ODOMETER, 0L)
        odometerView.text = java.text.NumberFormat.getInstance().format(n)
    }

    // ------------------------------------------------------------ UI

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(40))
        }
        root.addView(label("Minimal Keyboard", 30f, pal.text, true))
        root.addView(label("Cinematic typing. Typewriter sound. Nothing else.", 14f, pal.textDim, false).apply {
            setPadding(0, dp(4), 0, dp(8))
        })

        // --- setup
        statusView = label("", 15f, pal.text, true)
        root.addView(
            card(
                sectionTitle("Set up"),
                statusView,
                button("Enable keyboard", true) {
                    startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
                },
                button("Choose keyboard", false) {
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
                },
                EditText(this).apply {
                    hint = "Tap here and type to try the keyboard"
                    setHintTextColor(pal.textDim)
                    setTextColor(pal.text)
                    minLines = 3
                    gravity = Gravity.TOP
                    inputType = InputType.TYPE_CLASS_TEXT or
                        InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                        InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                    setPadding(dp(14), dp(12), dp(14), dp(12))
                    background = GradientDrawable().apply {
                        setColor(pal.keyFunc)
                        cornerRadius = dp(12).toFloat()
                    }
                    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
                }
            )
        )

        // --- appearance
        root.addView(
            card(
                sectionTitle("Appearance"),
                segmentRow("Theme", KeyboardPrefs.K_THEME, Palette.THEME_NAMES, KeyboardPrefs.THEME_SYSTEM, 11.5f),
                segmentRow("Layout", KeyboardPrefs.K_LAYOUT, listOf("QWERTY", "QWERTZ", "AZERTY", "Colemak"), 0, 13f),
                segmentRow("Key height", KeyboardPrefs.K_HEIGHT, listOf("Compact", "Normal", "Tall"), KeyboardPrefs.HEIGHT_NORMAL),
                switchRow("Toolbar", "Undo, redo, emoji, fonts, tools (swipe it sideways)", KeyboardPrefs.K_TOOLBAR, true, false),
                switchRow("Paper strip", "A typewriter paper window showing what you just typed", KeyboardPrefs.K_PAPER, true, false)
            )
        )

        // --- typing
        root.addView(
            card(
                sectionTitle("Typing"),
                switchRow("Auto-capitalise", "Capital letter at the start of sentences", KeyboardPrefs.K_AUTOCAP, true, false),
                switchRow("Double space for period", null, KeyboardPrefs.K_DOUBLE_SPACE, true, false),
                switchRow("Long-press alternates", "Accents, digits and punctuation", KeyboardPrefs.K_LONG_PRESS, true, false),
                seekRow("Space-bar cursor speed", KeyboardPrefs.K_SENSITIVITY, 1, 5, 3, { v -> "$v / 5" }, false)
            )
        )

        // --- effects
        root.addView(
            card(
                sectionTitle("Effects"),
                switchRow("Typing effects", "Master switch: turn off to disable all sound, haptics and animation", KeyboardPrefs.K_EFFECTS, true, false),
                switchRow("Opening animation", "Keys shuffle in like a deck of cards", KeyboardPrefs.K_OPENING, true, true),
                switchRow("Key press mark", "A brass ink ripple where you strike a key", KeyboardPrefs.K_PRESS_MARK, true, true),
                switchRow("Key sounds", null, KeyboardPrefs.K_SOUND, true, true),
                segmentRow("Sound pack", KeyboardPrefs.K_SOUND_PACK, listOf("Typewriter", "Clicky", "Soft", "Marimba"), 0, 12.5f, true),
                switchRow("Margin bell", "Rings as your line gets long, like a real typewriter", KeyboardPrefs.K_BELL, true, true),
                switchRow("Shuffle sound", "A card riffle when the keyboard opens", KeyboardPrefs.K_SHUFFLE_SOUND, true, true),
                seekRow("Volume", KeyboardPrefs.K_SOUND_VOLUME, 0, 100, 70, { v -> "$v%" }, true),
                switchRow("Mute when phone is silent", null, KeyboardPrefs.K_SILENT, true, true),
                switchRow("Haptic feedback", null, KeyboardPrefs.K_HAPTIC, true, true),
                seekRow("Haptic strength", KeyboardPrefs.K_HAPTIC_STRENGTH, 0, 100, 45, { v -> "$v%" }, true)
            )
        )

        // --- snippets
        root.addView(
            card(
                sectionTitle("Snippets"),
                label("One per line, up to 6. Insert them from the bookmark tool in the toolbar.", 12.5f, pal.textDim, false),
                EditText(this).apply {
                    hint = "name@example.com\n+1 555 0100\nOn my way!"
                    setHintTextColor(pal.textDim)
                    setTextColor(pal.text)
                    minLines = 4
                    gravity = Gravity.TOP
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    setText(store.getString(KeyboardPrefs.K_SNIPPETS, ""))
                    setPadding(dp(14), dp(12), dp(14), dp(12))
                    background = GradientDrawable().apply {
                        setColor(pal.keyFunc)
                        cornerRadius = dp(12).toFloat()
                    }
                    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }
                    addTextChangedListener(object : TextWatcher {
                        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                        override fun afterTextChanged(s: Editable?) {
                            store.edit().putString(KeyboardPrefs.K_SNIPPETS, s?.toString() ?: "").apply()
                        }
                    })
                }
            )
        )

        // --- odometer
        odometerView = label("", 22f, pal.text, true)
        root.addView(
            card(
                sectionTitle("Typewriter odometer"),
                odometerView,
                label("Keys struck since install. Only a number is stored, never what you typed.", 12.5f, pal.textDim, false)
            )
        )

        // --- about
        root.addView(
            card(
                sectionTitle("Privacy"),
                label(
                    "This app has no internet permission. What you type is never stored or sent anywhere. " +
                        "Clipboard history lives in memory only and is cleared when the keyboard service stops.",
                    13.5f, pal.textDim, false
                ),
                button("Reset all settings", false) {
                    // Settings go back to defaults; the lifetime odometer and your snippets are not settings.
                    val odometer = store.getLong(KeyboardPrefs.K_ODOMETER, 0L)
                    val snippets = store.getString(KeyboardPrefs.K_SNIPPETS, "") ?: ""
                    store.edit()
                        .clear()
                        .putLong(KeyboardPrefs.K_ODOMETER, odometer)
                        .putString(KeyboardPrefs.K_SNIPPETS, snippets)
                        .apply()
                    recreate()
                }
            )
        )

        return ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(pal.bg)
            addView(root)
        }
    }

    private fun updateStatus() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val selected = current.startsWith("$packageName/")
        statusView.text = when {
            !enabled -> "Step 1 of 2: enable Minimal Keyboard in system settings."
            !selected -> "Step 2 of 2: switch to Minimal Keyboard."
            else -> "Minimal Keyboard is your active keyboard."
        }
    }

    private fun refreshEnabled() {
        val on = store.getBoolean(KeyboardPrefs.K_EFFECTS, true)
        for (v in effectRows) {
            setEnabledDeep(v, on)
            v.alpha = if (on) 1f else 0.4f
        }
    }

    private fun setEnabledDeep(v: View, enabled: Boolean) {
        v.isEnabled = enabled
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) setEnabledDeep(v.getChildAt(i), enabled)
        }
    }

    // ------------------------------------------------------------ widgets

    private fun label(text: String, size: Float, color: Int, medium: Boolean): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = size
        tv.setTextColor(color)
        if (medium) tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        return tv
    }

    private fun sectionTitle(text: String): TextView =
        label(text.uppercase(), 12f, pal.accent, true).apply {
            letterSpacing = 0.12f
            setPadding(0, 0, 0, dp(6))
        }

    private fun card(vararg children: View): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.background = GradientDrawable().apply {
            setColor(pal.key)
            cornerRadius = dp(14).toFloat()
        }
        c.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
        for (child in children) c.addView(child)
        return c
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit): TextView {
        val b = label(text, 15f, if (filled) pal.onAccent else pal.text, true)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(16), dp(12), dp(16), dp(12))
        b.background = GradientDrawable().apply {
            setColor(if (filled) pal.accent else pal.keyFunc)
            cornerRadius = dp(12).toFloat()
        }
        b.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun tint(on: Int, off: Int): ColorStateList = ColorStateList(
        arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
        intArrayOf(on, off)
    )

    private fun switchRow(
        title: String, subtitle: String?, key: String, def: Boolean, effectDependent: Boolean
    ): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(8))

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        texts.addView(label(title, 16f, pal.text, false))
        if (subtitle != null) texts.addView(label(subtitle, 12.5f, pal.textDim, false))

        val sw = Switch(this)
        sw.isChecked = store.getBoolean(key, def)
        sw.thumbTintList = tint(pal.accent, pal.textDim)
        sw.trackTintList = tint(withAlpha(pal.accent, 0.4f), withAlpha(pal.textDim, 0.3f))
        sw.setOnCheckedChangeListener { _, checked ->
            store.edit().putBoolean(key, checked).apply()
            if (key == KeyboardPrefs.K_EFFECTS) refreshEnabled()
        }

        row.addView(texts)
        row.addView(sw)
        if (effectDependent) effectRows.add(row)
        return row
    }

    private fun seekRow(
        title: String, key: String, lo: Int, hi: Int, def: Int,
        format: (Int) -> String, effectDependent: Boolean
    ): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, dp(8), 0, dp(8))

        val current = store.getInt(key, def).coerceIn(lo, hi)
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        val name = label(title, 16f, pal.text, false)
        name.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        val value = label(format(current), 14f, pal.textDim, false)
        head.addView(name)
        head.addView(value)

        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = current - lo
        bar.progressTintList = ColorStateList.valueOf(pal.accent)
        bar.thumbTintList = ColorStateList.valueOf(pal.accent)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + lo
                value.text = format(v)
                if (fromUser) store.edit().putInt(key, v).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        col.addView(head)
        col.addView(bar)
        if (effectDependent) effectRows.add(col)
        return col
    }

    private fun segmentRow(
        title: String, key: String, options: List<String>, def: Int,
        textSize: Float = 14f, effectDependent: Boolean = false
    ): View {
        var current = store.getInt(key, def)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, dp(8), 0, dp(8))
        col.addView(label(title, 16f, pal.text, false))

        val seg = LinearLayout(this)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.setPadding(0, dp(8), 0, dp(4))
        val cells = ArrayList<TextView>()

        fun restyle() {
            for ((i, c) in cells.withIndex()) {
                val sel = i == current
                c.setTextColor(if (sel) pal.onAccent else pal.text)
                c.background = GradientDrawable().apply {
                    setColor(if (sel) pal.accent else pal.keyFunc)
                    cornerRadius = dp(10).toFloat()
                }
            }
        }

        for ((i, name) in options.withIndex()) {
            val c = label(name, textSize, pal.text, true)
            c.gravity = Gravity.CENTER
            c.setPadding(0, dp(10), 0, dp(10))
            c.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                if (i > 0) leftMargin = dp(6)
            }
            c.setOnClickListener {
                current = i
                store.edit().putInt(key, i).apply()
                restyle()
            }
            cells.add(c)
            seg.addView(c)
        }
        restyle()
        col.addView(seg)
        if (effectDependent) effectRows.add(col)
        return col
    }

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }
}
