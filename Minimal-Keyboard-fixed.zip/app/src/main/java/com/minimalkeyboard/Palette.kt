package com.minimalkeyboard

import android.graphics.Color

class Palette(
    val dark: Boolean,
    val bg: Int,
    val key: Int,
    val keyFunc: Int,
    val keyDown: Int,
    val keyFuncDown: Int,
    val text: Int,
    val textDim: Int,
    val shadow: Int,
    val highlight: Int,
    val accent: Int,
    val accentDown: Int,
    val onAccent: Int,
    val popup: Int,
    val engrave: Int,
    val dishShade: Int
) {
    companion object {
        /** Deep graphite with restrained grey keys and a single antique-brass accent. */
        val DARK = Palette(
            dark = true,
            bg = 0xFF16171A.toInt(),
            key = 0xFF303236.toInt(),
            keyFunc = 0xFF232528.toInt(),
            keyDown = 0xFF42444A.toInt(),
            keyFuncDown = 0xFF30323A.toInt(),
            text = 0xFFEDEBE6.toInt(),
            textDim = 0xFF9C9B97.toInt(),
            shadow = 0x66000000,
            highlight = 0x24FFFFFF,
            accent = 0xFFC9A66B.toInt(),
            accentDown = 0xFFA88A55.toInt(),
            onAccent = 0xFF1B1A17.toInt(),
            popup = 0xFF3A3C42.toInt(),
            engrave = 0x80000000.toInt(),
            dishShade = 0x66000000
        )

        /** Black keys with a typewriter-ribbon red accent. */
        val RIBBON = Palette(
            dark = true,
            bg = 0xFF0F0F10.toInt(),
            key = 0xFF1D1D1F.toInt(),
            keyFunc = 0xFF161617.toInt(),
            keyDown = 0xFF2B2B2E.toInt(),
            keyFuncDown = 0xFF222224.toInt(),
            text = 0xFFEFEAE0.toInt(),
            textDim = 0xFF8E8A82.toInt(),
            shadow = 0x77000000,
            highlight = 0x22FFFFFF,
            accent = 0xFFD2452B.toInt(),
            accentDown = 0xFFA83420.toInt(),
            onAccent = 0xFFFFF4EE.toInt(),
            popup = 0xFF2A2A2C.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        /** Green phosphor terminal. */
        val TERMINAL = Palette(
            dark = true,
            bg = 0xFF070D09.toInt(),
            key = 0xFF102017.toInt(),
            keyFunc = 0xFF0B160F.toInt(),
            keyDown = 0xFF1A3324.toInt(),
            keyFuncDown = 0xFF132A1C.toInt(),
            text = 0xFF8CFFB4.toInt(),
            textDim = 0xFF4F9E6C.toInt(),
            shadow = 0x88000000.toInt(),
            highlight = 0x2236FF8A,
            accent = 0xFF38E08A.toInt(),
            accentDown = 0xFF24A862.toInt(),
            onAccent = 0xFF04140A.toInt(),
            popup = 0xFF14301F.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        /** Deep navy with a cool blue accent. */
        val MIDNIGHT = Palette(
            dark = true,
            bg = 0xFF0B1020.toInt(),
            key = 0xFF1A2342.toInt(),
            keyFunc = 0xFF121A33.toInt(),
            keyDown = 0xFF26325C.toInt(),
            keyFuncDown = 0xFF1B2547.toInt(),
            text = 0xFFE6ECFF.toInt(),
            textDim = 0xFF8A97C2.toInt(),
            shadow = 0x88000000.toInt(),
            highlight = 0x226EA8FF,
            accent = 0xFF6EA8FF.toInt(),
            accentDown = 0xFF4C86E0.toInt(),
            onAccent = 0xFF0A1226.toInt(),
            popup = 0xFF222D55.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        val THEME_NAMES = listOf("System", "Ivory", "Graphite", "Ribbon", "Terminal", "Midnight")

        /** 0 = follow the system, then the named themes in [THEME_NAMES] order. */
        fun byId(id: Int, systemDark: Boolean): Palette = when (id) {
            1 -> LIGHT
            2 -> DARK
            3 -> RIBBON
            4 -> TERMINAL
            5 -> MIDNIGHT
            else -> if (systemDark) DARK else LIGHT
        }

        /** Warm ivory with soft neutral keys and delicate warm shadows. */
        val LIGHT = Palette(
            dark = false,
            bg = 0xFFEFE9DC.toInt(),
            key = 0xFFFBF8F1.toInt(),
            keyFunc = 0xFFE2DBCB.toInt(),
            keyDown = 0xFFE9E2D2.toInt(),
            keyFuncDown = 0xFFD5CDB9.toInt(),
            text = 0xFF2A2723.toInt(),
            textDim = 0xFF857F73.toInt(),
            shadow = 0x33503C14,
            highlight = 0xCCFFFFFF.toInt(),
            accent = 0xFF8C6A33.toInt(),
            accentDown = 0xFF74562A.toInt(),
            onAccent = 0xFFFBF8F1.toInt(),
            popup = 0xFFFBF8F1.toInt(),
            engrave = 0xCCFFFFFF.toInt(),
            dishShade = 0x2A3C2A0A
        )
    }
}

internal fun withAlpha(color: Int, a: Float): Int {
    val na = (Color.alpha(color) * a.coerceIn(0f, 1f)).toInt()
    return (color and 0x00FFFFFF) or (na shl 24)
}

internal fun lerpColor(a: Int, b: Int, t: Float): Int {
    if (t <= 0f) return a
    if (t >= 1f) return b
    val u = 1f - t
    return Color.argb(
        (Color.alpha(a) * u + Color.alpha(b) * t).toInt(),
        (Color.red(a) * u + Color.red(b) * t).toInt(),
        (Color.green(a) * u + Color.green(b) * t).toInt(),
        (Color.blue(a) * u + Color.blue(b) * t).toInt()
    )
}
