package com.minimalkeyboard

import android.graphics.Path
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Minimal line icons defined in a unit space (-1..1). The keyboard view scales the canvas
 * so one set of paths works for every key size.
 */
object Icons {

    val shift = Path().apply {
        moveTo(0f, -1f)
        lineTo(1f, 0f)
        lineTo(0.5f, 0f)
        lineTo(0.5f, 0.9f)
        lineTo(-0.5f, 0.9f)
        lineTo(-0.5f, 0f)
        lineTo(-1f, 0f)
        close()
    }

    val lockBar = Path().apply {
        moveTo(-0.55f, 1.5f)
        lineTo(0.55f, 1.5f)
    }

    val backspace = Path().apply {
        moveTo(-1f, 0f)
        lineTo(-0.45f, -0.75f)
        lineTo(1f, -0.75f)
        lineTo(1f, 0.75f)
        lineTo(-0.45f, 0.75f)
        close()
    }

    val backspaceX = Path().apply {
        moveTo(0.05f, -0.3f)
        lineTo(0.6f, 0.3f)
        moveTo(0.6f, -0.3f)
        lineTo(0.05f, 0.3f)
    }

    val enter = Path().apply {
        moveTo(0.95f, -0.75f)
        lineTo(0.95f, 0.15f)
        lineTo(-0.8f, 0.15f)
        moveTo(-0.25f, -0.4f)
        lineTo(-0.85f, 0.15f)
        lineTo(-0.25f, 0.7f)
    }

    val globe = Path().apply {
        addCircle(0f, 0f, 0.95f, Path.Direction.CW)
        addOval(RectF(-0.4f, -0.95f, 0.4f, 0.95f), Path.Direction.CW)
        moveTo(-0.95f, 0f)
        lineTo(0.95f, 0f)
    }

    val chevronDown = Path().apply {
        moveTo(-0.9f, -0.3f)
        lineTo(0f, 0.5f)
        lineTo(0.9f, -0.3f)
    }

    val gear = Path().apply {
        addCircle(0f, 0f, 0.55f, Path.Direction.CW)
        addCircle(0f, 0f, 0.18f, Path.Direction.CW)
        for (i in 0 until 8) {
            val a = i * PI / 4.0
            moveTo((cos(a) * 0.62).toFloat(), (sin(a) * 0.62).toFloat())
            lineTo((cos(a) * 0.98).toFloat(), (sin(a) * 0.98).toFloat())
        }
    }

    val selectBox = Path().apply {
        addRoundRect(RectF(-0.9f, -0.9f, 0.9f, 0.9f), 0.2f, 0.2f, Path.Direction.CW)
    }

    val selectLines = Path().apply {
        moveTo(-0.45f, -0.2f)
        lineTo(0.45f, -0.2f)
        moveTo(-0.45f, 0.3f)
        lineTo(0.25f, 0.3f)
    }

    val copy = Path().apply {
        addRoundRect(RectF(-0.85f, -0.95f, 0.3f, 0.35f), 0.15f, 0.15f, Path.Direction.CW)
        addRoundRect(RectF(-0.3f, -0.35f, 0.85f, 0.95f), 0.15f, 0.15f, Path.Direction.CW)
    }

    val cut = Path().apply {
        addCircle(-0.5f, 0.55f, 0.3f, Path.Direction.CW)
        addCircle(0.5f, 0.55f, 0.3f, Path.Direction.CW)
        moveTo(-0.38f, 0.3f)
        lineTo(0.6f, -0.95f)
        moveTo(0.38f, 0.3f)
        lineTo(-0.6f, -0.95f)
    }

    val paste = Path().apply {
        addRoundRect(RectF(-0.8f, -0.7f, 0.8f, 0.95f), 0.18f, 0.18f, Path.Direction.CW)
        addRoundRect(RectF(-0.38f, -0.95f, 0.38f, -0.5f), 0.12f, 0.12f, Path.Direction.CW)
        moveTo(-0.4f, 0.05f)
        lineTo(0.4f, 0.05f)
        moveTo(-0.4f, 0.5f)
        lineTo(0.4f, 0.5f)
    }

    val clipList = Path().apply {
        moveTo(-0.35f, -0.6f)
        lineTo(0.95f, -0.6f)
        moveTo(-0.35f, 0f)
        lineTo(0.95f, 0f)
        moveTo(-0.35f, 0.6f)
        lineTo(0.95f, 0.6f)
        addCircle(-0.8f, -0.6f, 0.1f, Path.Direction.CW)
        addCircle(-0.8f, 0f, 0.1f, Path.Direction.CW)
        addCircle(-0.8f, 0.6f, 0.1f, Path.Direction.CW)
    }

    val undo = Path().apply {
        moveTo(0.9f, 0.75f)
        cubicTo(0.9f, -0.1f, 0.3f, -0.6f, -0.5f, -0.55f)
        moveTo(-0.2f, -0.98f)
        lineTo(-0.75f, -0.55f)
        lineTo(-0.2f, -0.1f)
    }

    val redo = Path().apply {
        moveTo(-0.9f, 0.75f)
        cubicTo(-0.9f, -0.1f, -0.3f, -0.6f, 0.5f, -0.55f)
        moveTo(0.2f, -0.98f)
        lineTo(0.75f, -0.55f)
        lineTo(0.2f, -0.1f)
    }

    val emoji = Path().apply {
        addCircle(0f, 0f, 0.95f, Path.Direction.CW)
        addCircle(-0.35f, -0.25f, 0.07f, Path.Direction.CW)
        addCircle(0.35f, -0.25f, 0.07f, Path.Direction.CW)
        addArc(RectF(-0.55f, -0.35f, 0.55f, 0.55f), 20f, 140f)
    }

    val sparkle = Path().apply {
        moveTo(0f, -1f)
        quadTo(0.12f, -0.12f, 1f, 0f)
        quadTo(0.12f, 0.12f, 0f, 1f)
        quadTo(-0.12f, 0.12f, -1f, 0f)
        quadTo(-0.12f, -0.12f, 0f, -1f)
        close()
    }

    val bookmark = Path().apply {
        moveTo(-0.55f, -0.95f)
        lineTo(0.55f, -0.95f)
        lineTo(0.55f, 0.95f)
        lineTo(0f, 0.5f)
        lineTo(-0.55f, 0.95f)
        close()
    }

    val hand = Path().apply {
        moveTo(-0.95f, 0f)
        lineTo(0.95f, 0f)
        moveTo(-0.95f, 0f)
        lineTo(-0.5f, -0.42f)
        moveTo(-0.95f, 0f)
        lineTo(-0.5f, 0.42f)
        moveTo(0.95f, 0f)
        lineTo(0.5f, -0.42f)
        moveTo(0.95f, 0f)
        lineTo(0.5f, 0.42f)
    }
}
