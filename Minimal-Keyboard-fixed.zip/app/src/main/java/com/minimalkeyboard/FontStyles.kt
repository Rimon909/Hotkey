package com.minimalkeyboard

/** Unicode "font" styles: letters are swapped for look-alike glyphs, so styled text works in any app. */
enum class FontStyle(val label: String) {
    NORMAL("Normal"),
    BOLD("Bold"),
    ITALIC("Italic"),
    BOLD_ITALIC("Bold italic"),
    SCRIPT("Script"),
    BOLD_SCRIPT("Ink script"),
    FRAKTUR("Fraktur"),
    DOUBLE_STRUCK("Outline"),
    SANS("Sans"),
    SANS_BOLD("Sans bold"),
    MONO("Typewriter"),
    CIRCLED("Circled"),
    SMALL_CAPS("Small caps"),
    FULLWIDTH("Wide"),
    STRIKE("Strike"),
    UNDERLINE("Underline")
}

object FontStyles {

    private val SCRIPT_EX = mapOf(
        'B' to 0x212C, 'E' to 0x2130, 'F' to 0x2131, 'H' to 0x210B, 'I' to 0x2110,
        'L' to 0x2112, 'M' to 0x2133, 'R' to 0x211B, 'e' to 0x212F, 'g' to 0x210A, 'o' to 0x2134
    )
    private val FRAKTUR_EX = mapOf(
        'C' to 0x212D, 'H' to 0x210C, 'I' to 0x2111, 'R' to 0x211C, 'Z' to 0x2128
    )
    private val DOUBLE_EX = mapOf(
        'C' to 0x2102, 'H' to 0x210D, 'N' to 0x2115, 'P' to 0x2119,
        'Q' to 0x211A, 'R' to 0x211D, 'Z' to 0x2124
    )
    private val SMALL_CAPS = intArrayOf(
        0x1D00, 0x0299, 0x1D04, 0x1D05, 0x1D07, 0xA730, 0x0262, 0x029C, 0x026A, 0x1D0A,
        0x1D0B, 0x029F, 0x1D0D, 0x0274, 0x1D0F, 0x1D18, 0x01EB, 0x0280, 0xA731, 0x1D1B,
        0x1D1C, 0x1D20, 0x1D21, 0x0078, 0x028F, 0x1D22
    )

    fun apply(text: String, style: FontStyle): String {
        if (style == FontStyle.NORMAL || text.isEmpty()) return text
        val sb = StringBuilder(text.length * 2)
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            i += Character.charCount(cp)
            when (style) {
                FontStyle.STRIKE -> {
                    sb.appendCodePoint(cp)
                    if (!Character.isWhitespace(cp)) sb.appendCodePoint(0x0336)
                }
                FontStyle.UNDERLINE -> {
                    sb.appendCodePoint(cp)
                    if (!Character.isWhitespace(cp)) sb.appendCodePoint(0x0332)
                }
                FontStyle.FULLWIDTH -> {
                    when {
                        cp == 0x20 -> sb.appendCodePoint(0x3000)
                        cp in 0x21..0x7E -> sb.appendCodePoint(cp - 0x21 + 0xFF01)
                        else -> sb.appendCodePoint(cp)
                    }
                }
                else -> {
                    val mapped = if (cp < 0x80) mapAscii(cp.toChar(), style) else null
                    sb.appendCodePoint(mapped ?: cp)
                }
            }
        }
        return sb.toString()
    }

    private fun base(c: Char, up: Int, low: Int, dig: Int): Int? = when {
        c in 'A'..'Z' -> up + (c - 'A')
        c in 'a'..'z' -> low + (c - 'a')
        c in '0'..'9' && dig >= 0 -> dig + (c - '0')
        else -> null
    }

    private fun mapAscii(c: Char, style: FontStyle): Int? = when (style) {
        FontStyle.BOLD -> base(c, 0x1D400, 0x1D41A, 0x1D7CE)
        FontStyle.ITALIC -> if (c == 'h') 0x210E else base(c, 0x1D434, 0x1D44E, -1)
        FontStyle.BOLD_ITALIC -> base(c, 0x1D468, 0x1D482, -1)
        FontStyle.SCRIPT -> SCRIPT_EX[c] ?: base(c, 0x1D49C, 0x1D4B6, -1)
        FontStyle.BOLD_SCRIPT -> base(c, 0x1D4D0, 0x1D4EA, -1)
        FontStyle.FRAKTUR -> FRAKTUR_EX[c] ?: base(c, 0x1D504, 0x1D51E, -1)
        FontStyle.DOUBLE_STRUCK -> DOUBLE_EX[c] ?: base(c, 0x1D538, 0x1D552, 0x1D7D8)
        FontStyle.SANS -> base(c, 0x1D5A0, 0x1D5BA, 0x1D7E2)
        FontStyle.SANS_BOLD -> base(c, 0x1D5D4, 0x1D5EE, 0x1D7EC)
        FontStyle.MONO -> base(c, 0x1D670, 0x1D68A, 0x1D7F6)
        FontStyle.CIRCLED -> when {
            c == '0' -> 0x24EA
            c in '1'..'9' -> 0x2460 + (c - '1')
            else -> base(c, 0x24B6, 0x24D0, -1)
        }
        FontStyle.SMALL_CAPS -> when {
            c in 'a'..'z' -> SMALL_CAPS[c - 'a']
            c in 'A'..'Z' -> SMALL_CAPS[c - 'A']
            else -> null
        }
        else -> null
    }
}
