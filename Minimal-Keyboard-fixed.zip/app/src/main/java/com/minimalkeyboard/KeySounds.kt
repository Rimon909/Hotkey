package com.minimalkeyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.util.Collections
import java.util.Random

enum class SoundCat { LETTER, SPACE, BACK, ENTER, MOD, POP, OPEN, CLOSE, BELL, RIFFLE }

/**
 * Low-latency key sounds built on [SoundPool]. Four sound packs plus shared interface sounds.
 * The pool is created lazily, decodes the small bundled WAVs asynchronously, and is released
 * when sound is disabled, the pack changes, or the service is destroyed.
 */
class KeySounds(private val context: Context) {

    private var pool: SoundPool? = null
    private var pack = 0
    private val variants = HashMap<SoundCat, IntArray>()
    private val ready: MutableSet<Int> = Collections.synchronizedSet(HashSet<Int>())
    private val lastVariant = HashMap<SoundCat, Int>()
    private val random = Random()

    fun setEnabled(enabled: Boolean) {
        if (enabled) ensure() else release()
    }

    /** 0 = Typewriter, 1 = Mechanical, 2 = Soft, 3 = Marimba. */
    fun setPack(id: Int) {
        val p = id.coerceIn(0, 3)
        if (p == pack) return
        pack = p
        if (pool != null) {
            release()
            ensure()
        }
    }

    private fun packResources(id: Int): Map<SoundCat, IntArray> = when (id) {
        1 -> mapOf(
            SoundCat.LETTER to intArrayOf(R.raw.mech_letter_1, R.raw.mech_letter_2, R.raw.mech_letter_3),
            SoundCat.SPACE to intArrayOf(R.raw.mech_space_1, R.raw.mech_space_2),
            SoundCat.BACK to intArrayOf(R.raw.mech_back_1, R.raw.mech_back_2),
            SoundCat.ENTER to intArrayOf(R.raw.mech_enter_1),
            SoundCat.MOD to intArrayOf(R.raw.mech_mod_1, R.raw.mech_mod_2)
        )
        2 -> mapOf(
            SoundCat.LETTER to intArrayOf(R.raw.soft_letter_1, R.raw.soft_letter_2, R.raw.soft_letter_3),
            SoundCat.SPACE to intArrayOf(R.raw.soft_space_1, R.raw.soft_space_2),
            SoundCat.BACK to intArrayOf(R.raw.soft_back_1, R.raw.soft_back_2),
            SoundCat.ENTER to intArrayOf(R.raw.soft_enter_1),
            SoundCat.MOD to intArrayOf(R.raw.soft_mod_1, R.raw.soft_mod_2)
        )
        3 -> mapOf(
            SoundCat.LETTER to intArrayOf(R.raw.mari_letter_1, R.raw.mari_letter_2, R.raw.mari_letter_3),
            SoundCat.SPACE to intArrayOf(R.raw.mari_space_1, R.raw.mari_space_2),
            SoundCat.BACK to intArrayOf(R.raw.mari_back_1, R.raw.mari_back_2),
            SoundCat.ENTER to intArrayOf(R.raw.mari_enter_1),
            SoundCat.MOD to intArrayOf(R.raw.mari_mod_1, R.raw.mari_mod_2)
        )
        else -> mapOf(
            SoundCat.LETTER to intArrayOf(R.raw.key_letter_1, R.raw.key_letter_2, R.raw.key_letter_3),
            SoundCat.SPACE to intArrayOf(R.raw.key_space_1, R.raw.key_space_2),
            SoundCat.BACK to intArrayOf(R.raw.key_back_1, R.raw.key_back_2),
            SoundCat.ENTER to intArrayOf(R.raw.key_enter_1),
            SoundCat.MOD to intArrayOf(R.raw.key_mod_1, R.raw.key_mod_2)
        )
    }

    private fun sharedResources(): Map<SoundCat, IntArray> = mapOf(
        SoundCat.POP to intArrayOf(R.raw.ui_pop_1, R.raw.ui_pop_2),
        SoundCat.OPEN to intArrayOf(R.raw.ui_open_1),
        SoundCat.CLOSE to intArrayOf(R.raw.ui_close_1),
        SoundCat.BELL to intArrayOf(R.raw.ui_bell_1),
        SoundCat.RIFFLE to intArrayOf(R.raw.ui_riffle_1)
    )

    private fun ensure() {
        if (pool != null) return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder()
            .setMaxStreams(8)
            .setAudioAttributes(attrs)
            .build()
        p.setOnLoadCompleteListener { _, id, status ->
            if (status == 0) ready.add(id)
        }
        for ((cat, ids) in packResources(pack)) {
            variants[cat] = IntArray(ids.size) { p.load(context, ids[it], 1) }
        }
        for ((cat, ids) in sharedResources()) {
            variants[cat] = IntArray(ids.size) { p.load(context, ids[it], 1) }
        }
        pool = p
    }

    /**
     * [volume] is 0..1; [tempo] is a pitch bias (typing rhythm). Each play picks a different
     * variant and slightly varies pitch and level so it never sounds robotic.
     */
    fun play(cat: SoundCat, volume: Float, repeat: Boolean, tempo: Float) {
        val p = pool ?: return
        val ids = variants[cat] ?: return
        var idx = random.nextInt(ids.size)
        val previous = lastVariant[cat]
        if (ids.size > 1 && previous != null && idx == previous) {
            idx = (idx + 1 + random.nextInt(ids.size - 1)) % ids.size
        }
        val id = ids[idx]
        if (!ready.contains(id)) return
        lastVariant[cat] = idx

        val spread = when (cat) {
            SoundCat.LETTER -> 0.12f
            SoundCat.POP -> 0.10f
            SoundCat.SPACE, SoundCat.ENTER -> 0.05f
            else -> 0.03f
        }
        val bias = if (cat == SoundCat.LETTER || cat == SoundCat.SPACE || cat == SoundCat.BACK) tempo else 1f
        val rate = ((1f - spread / 2f + random.nextFloat() * spread) * bias).coerceIn(0.5f, 2f)
        var level = volume * (0.86f + random.nextFloat() * 0.14f)
        if (repeat) level *= 0.6f
        level = level.coerceIn(0f, 1f)
        p.play(id, level, level, 1, 0, rate)
    }

    fun release() {
        pool?.release()
        pool = null
        variants.clear()
        ready.clear()
        lastVariant.clear()
    }
}
