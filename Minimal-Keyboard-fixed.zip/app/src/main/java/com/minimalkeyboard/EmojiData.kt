package com.minimalkeyboard

class EmojiCategory(val tab: String, val name: String, val items: List<String>, val wide: Boolean = false)

/** Emoji from Unicode 11 and earlier so they render on every Android 8+ device. */
object EmojiData {

    private fun split(s: String): List<String> = s.split(' ').filter { it.isNotEmpty() }

    val categories: List<EmojiCategory> = listOf(
        EmojiCategory("\uD83D\uDD58", "Recent", emptyList()),
        EmojiCategory(
            "😀", "Smileys",
            split(
                "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥳 " +
                    "😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 " +
                    "🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 " +
                    "👹 👺 🤡 💩 👻 💀 👽 🤖 🎃"
            )
        ),
        EmojiCategory(
            "👋", "People",
            split(
                "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐 🖖 👋 💪 🙏 🤝 👏 🙌 👐 🤲 ✍️ 💅 🤳 👀 👅 " +
                    "👄 👶 🧒 👦 👧 🧑 👨 👩 🧔 👴 👵 🙍 🙎 🙅 🙆 💁 🙋 🙇 🤦 🤷 💃 🕺 🚶 🏃"
            )
        ),
        EmojiCategory(
            "🐶", "Nature",
            split(
                "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 " +
                    "🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦐 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦏 🐪 🦒 🌵 " +
                    "🎄 🌲 🌳 🌴 🌱 🌿 🍀 🍁 🍂 🍃 🌺 🌻 🌹 🌷 🌸 🌼 ⭐ 🌟 ✨ ⚡ 🔥 🌈 ☀️ ☁️ ❄️ 🌊"
            )
        ),
        EmojiCategory(
            "🍔", "Food",
            split(
                "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥒 🌽 🥕 🥔 🍠 🥐 🍞 🥖 🧀 🥚 🍳 " +
                    "🥞 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍘 🍥 🍢 🍡 🍧 🍨 🍦 " +
                    "🥧 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 ☕ 🍵 🥤 🍺 🍻 🥂 🍷 🥃 🍸 🍹 🍾"
            )
        ),
        EmojiCategory(
            "🚗", "Travel",
            split(
                "🚗 🚕 🚙 🚌 🚎 🏎 🚓 🚑 🚒 🚚 🚜 🏍 🛵 🚲 🛴 🚂 🚆 🚇 🚊 ✈️ 🛫 🛬 🚀 🛸 🚁 ⛵ 🚤 🛳 ⚓ 🏠 " +
                    "🏡 🏢 🏥 🏦 🏨 🏫 🏰 🗼 🗽 ⛪ 🕌 🕍 ⛩ 🌋 🏔 ⛰ 🏖 🏝 🏜 🗺 🧭 ⏰ 🌅 🌄 🌃 🌉 🎡 🎢 🎠"
            )
        ),
        EmojiCategory(
            "💡", "Objects",
            split(
                "💡 🔦 🕯 📱 💻 ⌨️ 🖥 🖨 🖱 💾 💿 📷 📹 🎥 📺 📻 🎙 🎧 🎤 🎸 🎹 🎺 🎻 🥁 🎬 🎮 🕹 🎲 🧩 🎯 " +
                    "🎳 ⚽ 🏀 🏈 ⚾ 🎾 🏐 🏓 🏸 🥊 🎁 🎈 🎉 🎊 🏆 🏅 🔑 🗝 🔒 🔓 🔨 🛠 ⚙️ 🔧 🔩 💰 💳 💎 ⚖️ " +
                    "📌 📎 ✂️ 📝 📖 📚 📅 📊 📈 📉 ✉️ 📦 🔔 🔍 🔬 🔭 💊 🧪 🧬"
            )
        ),
        EmojiCategory(
            "❤️", "Symbols",
            split(
                "❤️ 🧡 💛 💚 💙 💜 🖤 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💯 💢 💥 💫 💦 💨 💬 💭 ✔️ ✅ ❌ ❎ ➕ ➖ " +
                    "➗ ✖️ ♾ ‼️ ⁉️ ❓ ❔ ❕ ❗ ⭕ 🔴 🔵 ⚫ ⚪ ⬛ ⬜ ▶️ ⏸ ⏹ ⏩ ⏪ 🔀 🔁 🔊 🔇 ♻️ ⚠️ 🚫 ⛔ ℹ️ ✳️ ❇️"
            )
        ),
        EmojiCategory(
            "ツ", "Kaomoji",
            "¯\\_(ツ)_/¯|(╯°□°)╯︵ ┻━┻|┬─┬ ノ( ゜-゜ノ)|ಠ_ಠ|(ᵔᴥᵔ)|(づ｡◕‿‿◕｡)づ|(☞ﾟヮﾟ)☞|ʕ•ᴥ•ʔ|(¬‿¬)|(•_•)|(⌐■_■)|\\(^o^)/|(≧▽≦)|(T_T)|(ノಠ益ಠ)ノ|♪(´ε｀ )|(＾▽＾)|(︶︹︺)|(•‿•)"
                .split('|'),
            true
        )
    )
}
