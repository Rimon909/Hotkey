package com.minimalkeyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MinimalImeService : InputMethodService(), KeyboardListener {

    private lateinit var prefs: KeyboardPrefs
    private lateinit var sounds: KeySounds
    private lateinit var haptics: Haptics
    private lateinit var clipStore: ClipboardStore
    private lateinit var audio: AudioManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var keyboardView: KeyboardView? = null

    // Selection as last reported by the editor (kept optimistically up to date for gestures).
    private var selStart = -1
    private var selEnd = -1
    private var gestureAnchor = -1
    private var gestureActive = -1

    private var lastSpaceTime = 0L
    private var passwordLike = false

    // ------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        prefs = KeyboardPrefs(this)
        sounds = KeySounds(this)
        haptics = Haptics(this)
        clipStore = ClipboardStore(this)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        clipStore.start()
    }

    override fun onDestroy() {
        sounds.release()
        clipStore.stop()
        mainHandler.removeCallbacksAndMessages(null)
        keyboardView = null
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val view = KeyboardView(this, prefs, this)
        view.applyTheme(currentPalette())
        keyboardView = view
        return view
    }

    /** A clean keyboard in landscape too: no full-screen extract UI. */
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        prefs.reload()
        sounds.setEnabled(prefs.soundActive)
        val view = keyboardView ?: return
        val palette = currentPalette()
        view.applyTheme(palette)
        view.applyPrefs()
        applySystemBars(palette)

        if (info == null) return
        val type = info.inputType
        val cls = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        val isText = cls == InputType.TYPE_CLASS_TEXT
        val numeric = cls == InputType.TYPE_CLASS_NUMBER ||
            cls == InputType.TYPE_CLASS_PHONE ||
            cls == InputType.TYPE_CLASS_DATETIME

        passwordLike = (isText && (
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            )) || (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)

        val comma = when {
            isText && (variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS) -> "@"
            isText && variation == InputType.TYPE_TEXT_VARIATION_URI -> "/"
            else -> ","
        }
        val options = LayoutOptions(showGlobe = offerGlobe(), commaKey = comma)
        view.configureForInput(if (numeric) Page.NUMBERS else Page.LETTERS, options, enterLabelFor(info))

        if (!restarting) view.resetShift()
        selStart = info.initialSelStart
        selEnd = info.initialSelEnd
        lastSpaceTime = 0L
        updateAutoShift()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        keyboardView?.cancelAllTouches()
        gestureAnchor = -1
        gestureActive = -1
    }

    /** The signature opening animation plays only when the keyboard window actually appears. */
    override fun onWindowShown() {
        super.onWindowShown()
        keyboardView?.playOpening()
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        keyboardView?.onHidden()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val palette = currentPalette()
        keyboardView?.applyTheme(palette)
        applySystemBars(palette)
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        selStart = newSelStart
        selEnd = newSelEnd
        if (gestureAnchor >= 0) {
            // Keep the moving end of a gesture selection in sync with what the editor really did.
            if (newSelStart == gestureAnchor) gestureActive = newSelEnd
            else if (newSelEnd == gestureAnchor) gestureActive = newSelStart
            pushSelectionPreview()
        }
    }

    // ------------------------------------------------------------ helpers

    private fun isDark(): Boolean = when (prefs.theme) {
        KeyboardPrefs.THEME_LIGHT -> false
        KeyboardPrefs.THEME_DARK -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    }

    private fun currentPalette(): Palette = if (isDark()) Palette.DARK else Palette.LIGHT

    private fun applySystemBars(palette: Palette) {
        try {
            val w = window?.window ?: return
            w.navigationBarColor = palette.bg
            val decor = w.decorView
            var flags = decor.systemUiVisibility
            flags = if (palette.dark) {
                flags and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            } else {
                flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            decor.systemUiVisibility = flags
        } catch (e: Exception) {
            // Cosmetic only.
        }
    }

    private fun offerGlobe(): Boolean = try {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.enabledInputMethodList.size > 1
    } catch (e: Exception) {
        false
    }

    private fun enterLabelFor(info: EditorInfo): String? {
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return null
        val custom = info.actionLabel
        if (custom != null) return custom.toString()
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "Go"
            EditorInfo.IME_ACTION_SEARCH -> "Search"
            EditorInfo.IME_ACTION_SEND -> "Send"
            EditorInfo.IME_ACTION_NEXT -> "Next"
            EditorInfo.IME_ACTION_DONE -> "Done"
            EditorInfo.IME_ACTION_PREVIOUS -> "Prev"
            else -> null
        }
    }

    private fun updateAutoShift() {
        val view = keyboardView ?: return
        val info = currentInputEditorInfo
        if (!prefs.autoCapitalize || passwordLike || info == null) {
            view.setAutoCapitalized(false)
            return
        }
        val ic = currentInputConnection ?: return
        val caps = ic.getCursorCapsMode(info.inputType) != 0
        view.setAutoCapitalized(caps)
    }

    private fun sendKeyDownUp(code: Int, meta: Int = 0) {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0, meta))
    }

    private fun clipboard(): ClipboardManager =
        getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    // ------------------------------------------------------------ KeyboardListener

    override fun onText(text: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(text, 1)
        lastSpaceTime = 0L
        updateAutoShift()
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        if (prefs.doubleSpacePeriod && !passwordLike && lastSpaceTime != 0L) {
            val before = ic.getTextBeforeCursor(2, 0)
            if (TextLogic.shouldDoubleSpace(before, now - lastSpaceTime)) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                ic.endBatchEdit()
                lastSpaceTime = 0L
                updateAutoShift()
                return
            }
        }
        ic.commitText(" ", 1)
        lastSpaceTime = now
        updateAutoShift()
    }

    override fun onBackspace(repeatCount: Int) {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else if (TextLogic.deletesWord(repeatCount)) {
            val before = ic.getTextBeforeCursor(64, 0)
            if (before.isNullOrEmpty()) {
                sendKeyDownUp(KeyEvent.KEYCODE_DEL)
            } else {
                ic.deleteSurroundingText(TextLogic.wordDeleteLength(before), 0)
            }
        } else {
            val before = ic.getTextBeforeCursor(1, 0)
            if (before.isNullOrEmpty()) {
                // Editors without text access (or an empty field) still get a real DEL key.
                sendKeyDownUp(KeyEvent.KEYCODE_DEL)
            } else {
                ic.deleteSurroundingTextInCodePoints(1, 0)
            }
        }
        lastSpaceTime = 0L
        updateAutoShift()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        if (info == null || (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) {
            sendKeyDownUp(KeyEvent.KEYCODE_ENTER)
        } else if (info.actionLabel != null) {
            ic.performEditorAction(info.actionId)
        } else {
            val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
            if (action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
                sendKeyDownUp(KeyEvent.KEYCODE_ENTER)
            } else {
                ic.performEditorAction(action)
            }
        }
        lastSpaceTime = 0L
        // The editor handles key events asynchronously; re-check capitalisation shortly after.
        mainHandler.postDelayed({ updateAutoShift() }, 40L)
    }

    override fun onSelectionGesture(active: Boolean) {
        if (active) {
            gestureAnchor = selStart
            gestureActive = selEnd
            pushSelectionPreview()
        } else {
            gestureAnchor = -1
            gestureActive = -1
        }
    }

    override fun onCursorMove(delta: Int, select: Boolean) {
        val ic = currentInputConnection ?: return
        if (delta == 0) return
        if (selStart < 0 || selEnd < 0) {
            dpadMove(delta, select)
            return
        }
        val from = when {
            select -> gestureActive
            delta < 0 -> selStart
            else -> selEnd
        }
        if (from < 0) {
            dpadMove(delta, select)
            return
        }
        var target = max(0, from + delta)
        if (target > selEnd) {
            // Probe how much text actually exists after the cursor so we never run past the end.
            val available = ic.getTextAfterCursor(target - selEnd, 0)?.length ?: 0
            target = min(target, selEnd + available)
        }
        if (target == from) return

        val a: Int
        val b: Int
        if (select) {
            val anchor = if (gestureAnchor >= 0) gestureAnchor else from
            a = min(anchor, target)
            b = max(anchor, target)
            gestureActive = target
        } else {
            a = target
            b = target
        }
        if (ic.setSelection(a, b)) {
            selStart = a
            selEnd = b
        } else {
            // Some editors refuse setSelection; arrow keys are the portable fallback.
            dpadMove(delta, select)
        }
    }

    private fun pushSelectionPreview() {
        val text = currentInputConnection?.getSelectedText(0)
        keyboardView?.setSelectionPreview(text?.toString() ?: "")
    }

    override fun onLineMove(delta: Int, select: Boolean) {
        if (delta == 0) return
        val code = if (delta < 0) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN
        val meta = if (select) KeyEvent.META_SHIFT_ON else 0
        repeat(min(abs(delta), 4)) { sendKeyDownUp(code, meta) }
    }

    private fun dpadMove(delta: Int, select: Boolean) {
        val code = if (delta < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        val meta = if (select) KeyEvent.META_SHIFT_ON else 0
        repeat(min(abs(delta), 8)) { sendKeyDownUp(code, meta) }
    }

    override fun onTool(id: String) {
        when (id) {
            "select_all" -> selectAll()
            "copy" -> copySelection(false)
            "cut" -> {
                copySelection(true)
                updateAutoShift()
            }
            "paste" -> paste()
            "clipboard" -> keyboardView?.showClipboard(clipStore.snapshot())
            "settings" -> openSettings()
            "hide" -> requestHideSelf(0)
        }
    }

    override fun onClipPick(text: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(text, 1)
        lastSpaceTime = 0L
        updateAutoShift()
    }

    override fun onClipClear() {
        clipStore.clear()
    }

    override fun onNextIme() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (Build.VERSION.SDK_INT >= 28) {
            if (!switchToNextInputMethod(false)) imm.showInputMethodPicker()
        } else {
            imm.showInputMethodPicker()
        }
    }

    override fun onFeedback(type: KeyType, repeat: Boolean) {
        if (!prefs.effects) return
        if (prefs.soundActive && soundAllowed()) {
            sounds.play(categoryFor(type), soundVolume(), repeat)
        }
        if (prefs.hapticActive) haptics.tick(prefs.hapticStrength, repeat)
    }

    override fun onHapticStep() {
        if (prefs.effects && prefs.hapticActive) haptics.tick(prefs.hapticStrength, true)
    }

    private fun categoryFor(type: KeyType): SoundCat = when (type) {
        KeyType.CHAR -> SoundCat.LETTER
        KeyType.SPACE -> SoundCat.SPACE
        KeyType.BACKSPACE -> SoundCat.BACK
        KeyType.ENTER -> SoundCat.ENTER
        else -> SoundCat.MOD
    }

    private fun soundVolume(): Float {
        val v = prefs.soundVolume / 100f
        return (v * v * 0.6f + v * 0.4f).coerceIn(0f, 1f)
    }

    private fun soundAllowed(): Boolean =
        !prefs.respectSilentMode || audio.ringerMode == AudioManager.RINGER_MODE_NORMAL

    // ------------------------------------------------------------ editing shortcuts

    private fun selectAll() {
        val ic = currentInputConnection ?: return
        if (!ic.performContextMenuAction(android.R.id.selectAll)) {
            sendKeyDownUp(KeyEvent.KEYCODE_A, KeyEvent.META_CTRL_ON)
        }
    }

    private fun copySelection(cut: Boolean) {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            clipboard().setPrimaryClip(ClipData.newPlainText("text", selected.toString()))
            if (cut) ic.commitText("", 1)
        } else {
            ic.performContextMenuAction(if (cut) android.R.id.cut else android.R.id.copy)
        }
    }

    private fun paste() {
        val ic = currentInputConnection ?: return
        val clip = clipboard().primaryClip
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this) else null
        if (!text.isNullOrEmpty()) {
            ic.commitText(text, 1)
            lastSpaceTime = 0L
            updateAutoShift()
        } else {
            ic.performContextMenuAction(android.R.id.paste)
        }
    }

    private fun openSettings() {
        val intent = Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        requestHideSelf(0)
    }
}
