package com.minimalkeyboard

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextPaint
import android.text.TextUtils
import android.util.SparseArray
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Callbacks from the keyboard surface to the input method service. */
interface KeyboardListener {
    fun onText(text: String)
    fun onSpace()
    fun onBackspace(repeatCount: Int)
    fun onEnter()
    fun onCursorMove(delta: Int, select: Boolean)
    fun onLineMove(delta: Int, select: Boolean)
    fun onSelectionGesture(active: Boolean)
    fun onTool(id: String)
    fun onClipPick(text: String)
    fun onClipClear()
    fun onNextIme()
    fun onFeedback(type: KeyType, repeat: Boolean)
    fun onHapticStep()
}

/**
 * The whole keyboard is drawn on one canvas. Hit-testing is arithmetic on cached rectangles,
 * per-key animation needs no child views, and the memory footprint stays small.
 */
class KeyboardView(
    context: Context,
    private val prefs: KeyboardPrefs,
    private val listener: KeyboardListener
) : View(context) {

    // ---------------------------------------------------------------- model

    private class KeyGeom(val key: Key) {
        val cell = RectF()
        val face = RectF()
        var cx = 0f
        var cy = 0f
        var startX = 0f
        var startY = 0f
        var startRot = 0f
        var arcSign = 1f
        var delay = 0f
        var seq = 0
        var press = 0f
        var pressTarget = 0f
        var rowIndex = 0
    }

    private class Popup(val items: List<String>, val rects: Array<RectF>, val born: Long) {
        var index = 0
    }

    private class Mark(val x: Float, val y: Float, val face: RectF, val start: Long)

    private inner class Ptr(val id: Int, var geom: KeyGeom) {
        var downX = 0f
        var downY = 0f
        var lastX = 0f
        var lastY = 0f
        var downTime = 0L
        var mode = 0 // space bar: 0 idle, 1 cursor, 2 select. select pad: 3
        var moved = false
        var done = false
        var repeatCount = 0
        var popup: Popup? = null
        val acc = StepAccumulator()
        val accY = StepAccumulator()

        val longPress = Runnable { onLongPress(this) }

        val repeatRunnable: Runnable = object : Runnable {
            override fun run() {
                repeatCount++
                listener.onFeedback(KeyType.BACKSPACE, true)
                listener.onBackspace(repeatCount)
                ui.postDelayed(this, TextLogic.backspaceDelay(repeatCount))
            }
        }
    }

    // ---------------------------------------------------------------- state

    private val density = resources.displayMetrics.density
    private val cornerRadius = 8f * density
    private val ui = Handler(Looper.getMainLooper())

    private var palette: Palette = Palette.DARK
    private var page = Page.LETTERS
    private var shift = ShiftState.OFF
    private var lastShiftTap = 0L
    private var layoutOptions = LayoutOptions()
    private var enterLabel: String? = null
    private var spaceMode = 0
    private var panelOpen = false
    private var clips: List<String> = emptyList()

    private val geoms = ArrayList<KeyGeom>()
    private val bySeq = ArrayList<KeyGeom>()
    private val toolGeoms = ArrayList<KeyGeom>()
    private val panelGeoms = ArrayList<KeyGeom>()
    private var spaceGeom: KeyGeom? = null
    private var padGeom: KeyGeom? = null
    private val ptrs = SparseArray<Ptr>()
    private val marks = ArrayList<Mark>()

    private var keyH = 0f
    private var gap = 0f
    private var sidePad = 0f
    private var toolbarH = 0f
    private var rowsTop = 0f
    private var bottomPad = 0f
    private var bottomInset = 0f

    // opening "card shuffle" animation
    private val openInterp = PathInterpolator(0.2f, 0.85f, 0.25f, 1f)
    private var openAnimator: ValueAnimator? = null
    private var opening = false
    private var openRequested = false
    private var openElapsed = OPEN_TOTAL_MS

    // selection pad (space bar held)
    private val selInterp = PathInterpolator(0.2f, 0.9f, 0.25f, 1f)
    private var selectUi = false
    private var selT = 0f
    private var selAnimator: ValueAnimator? = null
    private var selPreview = ""
    private var selCount = 0
    private var lastPadTapTime = 0L
    private var lastPadTapX = 0f
    private var lastPadTapY = 0f
    private val padRect = RectF()

    private var settleStart = 0L
    private var lastFrame = 0L

    // ---------------------------------------------------------------- paints

    private val tfMedium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val tfRegular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val tfType: Typeface = Typeface.create("serif-monospace", Typeface.NORMAL)

    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val iconStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val dashStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        pathEffect = DashPathEffect(floatArrayOf(0.35f, 0.3f), 0f)
    }
    private val iconFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tmp = RectF()
    private val dish = RectF()

    // ---------------------------------------------------------------- public API

    fun applyTheme(p: Palette) {
        palette = p
        invalidate()
    }

    fun applyPrefs() {
        computeMetrics()
        requestLayout()
        buildGeometry()
        invalidate()
    }

    /** Selects the starting page and key variants for the current text field. */
    fun configureForInput(startPage: Page, options: LayoutOptions, enterKeyLabel: String?) {
        val changed = startPage != page || options != layoutOptions
        enterLabel = enterKeyLabel
        if (changed) {
            page = startPage
            layoutOptions = options
            if (panelOpen) closePanel()
            buildGeometry()
        }
        invalidate()
    }

    fun resetShift() {
        shift = ShiftState.OFF
        invalidate()
    }

    /** Auto-capitalisation hook: called by the service after edits. */
    fun setAutoCapitalized(caps: Boolean) {
        if (shift == ShiftState.LOCK) return
        val target = if (caps) ShiftState.ONCE else ShiftState.OFF
        if (target != shift) {
            shift = target
            invalidate()
        }
    }

    fun showClipboard(list: List<String>) {
        if (selectUi) exitSelect(false, true)
        clips = list
        panelOpen = true
        buildPanel()
        invalidate()
    }

    /** Live preview of the text selected with the select pad. */
    fun setSelectionPreview(text: String) {
        selCount = text.length
        selPreview = TextLogic.clipPreview(text, 160)
        if (selT > 0f) invalidate()
    }

    fun playOpening() {
        if (!prefs.openingActive || reducedMotion()) {
            openRequested = false
            return
        }
        openRequested = true
        startOpeningIfReady()
    }

    fun onHidden() {
        cancelAllTouches()
        openAnimator?.cancel()
        opening = false
        openRequested = false
        exitSelect(false, false)
        marks.clear()
        if (panelOpen) closePanel()
    }

    fun cancelAllTouches() {
        for (i in 0 until ptrs.size()) cancelPointer(ptrs.valueAt(i))
        ptrs.clear()
        spaceMode = 0
        invalidate()
    }

    // ---------------------------------------------------------------- layout

    private fun dp(v: Float): Float = v * density

    private fun computeMetrics() {
        val dm = resources.displayMetrics
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val screenHdp = dm.heightPixels / density
        val mult = when (prefs.heightMode) {
            KeyboardPrefs.HEIGHT_COMPACT -> 0.88f
            KeyboardPrefs.HEIGHT_TALL -> 1.12f
            else -> 1f
        }
        val base = if (landscape) (screenHdp * 0.115f).coerceIn(34f, 46f)
        else (screenHdp * 0.066f).coerceIn(44f, 58f)
        keyH = dp(base * mult)
        gap = dp(5f)
        sidePad = dp(3f)
        toolbarH = if (prefs.showToolbar) dp(42f) else dp(6f)
        rowsTop = toolbarH
        bottomPad = dp(6f) + bottomInset
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        computeMetrics()
        var w = MeasureSpec.getSize(widthMeasureSpec)
        if (w <= 0) w = resources.displayMetrics.widthPixels
        val h = (rowsTop + 4f * (keyH + gap) + bottomPad).toInt()
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        buildGeometry()
        startOpeningIfReady()
    }

    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        // Only needed when the window is drawn edge-to-edge (target SDK 35+). Below that the
        // framework already places the keyboard above the navigation bar.
        val edgeToEdge = Build.VERSION.SDK_INT >= 35 && context.applicationInfo.targetSdkVersion >= 35
        val inset = if (edgeToEdge && Build.VERSION.SDK_INT >= 30) {
            insets.getInsets(WindowInsets.Type.navigationBars()).bottom.toFloat()
        } else {
            0f
        }
        if (inset != bottomInset) {
            bottomInset = inset
            requestLayout()
        }
        return super.onApplyWindowInsets(insets)
    }

    private fun finish(g: KeyGeom) {
        g.cx = g.face.centerX()
        g.cy = g.face.centerY()
    }

    private fun buildGeometry() {
        if (width <= 0) return
        computeMetrics()
        geoms.clear()
        toolGeoms.clear()
        val rows = KeyboardLayouts.rows(page, layoutOptions)
        val usableW = width - 2f * sidePad
        val rowCell = keyH + gap
        for ((r, row) in rows.withIndex()) {
            val spans = KeyboardLayouts.spans(row, usableW)
            for ((i, key) in row.withIndex()) {
                if (key.type == KeyType.SPACER) continue
                val g = KeyGeom(key)
                val left = sidePad + spans[2 * i]
                val top = rowsTop + r * rowCell
                g.cell.set(left, top, left + spans[2 * i + 1], top + rowCell)
                g.face.set(
                    g.cell.left + gap / 2f, g.cell.top + gap / 2f,
                    g.cell.right - gap / 2f, g.cell.bottom - gap / 2f
                )
                g.rowIndex = r
                finish(g)
                geoms.add(g)
            }
        }
        spaceGeom = geoms.firstOrNull { it.key.type == KeyType.SPACE }

        val pg = KeyGeom(Key(KeyType.PAD))
        pg.cell.set(
            sidePad + dp(8f), rowsTop + dp(8f),
            width - sidePad - dp(8f), rowsTop + 4f * rowCell - dp(8f)
        )
        pg.face.set(pg.cell)
        finish(pg)
        padGeom = pg

        if (prefs.showToolbar) {
            val tools = KeyboardLayouts.toolbar
            val w = width.toFloat() / tools.size
            for ((i, key) in tools.withIndex()) {
                val g = KeyGeom(key)
                g.cell.set(i * w, 0f, (i + 1) * w, toolbarH)
                g.face.set(g.cell.left + dp(3f), dp(3f), g.cell.right - dp(3f), toolbarH - dp(3f))
                finish(g)
                toolGeoms.add(g)
            }
        }
        computeOrigins()
        if (panelOpen) buildPanel()
    }

    /**
     * Card-shuffle choreography. All keys wait as two loose piles in the bottom corners; keys
     * then leave the piles alternately (like a riffle shuffle) in a fixed scrambled order and
     * arc into place.
     */
    private fun computeOrigins() {
        val n = geoms.size
        bySeq.clear()
        if (n == 0) return
        val perm = IntArray(n) { it }
        var seed = 20261122L
        for (i in n - 1 downTo 1) {
            seed = (seed * 1103515245L + 12345L) and 0x7fffffffL
            val j = (seed % (i + 1)).toInt()
            val t = perm[i]
            perm[i] = perm[j]
            perm[j] = t
        }
        val w = width.toFloat()
        val h = height.toFloat()
        val pileY = h - bottomPad - keyH * 0.75f
        val pileInset = dp(36f)
        for (k in 0 until n) {
            val g = geoms[perm[k]]
            g.seq = k
            bySeq.add(g)
            val left = k % 2 == 0
            val depth = (k / 2).toFloat()
            seed = (seed * 1103515245L + 12345L) and 0x7fffffffL
            val r1 = (seed % 1000L) / 1000f - 0.5f
            seed = (seed * 1103515245L + 12345L) and 0x7fffffffL
            val r2 = (seed % 1000L) / 1000f - 0.5f
            g.startX = (if (left) pileInset else w - pileInset) + r1 * dp(8f)
            g.startY = pileY + r2 * dp(8f) + depth * dp(0.25f)
            g.startRot = (if (left) -1f else 1f) * (5f + (r1 + 0.5f) * 11f)
            g.arcSign = if (left) -1f else 1f
            g.delay = if (n > 1) k.toFloat() / (n - 1) * MAX_DELAY_MS else 0f
        }
    }

    private fun buildPanel() {
        panelGeoms.clear()
        if (width <= 0) return
        val areaH = 4f * (keyH + gap)
        val cellH = areaH / 5f
        val shown = min(4, clips.size)
        for (i in 0 until shown) {
            val text = clips[i]
            val g = KeyGeom(Key(KeyType.CLIP_ITEM, TextLogic.clipPreview(text), 1f, emptyList(), text))
            g.cell.set(sidePad, rowsTop + i * cellH, width - sidePad, rowsTop + (i + 1) * cellH)
            insetFace(g)
            panelGeoms.add(g)
        }
        val y0 = rowsTop + 4f * cellH
        val mid = width / 2f
        val back = KeyGeom(Key(KeyType.PANEL_BACK, "Keys"))
        back.cell.set(sidePad, y0, mid, y0 + cellH)
        insetFace(back)
        panelGeoms.add(back)
        val clear = KeyGeom(Key(KeyType.PANEL_CLEAR, "Clear history"))
        clear.cell.set(mid, y0, width - sidePad, y0 + cellH)
        insetFace(clear)
        panelGeoms.add(clear)
    }

    private fun insetFace(g: KeyGeom) {
        g.face.set(
            g.cell.left + gap / 2f, g.cell.top + gap / 2f,
            g.cell.right - gap / 2f, g.cell.bottom - gap / 2f
        )
        finish(g)
    }

    private fun closePanel() {
        panelOpen = false
        panelGeoms.clear()
        invalidate()
    }

    // ---------------------------------------------------------------- opening animation

    private fun reducedMotion(): Boolean = try {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    } catch (e: Exception) {
        false
    }

    private fun startOpeningIfReady() {
        if (!openRequested || width <= 0 || geoms.isEmpty()) return
        openRequested = false
        openAnimator?.cancel()
        val total = OPEN_TOTAL_MS
        val a = ValueAnimator.ofFloat(0f, total)
        a.duration = total.toLong()
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            openElapsed = it.animatedValue as Float
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                opening = false
                openElapsed = total
                invalidate()
            }
        })
        openElapsed = 0f
        opening = true
        openAnimator = a
        a.start()
    }

    private fun startSettle() {
        if (opening || !prefs.effects) return
        settleStart = SystemClock.uptimeMillis()
    }

    override fun onDetachedFromWindow() {
        openAnimator?.cancel()
        selAnimator?.cancel()
        ui.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    // ---------------------------------------------------------------- selection pad

    private fun animateSel(target: Float, ms: Long) {
        selAnimator?.cancel()
        if (ms <= 0L || !prefs.effects) {
            selT = target
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(selT, target)
        a.duration = ms
        a.interpolator = selInterp
        a.addUpdateListener {
            selT = it.animatedValue as Float
            invalidate()
        }
        selAnimator = a
        a.start()
    }

    private fun enterSelect() {
        if (selectUi) return
        selectUi = true
        selPreview = ""
        selCount = 0
        listener.onSelectionGesture(true)
        animateSel(1f, 340L)
    }

    private fun exitSelect(copy: Boolean, animate: Boolean) {
        if (!selectUi) {
            if (!animate && selT != 0f) animateSel(0f, 0L)
            return
        }
        selectUi = false
        if (copy) listener.onTool("copy")
        listener.onSelectionGesture(false)
        spaceMode = 0
        selPreview = ""
        selCount = 0
        animateSel(0f, if (animate) 300L else 0L)
    }

    // ---------------------------------------------------------------- drawing

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 16f else (now - lastFrame).coerceIn(1L, 48L).toFloat()
        var animating = false
        for (g in geoms) if (stepGeom(g, dt)) animating = true
        for (g in toolGeoms) if (stepGeom(g, dt)) animating = true
        for (g in panelGeoms) if (stepGeom(g, dt)) animating = true

        canvas.drawColor(palette.bg)

        var settle = 1f
        if (!opening && settleStart != 0L) {
            val t = ((now - settleStart) / SETTLE_MS).coerceIn(0f, 1f)
            settle = 1f - (1f - t) * (1f - t)
            if (t >= 1f) settleStart = 0L else animating = true
        }

        if (prefs.showToolbar) {
            val a = if (opening) ((openElapsed - 500f) / 300f).coerceIn(0f, 1f) else 1f
            if (a > 0f) for (g in toolGeoms) drawToolbarItem(canvas, g, a)
        }

        if (panelOpen) {
            if (clips.isEmpty()) {
                drawLabel(
                    canvas, "Nothing copied yet", width / 2f, rowsTop + 4f * (keyH + gap) * 0.32f,
                    keyH * 0.3f, palette.textDim, 1f, tfRegular
                )
            }
            for (g in panelGeoms) drawKey(canvas, g, 0f, 0f, 1f, 1f, 0f)
        } else if (opening) {
            drawOpening(canvas)
        } else if (selT > 0f) {
            drawSelectionKeys(canvas)
            drawPad(canvas)
        } else {
            for (g in geoms) drawKeyAnimated(canvas, g, settle)
        }

        if (drawMarks(canvas, now)) animating = true

        for (i in 0 until ptrs.size()) {
            val pop = ptrs.valueAt(i).popup
            if (pop != null && drawPopup(canvas, pop, now)) animating = true
        }

        lastFrame = if (animating) now else 0L
        if (animating && !opening) postInvalidateOnAnimation()
    }

    private fun stepGeom(g: KeyGeom, dt: Float): Boolean {
        if (g.press == g.pressTarget) return false
        if (!prefs.effects) {
            g.press = g.pressTarget
            return false
        }
        g.press = if (g.press < g.pressTarget) min(g.pressTarget, g.press + dt / 40f)
        else max(g.pressTarget, g.press - dt / 140f)
        return g.press != g.pressTarget
    }

    private fun landed(g: KeyGeom): Boolean = openElapsed - g.delay >= FLIGHT_MS

    private fun drawOpening(canvas: Canvas) {
        val pileAlpha = (openElapsed / 140f).coerceIn(0f, 1f)
        val n = bySeq.size
        for (i in n - 1 downTo 0) {
            val g = bySeq[i]
            if (landed(g)) drawKey(canvas, g, 0f, 0f, 1f, 1f, 0f)
        }
        for (i in n - 1 downTo 0) {
            val g = bySeq[i]
            if (landed(g)) continue
            val t = ((openElapsed - g.delay) / FLIGHT_MS).coerceIn(0f, 1f)
            if (t <= 0f) {
                drawKey(canvas, g, g.startX - g.cx, g.startY - g.cy, 0.82f, pileAlpha, g.startRot)
            } else {
                val e = openInterp.getInterpolation(t)
                val dx0 = g.cx - g.startX
                val dy0 = g.cy - g.startY
                val len = max(1f, hypot(dx0, dy0))
                val bulge = sin(PI_F * e) * len * 0.12f * g.arcSign
                val px = g.startX + dx0 * e + (-dy0 / len) * bulge
                val py = g.startY + dy0 * e + (dx0 / len) * bulge
                drawKey(canvas, g, px - g.cx, py - g.cy, 0.82f + 0.18f * e, 1f, g.startRot * (1f - e))
            }
        }
    }

    private fun drawKeyAnimated(canvas: Canvas, g: KeyGeom, settle: Float) {
        if (settle < 1f) {
            drawKey(canvas, g, 0f, 0f, 0.94f + 0.06f * settle, 0.5f + 0.5f * settle, 0f)
        } else {
            drawKey(canvas, g, 0f, 0f, 1f, 1f, 0f)
        }
    }

    private fun drawSelectionKeys(canvas: Canvas) {
        val s = 1f - 0.45f * selT
        val a = 1f - selT
        for (g in geoms) {
            if (g.key.type == KeyType.SPACE) {
                if (a > 0.03f) drawKey(canvas, g, 0f, 0f, 1f, a, 0f)
                continue
            }
            if (a > 0.03f) drawKey(canvas, g, 0f, 0f, s, a, 0f)
            drawGhost(canvas, g, s, selT)
        }
    }

    /** Cheap stand-in for blur: a few soft, offset, low-alpha copies of the shrunken key. */
    private fun drawGhost(canvas: Canvas, g: KeyGeom, s: Float, t: Float) {
        val hw = g.face.width() * s / 2f
        val hh = g.face.height() * s / 2f
        val o = dp(2.2f) * t
        val ghost = lerpColor(palette.key, palette.text, 0.2f)
        facePaint.color = withAlpha(ghost, 0.16f * t)
        val r = cornerRadius * s * 1.3f
        for (i in 0 until 5) {
            val ox = if (i == 1) o else if (i == 2) -o else 0f
            val oy = if (i == 3) o else if (i == 4) -o else 0f
            tmp.set(g.cx - hw + ox, g.cy - hh + oy, g.cx + hw + ox, g.cy + hh + oy)
            canvas.drawRoundRect(tmp, r, r, facePaint)
        }
        if (g.key.type == KeyType.CHAR) {
            val label = if (g.key.isLetter && shift != ShiftState.OFF) g.key.label.uppercase() else g.key.label
            val size = keyH * 0.40f * s
            drawLabel(canvas, label, g.cx - o, g.cy, size, palette.text, 0.09f * t, tfRegular)
            drawLabel(canvas, label, g.cx + o, g.cy, size, palette.text, 0.09f * t, tfRegular)
        }
    }

    private fun drawPad(canvas: Canvas) {
        val sp = spaceGeom ?: return
        val pg = padGeom ?: return
        val t = selT
        val a = min(1f, t * 3f)
        padRect.set(
            sp.face.left + (pg.face.left - sp.face.left) * t,
            sp.face.top + (pg.face.top - sp.face.top) * t,
            sp.face.right + (pg.face.right - sp.face.right) * t,
            sp.face.bottom + (pg.face.bottom - sp.face.bottom) * t
        )
        val r = cornerRadius + (dp(18f) - cornerRadius) * t

        tmp.set(padRect.left, padRect.top + dp(3f), padRect.right, padRect.bottom + dp(3f))
        shadowPaint.color = withAlpha(palette.shadow, a)
        canvas.drawRoundRect(tmp, r, r, shadowPaint)

        facePaint.color = withAlpha(lerpColor(palette.key, palette.accent, 0.10f * t), a * (1f - 0.1f * t))
        canvas.drawRoundRect(padRect, r, r, facePaint)

        highlightPaint.strokeWidth = dp(1.4f)
        highlightPaint.color = withAlpha(palette.accent, a * 0.75f * t)
        tmp.set(padRect.left + dp(0.7f), padRect.top + dp(0.7f), padRect.right - dp(0.7f), padRect.bottom - dp(0.7f))
        canvas.drawRoundRect(tmp, r, r, highlightPaint)

        if (t > 0.55f) {
            val ca = ((t - 0.55f) / 0.45f).coerceIn(0f, 1f)
            val cx = padRect.centerX()
            tmp.set(cx - dp(20f), padRect.top + dp(9f), cx + dp(20f), padRect.top + dp(13f))
            facePaint.color = withAlpha(palette.textDim, ca * 0.6f)
            canvas.drawRoundRect(tmp, dp(2f), dp(2f), facePaint)

            drawLabel(
                canvas, "slide to select  \u00B7  flick down to close  \u00B7  double-tap to copy",
                cx, padRect.top + dp(32f), keyH * 0.2f, palette.textDim, ca, tfRegular
            )
            val maxW = padRect.width() - dp(32f)
            if (selPreview.isEmpty()) {
                drawLabel(canvas, "nothing selected yet", cx, padRect.centerY(), keyH * 0.3f, palette.textDim, ca * 0.8f, tfRegular)
            } else {
                drawLabel(canvas, "$selCount selected", cx, padRect.centerY() - dp(14f), keyH * 0.26f, palette.accent, ca, tfMedium)
                drawEllipsized(canvas, selPreview, cx, padRect.centerY() + dp(14f), keyH * 0.32f, palette.text, ca, tfType, maxW)
            }
        }
    }

    private fun drawMarks(canvas: Canvas, now: Long): Boolean {
        if (marks.isEmpty()) return false
        var i = marks.size - 1
        while (i >= 0) {
            val m = marks[i]
            val p = (now - m.start) / MARK_MS
            if (p >= 1f) {
                marks.removeAt(i)
                i--
                continue
            }
            val e = 1f - (1f - p) * (1f - p)
            canvas.save()
            canvas.clipRect(m.face)
            highlightPaint.strokeWidth = dp(1.5f)
            highlightPaint.color = withAlpha(palette.accent, (1f - p) * 0.6f)
            val rad = dp(4f) + max(m.face.width(), m.face.height()) * 0.6f * e
            canvas.drawCircle(m.x, m.y, rad, highlightPaint)
            facePaint.color = withAlpha(palette.accent, (1f - p) * 0.85f)
            canvas.drawCircle(m.x, m.y, dp(3f) * (1f - p) + dp(0.6f), facePaint)
            canvas.restore()
            i--
        }
        return marks.isNotEmpty()
    }

    private fun addMark(g: KeyGeom, x: Float, y: Float) {
        if (!prefs.markActive) return
        if (g.key.type == KeyType.PAD) return
        if (marks.size >= 10) marks.removeAt(0)
        marks.add(Mark(x, y, RectF(g.face), SystemClock.uptimeMillis()))
        invalidate()
    }

    private fun isAccentFace(g: KeyGeom): Boolean {
        val type = g.key.type
        return type == KeyType.ENTER || (type == KeyType.SHIFT && shift == ShiftState.LOCK)
    }

    private fun faceColor(g: KeyGeom): Int {
        val type = g.key.type
        val base: Int
        val down: Int
        if (isAccentFace(g)) {
            base = palette.accent
            down = palette.accentDown
        } else if (type == KeyType.CHAR || type == KeyType.SPACE || type == KeyType.CLIP_ITEM) {
            base = palette.key
            down = palette.keyDown
        } else {
            base = palette.keyFunc
            down = palette.keyFuncDown
        }
        var c = lerpColor(base, down, g.press)
        if (type == KeyType.SPACE && spaceMode != 0) c = lerpColor(c, palette.accent, 0.28f)
        return c
    }

    /** Metal-ring colour of the keycap, always a little different from the dish inside it. */
    private fun rimColor(g: KeyGeom): Int {
        if (isAccentFace(g)) return palette.accentDown
        val type = g.key.type
        val base = if (type == KeyType.CHAR || type == KeyType.SPACE || type == KeyType.CLIP_ITEM) palette.key else palette.keyFunc
        return lerpColor(base, if (palette.dark) Color.WHITE else Color.BLACK, 0.12f)
    }

    /** Typewriter keycap: soft double shadow, metal rim, dished face with inner edge shading. */
    private fun drawKey(canvas: Canvas, g: KeyGeom, dx: Float, dy: Float, scale: Float, alpha: Float, rot: Float) {
        val p = g.press
        val f = g.face
        val r = cornerRadius
        canvas.save()
        canvas.translate(dx, dy + p * dp(1.1f))
        if (rot != 0f) canvas.rotate(rot, g.cx, g.cy)
        val s = scale * (1f - 0.035f * p)
        canvas.scale(s, s, g.cx, g.cy)

        val so = dp(1.6f) * (1f - 0.6f * p)
        shadowPaint.color = withAlpha(palette.shadow, alpha * 0.5f)
        tmp.set(f.left, f.top + so * 1.9f, f.right, f.bottom + so * 1.9f)
        canvas.drawRoundRect(tmp, r, r, shadowPaint)
        shadowPaint.color = withAlpha(palette.shadow, alpha)
        tmp.set(f.left, f.top + so, f.right, f.bottom + so)
        canvas.drawRoundRect(tmp, r, r, shadowPaint)

        facePaint.color = withAlpha(rimColor(g), alpha)
        canvas.drawRoundRect(f, r, r, facePaint)

        val inset = dp(2.4f)
        val dr = max(1f, r - inset * 0.5f)
        dish.set(f.left + inset, f.top + inset, f.right - inset, f.bottom - inset)
        facePaint.color = withAlpha(faceColor(g), alpha)
        canvas.drawRoundRect(dish, dr, dr, facePaint)

        // inner shadow along the top lip, light catching the bottom lip
        highlightPaint.strokeWidth = dp(1.6f)
        tmp.set(dish.left + dp(0.8f), dish.top + dp(0.8f), dish.right - dp(0.8f), dish.bottom - dp(0.8f))
        canvas.save()
        canvas.clipRect(dish.left, dish.top, dish.right, dish.top + dp(6f))
        highlightPaint.color = withAlpha(palette.dishShade, alpha)
        canvas.drawRoundRect(tmp, dr, dr, highlightPaint)
        canvas.restore()
        canvas.save()
        canvas.clipRect(dish.left, dish.bottom - dp(5f), dish.right, dish.bottom)
        highlightPaint.color = withAlpha(palette.highlight, alpha * (1f - p))
        canvas.drawRoundRect(tmp, dr, dr, highlightPaint)
        canvas.restore()

        drawKeyContent(canvas, g, alpha)
        canvas.restore()
    }

    private fun drawKeyContent(canvas: Canvas, g: KeyGeom, alpha: Float) {
        val key = g.key
        val cx = g.cx
        val cy = g.cy
        when (key.type) {
            KeyType.CHAR -> {
                val label = if (key.isLetter && shift != ShiftState.OFF) key.label.uppercase() else key.label
                val size = keyH * 0.42f
                drawLabel(canvas, label, cx, cy + dp(0.9f), size, palette.engrave, alpha, tfType)
                drawLabel(canvas, label, cx, cy, size, palette.text, alpha, tfType)
            }
            KeyType.SHIFT -> {
                val locked = shift == ShiftState.LOCK
                val col = if (locked) palette.onAccent else palette.text
                drawIcon(canvas, Icons.shift, cx, cy - dp(1f), keyH * 0.2f, col, alpha, shift != ShiftState.OFF, false)
                if (locked) drawIcon(canvas, Icons.lockBar, cx, cy - dp(1f), keyH * 0.2f, col, alpha, false, false)
            }
            KeyType.BACKSPACE -> {
                drawIcon(canvas, Icons.backspace, cx, cy, keyH * 0.23f, palette.text, alpha, false, false)
                drawIcon(canvas, Icons.backspaceX, cx, cy, keyH * 0.23f, palette.text, alpha, false, false)
            }
            KeyType.ENTER -> {
                val label = enterLabel
                if (label != null) {
                    drawLabel(canvas, label.take(8), cx, cy, keyH * 0.27f, palette.onAccent, alpha, tfMedium)
                } else {
                    drawIcon(canvas, Icons.enter, cx, cy, keyH * 0.21f, palette.onAccent, alpha, false, false)
                }
            }
            KeyType.SPACE -> {
                if (spaceMode == 1) {
                    drawLabel(canvas, "\u2039   \u203A", cx, cy, keyH * 0.34f, palette.text, alpha, tfRegular)
                }
            }
            KeyType.MODE_NUMBERS, KeyType.MODE_LETTERS, KeyType.MODE_SYMBOLS ->
                drawLabel(canvas, key.label, cx, cy, keyH * 0.27f, palette.text, alpha, tfMedium)
            KeyType.NEXT_IME ->
                drawIcon(canvas, Icons.globe, cx, cy, keyH * 0.2f, palette.text, alpha, false, false)
            KeyType.CLIP_ITEM -> {
                textPaint.textSize = keyH * 0.30f
                textPaint.typeface = tfRegular
                textPaint.color = withAlpha(palette.text, alpha)
                textPaint.textAlign = Paint.Align.LEFT
                val avail = g.face.width() - dp(28f)
                val shown = TextUtils.ellipsize(key.label, textPaint, avail, TextUtils.TruncateAt.END).toString()
                val fm = textPaint.fontMetrics
                canvas.drawText(shown, g.face.left + dp(14f), cy - (fm.ascent + fm.descent) / 2f, textPaint)
                textPaint.textAlign = Paint.Align.CENTER
            }
            KeyType.PANEL_BACK, KeyType.PANEL_CLEAR ->
                drawLabel(canvas, key.label, cx, cy, keyH * 0.27f, palette.text, alpha, tfMedium)
            else -> {}
        }
    }

    private fun drawToolbarItem(canvas: Canvas, g: KeyGeom, alpha: Float) {
        val p = g.press
        if (p > 0f) {
            facePaint.color = withAlpha(palette.keyFunc, alpha * p)
            canvas.drawRoundRect(g.face, cornerRadius, cornerRadius, facePaint)
        }
        val active = g.key.id == "clipboard" && panelOpen
        val col = if (active) palette.accent else lerpColor(palette.textDim, palette.text, p)
        val cx = g.face.centerX()
        val cy = g.face.centerY()
        val size = dp(8.5f)
        when (g.key.id) {
            "select_all" -> {
                drawIcon(canvas, Icons.selectBox, cx, cy, size, col, alpha, false, true)
                drawIcon(canvas, Icons.selectLines, cx, cy, size, col, alpha, false, false)
            }
            "copy" -> drawIcon(canvas, Icons.copy, cx, cy, size, col, alpha, false, false)
            "cut" -> drawIcon(canvas, Icons.cut, cx, cy, size, col, alpha, false, false)
            "paste" -> drawIcon(canvas, Icons.paste, cx, cy, size, col, alpha, false, false)
            "clipboard" -> drawIcon(canvas, Icons.clipList, cx, cy, size, col, alpha, false, false)
            "settings" -> drawIcon(canvas, Icons.gear, cx, cy, size, col, alpha, false, false)
            "hide" -> drawIcon(canvas, Icons.chevronDown, cx, cy, size, col, alpha, false, false)
        }
    }

    private fun drawLabel(
        canvas: Canvas, text: String, cx: Float, cy: Float, size: Float,
        color: Int, alpha: Float, face: Typeface
    ) {
        textPaint.textSize = size
        textPaint.typeface = face
        textPaint.color = withAlpha(color, alpha)
        val fm = textPaint.fontMetrics
        canvas.drawText(text, cx, cy - (fm.ascent + fm.descent) / 2f, textPaint)
    }

    private fun drawEllipsized(
        canvas: Canvas, text: String, cx: Float, cy: Float, size: Float,
        color: Int, alpha: Float, face: Typeface, maxWidth: Float
    ) {
        textPaint.textSize = size
        textPaint.typeface = face
        textPaint.color = withAlpha(color, alpha)
        val shown = TextUtils.ellipsize(text, textPaint, maxWidth, TextUtils.TruncateAt.END).toString()
        val fm = textPaint.fontMetrics
        canvas.drawText(shown, cx, cy - (fm.ascent + fm.descent) / 2f, textPaint)
    }

    private fun drawIcon(
        canvas: Canvas, path: Path, cx: Float, cy: Float, size: Float,
        color: Int, alpha: Float, fill: Boolean, dashed: Boolean
    ) {
        val paint = if (dashed) dashStroke else iconStroke
        canvas.save()
        canvas.translate(cx, cy)
        canvas.scale(size, size)
        if (fill) {
            iconFill.color = withAlpha(color, alpha)
            canvas.drawPath(path, iconFill)
        }
        paint.color = withAlpha(color, alpha)
        paint.strokeWidth = dp(1.7f) / size
        canvas.drawPath(path, paint)
        canvas.restore()
    }

    /** Draws the long-press grid; returns true while its pop-in animation is still running. */
    private fun drawPopup(canvas: Canvas, pop: Popup, now: Long): Boolean {
        val age = ((now - pop.born) / POPUP_MS).coerceIn(0f, 1f)
        val e = 1f - (1f - age) * (1f - age)
        var l = Float.MAX_VALUE
        var t = Float.MAX_VALUE
        var rr = -Float.MAX_VALUE
        var b = -Float.MAX_VALUE
        for (rect in pop.rects) {
            l = min(l, rect.left)
            t = min(t, rect.top)
            rr = max(rr, rect.right)
            b = max(b, rect.bottom)
        }
        val pad = dp(4f)
        val sc = if (prefs.effects) 0.88f + 0.12f * e else 1f
        val al = if (prefs.effects) e else 1f
        canvas.save()
        canvas.scale(sc, sc, (l + rr) / 2f, b)

        val rad = cornerRadius + pad
        tmp.set(l - pad, t - pad + dp(2f), rr + pad, b + pad + dp(2f))
        shadowPaint.color = withAlpha(palette.shadow, al)
        canvas.drawRoundRect(tmp, rad, rad, shadowPaint)
        tmp.set(l - pad, t - pad, rr + pad, b + pad)
        facePaint.color = withAlpha(palette.popup, al)
        canvas.drawRoundRect(tmp, rad, rad, facePaint)
        highlightPaint.strokeWidth = dp(1f)
        highlightPaint.color = withAlpha(palette.accent, al * 0.5f)
        canvas.drawRoundRect(tmp, rad, rad, highlightPaint)

        for ((i, rect) in pop.rects.withIndex()) {
            val selected = i == pop.index
            tmp.set(rect.left + dp(1.5f), rect.top + dp(1.5f), rect.right - dp(1.5f), rect.bottom - dp(1.5f))
            if (selected) {
                facePaint.color = withAlpha(palette.accent, al)
                canvas.drawRoundRect(tmp, cornerRadius, cornerRadius, facePaint)
            }
            drawLabel(
                canvas, pop.items[i], tmp.centerX(), tmp.centerY(),
                min(tmp.height() * 0.52f, keyH * 0.42f),
                if (selected) palette.onAccent else palette.text, al, tfMedium
            )
        }
        canvas.restore()
        return age < 1f
    }

    // ---------------------------------------------------------------- touch

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                pointerDown(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) pointerMove(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                pointerUp(e.getPointerId(e.actionIndex))
            }
            MotionEvent.ACTION_CANCEL -> cancelAllTouches()
        }
        return true
    }

    private fun hitTest(x: Float, y: Float): KeyGeom? {
        if (y < rowsTop) {
            if (!prefs.showToolbar) return null
            for (g in toolGeoms) if (x >= g.cell.left && x < g.cell.right) return g
            return null
        }
        val rowCell = keyH + gap
        if (y > rowsTop + 4f * rowCell + dp(2f)) return null
        if (selectUi) {
            val pg = padGeom ?: return null
            return if (pg.cell.contains(x, y)) pg else null
        }
        if (panelOpen) {
            for (g in panelGeoms) if (g.cell.contains(x, y)) return g
            return null
        }
        val r = ((y - rowsTop) / rowCell).toInt().coerceIn(0, 3)
        var best: KeyGeom? = null
        var bestD = Float.MAX_VALUE
        for (g in geoms) {
            if (g.rowIndex != r) continue
            val d = if (x < g.cell.left) g.cell.left - x else if (x > g.cell.right) x - g.cell.right else 0f
            if (d < bestD) {
                bestD = d
                best = g
            }
        }
        return best
    }

    private fun press(g: KeyGeom, down: Boolean) {
        g.pressTarget = if (down) 1f else 0f
        invalidate()
    }

    private fun longPressDelay(key: Key): Long =
        if (key.label == "." || key.label == ",") PUNCT_LONG_PRESS_MS else LONG_PRESS_MS

    private fun pointerDown(id: Int, x: Float, y: Float) {
        val g = hitTest(x, y) ?: return
        ptrs.get(id)?.let { cancelPointer(it) }
        val p = Ptr(id, g)
        p.downX = x
        p.downY = y
        p.lastX = x
        p.lastY = y
        p.downTime = SystemClock.uptimeMillis()
        ptrs.put(id, p)
        press(g, true)
        addMark(g, x, y)

        val type = g.key.type
        listener.onFeedback(type, false)
        when (type) {
            KeyType.BACKSPACE -> {
                listener.onBackspace(0)
                ui.postDelayed(p.repeatRunnable, TextLogic.BACKSPACE_INITIAL_DELAY)
            }
            KeyType.SHIFT -> handleShift()
            KeyType.MODE_NUMBERS -> switchPage(Page.NUMBERS)
            KeyType.MODE_LETTERS -> switchPage(Page.LETTERS)
            KeyType.MODE_SYMBOLS -> switchPage(Page.SYMBOLS)
            KeyType.SPACE -> ui.postDelayed(p.longPress, SELECT_HOLD_MS)
            KeyType.PAD -> p.mode = 3
            KeyType.CHAR -> if (prefs.longPressAlternates && g.key.alts.isNotEmpty()) {
                ui.postDelayed(p.longPress, longPressDelay(g.key))
            }
            else -> {}
        }
    }

    private fun pointerMove(id: Int, x: Float, y: Float) {
        val p = ptrs.get(id) ?: return
        val pop = p.popup
        if (pop != null) {
            val idx = popupIndexAt(pop, x, y)
            if (idx != pop.index) {
                pop.index = idx
                listener.onHapticStep()
                invalidate()
            }
            p.lastX = x
            p.lastY = y
            return
        }
        when (p.geom.key.type) {
            KeyType.SPACE -> spaceMove(p, x, y)
            KeyType.PAD -> padMove(p, x, y)
            KeyType.CHAR -> {
                val g = hitTest(x, y)
                if (g != null && g !== p.geom && g.key.type == KeyType.CHAR) switchKey(p, g)
            }
            else -> {}
        }
        p.lastX = x
        p.lastY = y
    }

    private fun pointerUp(id: Int) {
        val p = ptrs.get(id) ?: return
        ptrs.remove(id)
        ui.removeCallbacks(p.longPress)
        ui.removeCallbacks(p.repeatRunnable)
        press(p.geom, false)

        val pop = p.popup
        if (pop != null) {
            commitText(pop.items[pop.index])
            invalidate()
            return
        }
        val key = p.geom.key
        when (key.type) {
            KeyType.CHAR -> commitText(
                if (key.isLetter && shift != ShiftState.OFF) key.label.uppercase() else key.label
            )
            KeyType.SPACE -> {
                if (p.mode == 0) {
                    listener.onSpace()
                } else {
                    // Cursor mode ends; the select pad (mode 2) stays open until closed.
                    spaceMode = 0
                    invalidate()
                }
            }
            KeyType.PAD -> padUp(p)
            KeyType.ENTER -> listener.onEnter()
            KeyType.NEXT_IME -> listener.onNextIme()
            KeyType.TOOL -> {
                if (key.id == "clipboard" && panelOpen) closePanel() else listener.onTool(key.id)
            }
            KeyType.CLIP_ITEM -> {
                listener.onClipPick(key.id)
                closePanel()
            }
            KeyType.PANEL_BACK -> closePanel()
            KeyType.PANEL_CLEAR -> {
                listener.onClipClear()
                clips = emptyList()
                buildPanel()
                invalidate()
            }
            else -> {}
        }
    }

    private fun cancelPointer(p: Ptr) {
        ui.removeCallbacks(p.longPress)
        ui.removeCallbacks(p.repeatRunnable)
        press(p.geom, false)
    }

    private fun commitText(text: String) {
        // Consume one-shot shift *before* notifying, so the service can re-arm auto-capitalisation.
        if (shift == ShiftState.ONCE) {
            shift = ShiftState.OFF
            invalidate()
        }
        listener.onText(text)
    }

    private fun handleShift() {
        val now = SystemClock.uptimeMillis()
        shift = TextLogic.nextShift(shift, now - lastShiftTap)
        lastShiftTap = now
        invalidate()
    }

    private fun switchPage(newPage: Page) {
        if (newPage == page) return
        if (panelOpen) closePanel()
        page = newPage
        buildGeometry()
        startSettle()
        invalidate()
    }

    private fun switchKey(p: Ptr, g: KeyGeom) {
        ui.removeCallbacks(p.longPress)
        press(p.geom, false)
        p.geom = g
        press(g, true)
        if (prefs.longPressAlternates && g.key.alts.isNotEmpty()) {
            ui.postDelayed(p.longPress, longPressDelay(g.key))
        }
    }

    private fun onLongPress(p: Ptr) {
        if (ptrs.get(p.id) !== p) return
        when (p.geom.key.type) {
            KeyType.SPACE -> {
                if (p.mode == 0) {
                    p.mode = 2
                    p.acc.reset()
                    p.accY.reset()
                    enterSelect()
                    listener.onHapticStep()
                    invalidate()
                }
            }
            KeyType.CHAR -> showPopup(p)
            else -> {}
        }
    }

    private fun spaceMove(p: Ptr, x: Float, y: Float) {
        if (p.mode == 2) {
            selectionMove(p, x, y)
            return
        }
        val step = dp(TextLogic.cursorStepDp(prefs.cursorSensitivity))
        val n: Int
        if (p.mode == 0) {
            if (abs(x - p.downX) < dp(10f)) return
            p.mode = 1
            spaceMode = 1
            ui.removeCallbacks(p.longPress)
            p.acc.reset()
            n = p.acc.add(x - p.downX, step)
            invalidate()
        } else {
            n = p.acc.add(x - p.lastX, step)
        }
        if (n != 0) {
            listener.onCursorMove(n, false)
            listener.onHapticStep()
        }
    }

    /** Horizontal drag extends the selection by characters, vertical drag by lines. */
    private fun selectionMove(p: Ptr, x: Float, y: Float) {
        val stepX = dp(TextLogic.cursorStepDp(prefs.cursorSensitivity))
        val nh = p.acc.add(x - p.lastX, stepX)
        val nv = p.accY.add(y - p.lastY, dp(26f))
        if (nh != 0) {
            listener.onCursorMove(nh, true)
            listener.onHapticStep()
        }
        if (nv != 0) {
            listener.onLineMove(nv, true)
            listener.onHapticStep()
        }
    }

    private fun padMove(p: Ptr, x: Float, y: Float) {
        if (!selectUi || p.done) return
        if (!p.moved && (abs(x - p.downX) > dp(8f) || abs(y - p.downY) > dp(8f))) p.moved = true
        val now = SystemClock.uptimeMillis()
        val dy = y - p.downY
        val flick = dy > dp(110f) && now - p.downTime < 280L && abs(x - p.downX) < dy * 0.7f
        val handleDrag = p.downY < padRect.top + dp(34f) && dy > dp(40f)
        if (flick || handleDrag) {
            p.done = true
            exitSelect(false, true)
            return
        }
        if (p.moved) selectionMove(p, x, y)
    }

    private fun padUp(p: Ptr) {
        if (!selectUi || p.done || p.moved) return
        val now = SystemClock.uptimeMillis()
        if (now - p.downTime > 300L) return
        val near = abs(p.downX - lastPadTapX) < dp(40f) && abs(p.downY - lastPadTapY) < dp(40f)
        if (now - lastPadTapTime < 320L && near) {
            lastPadTapTime = 0L
            exitSelect(true, true)
        } else {
            lastPadTapTime = now
            lastPadTapX = p.downX
            lastPadTapY = p.downY
        }
    }

    /** Long-press grid: first item sits next to the pressed key, more items stack upwards. */
    private fun showPopup(p: Ptr) {
        val g = p.geom
        val base = g.key.alts
        if (base.isEmpty()) return
        val items = if (shift != ShiftState.OFF && g.key.isLetter) base.map { it.uppercase() } else base
        val n = items.size
        val cols = if (n <= 5) n else (n + 1) / 2
        val rows = (n + cols - 1) / cols
        val itemW = max(g.face.width(), dp(40f))
        val itemH = min(g.face.height(), dp(48f))
        val totalW = cols * itemW
        val totalH = rows * itemH
        val dir = if (g.cx < width / 2f) 1 else -1
        var left = if (dir == 1) g.face.left else g.face.right - totalW
        left = left.coerceIn(dp(2f), max(dp(2f), width - totalW - dp(2f)))
        var bottom = g.face.top - dp(6f)
        var top = bottom - totalH
        if (top < dp(2f)) {
            top = dp(2f)
            bottom = top + totalH
        }
        val rects = Array(n) { i ->
            val c = i % cols
            val r = i / cols
            val x = if (dir == 1) left + c * itemW else left + totalW - (c + 1) * itemW
            val y = bottom - (r + 1) * itemH
            RectF(x, y, x + itemW, y + itemH)
        }
        p.popup = Popup(items, rects, SystemClock.uptimeMillis())
        listener.onHapticStep()
        invalidate()
    }

    private fun popupIndexAt(pop: Popup, x: Float, y: Float): Int {
        var best = 0
        var bestD = Float.MAX_VALUE
        for ((i, r) in pop.rects.withIndex()) {
            val dx = if (x < r.left) r.left - x else if (x > r.right) x - r.right else 0f
            val dy = if (y < r.top) r.top - y else if (y > r.bottom) y - r.bottom else 0f
            val d = dx * dx + dy * dy
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        return best
    }

    companion object {
        private const val PI_F = 3.1415927f
        private const val LONG_PRESS_MS = 380L
        private const val PUNCT_LONG_PRESS_MS = 230L
        private const val SELECT_HOLD_MS = 500L
        private const val OPEN_TOTAL_MS = 960f
        private const val FLIGHT_MS = 430f
        private const val MAX_DELAY_MS = 530f
        private const val SETTLE_MS = 150f
        private const val MARK_MS = 420f
        private const val POPUP_MS = 140f
    }
}
