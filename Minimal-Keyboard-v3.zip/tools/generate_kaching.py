#!/usr/bin/env python3
"""Synthesises the cash-register "ka-ching" used by the Heist layout's Enter key.

Pure standard library (no numpy). Writes app/src/main/res/raw/ui_kaching_1.wav
(44.1 kHz, mono, 16-bit, like the other bundled sounds).
"""
import math
import os
import random
import struct
import wave

SR = 44100
DURATION = 1.05
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "raw", "ui_kaching_1.wav")


def main() -> None:
    rnd = random.Random(7)
    n = int(SR * DURATION)
    buf = [0.0] * n

    # "ka": the drawer clunk. A short noise burst plus a falling low thump.
    low = 0.0
    for i in range(int(SR * 0.09)):
        t = i / SR
        noise = rnd.uniform(-1.0, 1.0)
        low += 0.35 * (noise - low)  # crude low-pass so it sounds like metal, not hiss
        buf[i] += 0.55 * low * math.exp(-t / 0.016)
        freq = 70.0 + 90.0 * math.exp(-t / 0.02)
        buf[i] += 0.5 * math.sin(2 * math.pi * freq * t) * math.exp(-t / 0.035)

    # "ching": two strikes of a small brass bell (slightly inharmonic partials, detuned twins).
    partials = [
        (2093.0, 1.00, 0.55),
        (2637.0, 0.70, 0.45),
        (3136.0, 0.50, 0.35),
        (4186.0, 0.35, 0.25),
        (5588.0, 0.18, 0.15),
    ]
    for start, gain in ((0.06, 1.0), (0.20, 0.7)):
        s0 = int(SR * start)
        for i in range(s0, n):
            t = (i - s0) / SR
            attack = min(1.0, t / 0.002)
            v = 0.0
            for freq, amp, tau in partials:
                env = math.exp(-t / tau)
                v += amp * env * math.sin(2 * math.pi * freq * t)
                v += 0.5 * amp * env * math.sin(2 * math.pi * freq * 1.0035 * t)
            buf[i] += 0.16 * gain * attack * v

    # gentle fade-out, then normalise
    fade = int(SR * 0.09)
    for i in range(fade):
        buf[n - 1 - i] *= i / fade
    peak = max(abs(x) for x in buf) or 1.0
    scale = 0.85 / peak

    with wave.open(OUT, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1.0, min(1.0, x * scale)) * 32767)) for x in buf))
    print("wrote", os.path.normpath(OUT), n, "frames")


if __name__ == "__main__":
    main()
