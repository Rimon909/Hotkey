package com.minimalkeyboard

import android.annotation.TargetApi
import android.content.Context
import android.graphics.Color
import android.os.Build

class Palette(
    val dark: Boolean,
    val bg: Int,
    val key: Int,
    val keyFunc: Int,
    val keyDown: Int,
    val keyFuncDown: Int,
    val text: Int,
    val textDim: Int,
    val shadow: Int,
    val highlight: Int,
    val accent: Int,
    val accentDown: Int,
    val onAccent: Int,
    val popup: Int,
    val engrave: Int,
    val dishShade: Int
) {
    companion object {
        /** Deep graphite with restrained grey keys and a single antique-brass accent. */
        val DARK = Palette(
            dark = true,
            bg = 0xFF16171A.toInt(),
            key = 0xFF303236.toInt(),
            keyFunc = 0xFF232528.toInt(),
            keyDown = 0xFF42444A.toInt(),
            keyFuncDown = 0xFF30323A.toInt(),
            text = 0xFFEDEBE6.toInt(),
            textDim = 0xFF9C9B97.toInt(),
            shadow = 0x66000000,
            highlight = 0x24FFFFFF,
            accent = 0xFFC9A66B.toInt(),
            accentDown = 0xFFA88A55.toInt(),
            onAccent = 0xFF1B1A17.toInt(),
            popup = 0xFF3A3C42.toInt(),
            engrave = 0x80000000.toInt(),
            dishShade = 0x66000000
        )

        /** Black keys with a typewriter-ribbon red accent. */
        val RIBBON = Palette(
            dark = true,
            bg = 0xFF0F0F10.toInt(),
            key = 0xFF1D1D1F.toInt(),
            keyFunc = 0xFF161617.toInt(),
            keyDown = 0xFF2B2B2E.toInt(),
            keyFuncDown = 0xFF222224.toInt(),
            text = 0xFFEFEAE0.toInt(),
            textDim = 0xFF8E8A82.toInt(),
            shadow = 0x77000000,
            highlight = 0x22FFFFFF,
            accent = 0xFFD2452B.toInt(),
            accentDown = 0xFFA83420.toInt(),
            onAccent = 0xFFFFF4EE.toInt(),
            popup = 0xFF2A2A2C.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        /** Green phosphor terminal. */
        val TERMINAL = Palette(
            dark = true,
            bg = 0xFF070D09.toInt(),
            key = 0xFF102017.toInt(),
            keyFunc = 0xFF0B160F.toInt(),
            keyDown = 0xFF1A3324.toInt(),
            keyFuncDown = 0xFF132A1C.toInt(),
            text = 0xFF8CFFB4.toInt(),
            textDim = 0xFF4F9E6C.toInt(),
            shadow = 0x88000000.toInt(),
            highlight = 0x2236FF8A,
            accent = 0xFF38E08A.toInt(),
            accentDown = 0xFF24A862.toInt(),
            onAccent = 0xFF04140A.toInt(),
            popup = 0xFF14301F.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        /** Deep navy with a cool blue accent. */
        val MIDNIGHT = Palette(
            dark = true,
            bg = 0xFF0B1020.toInt(),
            key = 0xFF1A2342.toInt(),
            keyFunc = 0xFF121A33.toInt(),
            keyDown = 0xFF26325C.toInt(),
            keyFuncDown = 0xFF1B2547.toInt(),
            text = 0xFFE6ECFF.toInt(),
            textDim = 0xFF8A97C2.toInt(),
            shadow = 0x88000000.toInt(),
            highlight = 0x226EA8FF,
            accent = 0xFF6EA8FF.toInt(),
            accentDown = 0xFF4C86E0.toInt(),
            onAccent = 0xFF0A1226.toInt(),
            popup = 0xFF222D55.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        val THEME_NAMES = listOf(
            "System", "Ivory", "Graphite", "Ribbon", "Terminal",
            "Midnight", "Aurora", "Dusk", "Sunset", "Mint", "Material You", "Pure black"
        )
        const val THEME_COUNT = 12

        /** 0 = follow the system (fresh Aurora by day, vivid Dusk by night), then [THEME_NAMES] order. */
        fun byId(id: Int, systemDark: Boolean, context: Context? = null): Palette = when (id) {
            1 -> LIGHT
            2 -> DARK
            3 -> RIBBON
            4 -> TERMINAL
            5 -> MIDNIGHT
            6 -> AURORA
            7 -> DUSK
            8 -> SUNSET
            9 -> MINT
            10 -> dynamicOrNull(context, systemDark) ?: (if (systemDark) DUSK else AURORA)
            11 -> BLACK
            else -> if (systemDark) DUSK else AURORA
        }

        /**
         * Colours taken from the wallpaper (Material You, Android 12+). Older phones, or a missing
         * context, fall back to Aurora / Dusk.
         */
        @TargetApi(Build.VERSION_CODES.S)
        private fun dynamicOrNull(context: Context?, dark: Boolean): Palette? {
            if (context == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return null
            return try {
                fun c(id: Int): Int = context.getColor(id)
                if (dark) {
                    Palette(
                        dark = true,
                        bg = c(android.R.color.system_neutral1_900),
                        key = c(android.R.color.system_neutral1_800),
                        keyFunc = c(android.R.color.system_neutral1_900),
                        keyDown = c(android.R.color.system_neutral1_700),
                        keyFuncDown = c(android.R.color.system_neutral1_800),
                        text = c(android.R.color.system_neutral1_50),
                        textDim = c(android.R.color.system_neutral2_300),
                        shadow = 0x88000000.toInt(),
                        highlight = 0x22FFFFFF,
                        accent = c(android.R.color.system_accent1_200),
                        accentDown = c(android.R.color.system_accent1_300),
                        onAccent = c(android.R.color.system_accent1_900),
                        popup = c(android.R.color.system_neutral1_700),
                        engrave = 0x99000000.toInt(),
                        dishShade = 0x77000000
                    )
                } else {
                    Palette(
                        dark = false,
                        bg = c(android.R.color.system_neutral1_50),
                        key = c(android.R.color.system_neutral1_0),
                        keyFunc = c(android.R.color.system_accent1_100),
                        keyDown = c(android.R.color.system_accent1_50),
                        keyFuncDown = c(android.R.color.system_accent1_200),
                        text = c(android.R.color.system_neutral1_900),
                        textDim = c(android.R.color.system_neutral2_500),
                        shadow = 0x331B1B2F,
                        highlight = 0xCCFFFFFF.toInt(),
                        accent = c(android.R.color.system_accent1_600),
                        accentDown = c(android.R.color.system_accent1_700),
                        onAccent = c(android.R.color.system_accent1_0),
                        popup = c(android.R.color.system_neutral1_0),
                        engrave = 0xCCFFFFFF.toInt(),
                        dishShade = 0x1F1B1B2F
                    )
                }
            } catch (e: Exception) {
                null
            }
        }

        /** True black for OLED screens. */
        val BLACK = Palette(
            dark = true,
            bg = 0xFF000000.toInt(),
            key = 0xFF171717.toInt(),
            keyFunc = 0xFF0D0D0D.toInt(),
            keyDown = 0xFF282828.toInt(),
            keyFuncDown = 0xFF1A1A1A.toInt(),
            text = 0xFFF2F2F2.toInt(),
            textDim = 0xFF8A8A8A.toInt(),
            shadow = 0x66000000,
            highlight = 0x22FFFFFF,
            accent = 0xFF7AA2FF.toInt(),
            accentDown = 0xFF5C84E0.toInt(),
            onAccent = 0xFF0A1530.toInt(),
            popup = 0xFF1F1F1F.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x66000000
        )

        /** Layout styles bring their own palette; Classic follows the chosen theme. */
        fun resolve(skin: Skin, theme: Int, systemDark: Boolean, context: Context? = null): Palette = when (skin) {
            Skin.CLASSIC -> byId(theme, systemDark, context)
            Skin.AUTOBOTS -> AUTOBOTS
            Skin.AVENGERS -> AVENGERS
            Skin.HEIST -> HEIST
            Skin.DAILY -> if (systemDark) DAILY_DARK else DAILY
            Skin.CONSTELLATION -> CONSTELLATION
        }

        /** Fresh, airy blue-white with an indigo accent. */
        val AURORA = Palette(
            dark = false,
            bg = 0xFFE9F1FF.toInt(),
            key = 0xFFFFFFFF.toInt(),
            keyFunc = 0xFFD3E2FA.toInt(),
            keyDown = 0xFFDCE8FF.toInt(),
            keyFuncDown = 0xFFC2D5F2.toInt(),
            text = 0xFF1B2540.toInt(),
            textDim = 0xFF6B7A99.toInt(),
            shadow = 0x331B3A7A,
            highlight = 0xCCFFFFFF.toInt(),
            accent = 0xFF5B6CFF.toInt(),
            accentDown = 0xFF4655DB.toInt(),
            onAccent = 0xFFFFFFFF.toInt(),
            popup = 0xFFFFFFFF.toInt(),
            engrave = 0xCCFFFFFF.toInt(),
            dishShade = 0x1F1B3A7A
        )

        /** Deep indigo with vivid pink: a dark theme that is not dull. */
        val DUSK = Palette(
            dark = true,
            bg = 0xFF14122B.toInt(),
            key = 0xFF2C2858.toInt(),
            keyFunc = 0xFF1F1C43.toInt(),
            keyDown = 0xFF3B3672.toInt(),
            keyFuncDown = 0xFF2B2759.toInt(),
            text = 0xFFF4F1FF.toInt(),
            textDim = 0xFFA9A3D6.toInt(),
            shadow = 0x88000000.toInt(),
            highlight = 0x33C9B8FF,
            accent = 0xFFFF7AC8.toInt(),
            accentDown = 0xFFD955A6.toInt(),
            onAccent = 0xFF2A0A1E.toInt(),
            popup = 0xFF38336B.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        /** Warm peach with a coral accent. */
        val SUNSET = Palette(
            dark = false,
            bg = 0xFFFFEFE2.toInt(),
            key = 0xFFFFFAF5.toInt(),
            keyFunc = 0xFFFFD9BF.toInt(),
            keyDown = 0xFFFFE6D3.toInt(),
            keyFuncDown = 0xFFFFC9A6.toInt(),
            text = 0xFF3B1F14.toInt(),
            textDim = 0xFF9A6B55.toInt(),
            shadow = 0x33A04A1A,
            highlight = 0xCCFFFFFF.toInt(),
            accent = 0xFFFF6B3D.toInt(),
            accentDown = 0xFFE0502A.toInt(),
            onAccent = 0xFFFFFFFF.toInt(),
            popup = 0xFFFFFAF5.toInt(),
            engrave = 0xCCFFFFFF.toInt(),
            dishShade = 0x22A04A1A
        )

        /** Cool mint with a fresh green accent. */
        val MINT = Palette(
            dark = false,
            bg = 0xFFE4F6EE.toInt(),
            key = 0xFFFFFFFF.toInt(),
            keyFunc = 0xFFC8EADB.toInt(),
            keyDown = 0xFFD8F1E6.toInt(),
            keyFuncDown = 0xFFB4DFCD.toInt(),
            text = 0xFF10372B.toInt(),
            textDim = 0xFF5F8F7D.toInt(),
            shadow = 0x331B6B4F,
            highlight = 0xCCFFFFFF.toInt(),
            accent = 0xFF14B88A.toInt(),
            accentDown = 0xFF0E9A73.toInt(),
            onAccent = 0xFFFFFFFF.toInt(),
            popup = 0xFFFFFFFF.toInt(),
            engrave = 0xCCFFFFFF.toInt(),
            dishShade = 0x1F1B6B4F
        )

        /** Steel blue with Autobot red. */
        val AUTOBOTS = Palette(
            dark = true,
            bg = 0xFF0C1424.toInt(),
            key = 0xFF223350.toInt(),
            keyFunc = 0xFF16233A.toInt(),
            keyDown = 0xFF2F4670.toInt(),
            keyFuncDown = 0xFF223555.toInt(),
            text = 0xFFEAF2FF.toInt(),
            textDim = 0xFF8FA6C9.toInt(),
            shadow = 0x99000000.toInt(),
            highlight = 0x336EA8FF,
            accent = 0xFFE53935.toInt(),
            accentDown = 0xFFB52B28.toInt(),
            onAccent = 0xFFFFFFFF.toInt(),
            popup = 0xFF2A3F63.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        /** Midnight navy with heroic gold. */
        val AVENGERS = Palette(
            dark = true,
            bg = 0xFF0A0F1F.toInt(),
            key = 0xFF1D2745.toInt(),
            keyFunc = 0xFF131B33.toInt(),
            keyDown = 0xFF2A3764.toInt(),
            keyFuncDown = 0xFF1D2748.toInt(),
            text = 0xFFF4F6FF.toInt(),
            textDim = 0xFF93A0C8.toInt(),
            shadow = 0x99000000.toInt(),
            highlight = 0x33FFD54F,
            accent = 0xFFFFC107.toInt(),
            accentDown = 0xFFD9A006.toInt(),
            onAccent = 0xFF1A1400.toInt(),
            popup = 0xFF26345E.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        /** Old-school cash: banknote green, cream ink and gold. */
        val HEIST = Palette(
            dark = true,
            bg = 0xFF0B1F14.toInt(),
            key = 0xFF1F5A36.toInt(),
            keyFunc = 0xFF153B25.toInt(),
            keyDown = 0xFF2B7347.toInt(),
            keyFuncDown = 0xFF1F5236.toInt(),
            text = 0xFFF3EBC8.toInt(),
            textDim = 0xFFB5C79B.toInt(),
            shadow = 0x99000000.toInt(),
            highlight = 0x33F3E1A0,
            accent = 0xFFD4AF37.toInt(),
            accentDown = 0xFFB38F20.toInt(),
            onAccent = 0xFF1A1400.toInt(),
            popup = 0xFF1F4A31.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        /** Clean white with a confident blue: the everyday layout. */
        val DAILY = Palette(
            dark = false,
            bg = 0xFFF3F5FA.toInt(),
            key = 0xFFFFFFFF.toInt(),
            keyFunc = 0xFFE1E7F1.toInt(),
            keyDown = 0xFFE7ECF5.toInt(),
            keyFuncDown = 0xFFD1D9E8.toInt(),
            text = 0xFF1A2233.toInt(),
            textDim = 0xFF7A869E.toInt(),
            shadow = 0x261A2A55,
            highlight = 0xCCFFFFFF.toInt(),
            accent = 0xFF3D5AFE.toInt(),
            accentDown = 0xFF2F47D1.toInt(),
            onAccent = 0xFFFFFFFF.toInt(),
            popup = 0xFFFFFFFF.toInt(),
            engrave = 0xCCFFFFFF.toInt(),
            dishShade = 0x1A1A2A55
        )

        val DAILY_DARK = Palette(
            dark = true,
            bg = 0xFF0F1115.toInt(),
            key = 0xFF262B34.toInt(),
            keyFunc = 0xFF1A1E25.toInt(),
            keyDown = 0xFF343A46.toInt(),
            keyFuncDown = 0xFF262B34.toInt(),
            text = 0xFFF1F4FA.toInt(),
            textDim = 0xFF8D97AB.toInt(),
            shadow = 0x88000000.toInt(),
            highlight = 0x22FFFFFF,
            accent = 0xFF6C85FF.toInt(),
            accentDown = 0xFF4F69E6.toInt(),
            onAccent = 0xFF0A1030.toInt(),
            popup = 0xFF303642.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        /** Near-black space with a violet nebula glow. */
        val CONSTELLATION = Palette(
            dark = true,
            bg = 0xFF050818.toInt(),
            key = 0xFF141C3F.toInt(),
            keyFunc = 0xFF0D1330.toInt(),
            keyDown = 0xFF1F2B5E.toInt(),
            keyFuncDown = 0xFF162049.toInt(),
            text = 0xFFEAF0FF.toInt(),
            textDim = 0xFF7F8CC4.toInt(),
            shadow = 0x99000000.toInt(),
            highlight = 0x33A8C0FF,
            accent = 0xFFB69CFF.toInt(),
            accentDown = 0xFF8F74E6.toInt(),
            onAccent = 0xFF140B33.toInt(),
            popup = 0xFF1C2754.toInt(),
            engrave = 0x99000000.toInt(),
            dishShade = 0x77000000
        )

        /** Warm ivory with soft neutral keys and delicate warm shadows. */
        val LIGHT = Palette(
            dark = false,
            bg = 0xFFEFE9DC.toInt(),
            key = 0xFFFBF8F1.toInt(),
            keyFunc = 0xFFE2DBCB.toInt(),
            keyDown = 0xFFE9E2D2.toInt(),
            keyFuncDown = 0xFFD5CDB9.toInt(),
            text = 0xFF2A2723.toInt(),
            textDim = 0xFF857F73.toInt(),
            shadow = 0x33503C14,
            highlight = 0xCCFFFFFF.toInt(),
            accent = 0xFF8C6A33.toInt(),
            accentDown = 0xFF74562A.toInt(),
            onAccent = 0xFFFBF8F1.toInt(),
            popup = 0xFFFBF8F1.toInt(),
            engrave = 0xCCFFFFFF.toInt(),
            dishShade = 0x2A3C2A0A
        )
    }
}

internal fun withAlpha(color: Int, a: Float): Int {
    val na = (Color.alpha(color) * a.coerceIn(0f, 1f)).toInt()
    return (color and 0x00FFFFFF) or (na shl 24)
}

internal fun lerpColor(a: Int, b: Int, t: Float): Int {
    if (t <= 0f) return a
    if (t >= 1f) return b
    val u = 1f - t
    return Color.argb(
        (Color.alpha(a) * u + Color.alpha(b) * t).toInt(),
        (Color.red(a) * u + Color.red(b) * t).toInt(),
        (Color.green(a) * u + Color.green(b) * t).toInt(),
        (Color.blue(a) * u + Color.blue(b) * t).toInt()
    )
}
