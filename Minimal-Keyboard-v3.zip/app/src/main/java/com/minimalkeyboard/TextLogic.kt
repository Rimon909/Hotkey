package com.minimalkeyboard

/** Pure text/gesture logic, kept free of Android types so it can be unit-tested. */

enum class ShiftState { OFF, ONCE, LOCK }

class StepAccumulator {
    private var accum = 0f

    /** Adds [dx] pixels of movement and returns how many whole [step]s were crossed (signed). */
    fun add(dx: Float, step: Float): Int {
        if (step <= 0f) return 0
        accum += dx
        val n = (accum / step).toInt()
        accum -= n * step
        return n
    }

    fun reset() {
        accum = 0f
    }
}

object TextLogic {
    const val DOUBLE_TAP_MS = 350L
    const val DOUBLE_SPACE_MS = 400L
    const val BACKSPACE_INITIAL_DELAY = 380L
    const val WORD_DELETE_AFTER = 22

    fun nextShift(current: ShiftState, sinceLastTapMs: Long): ShiftState = when (current) {
        ShiftState.OFF -> ShiftState.ONCE
        ShiftState.ONCE -> if (sinceLastTapMs in 0..DOUBLE_TAP_MS) ShiftState.LOCK else ShiftState.OFF
        ShiftState.LOCK -> ShiftState.OFF
    }

    fun backspaceDelay(repeatCount: Int): Long = when {
        repeatCount < 6 -> 90L
        repeatCount < 16 -> 55L
        else -> 35L
    }

    fun deletesWord(repeatCount: Int): Boolean = repeatCount >= WORD_DELETE_AFTER

    /** Number of UTF-16 units to delete to remove the word (or punctuation run) before the cursor. */
    fun wordDeleteLength(before: CharSequence?): Int {
        if (before == null || before.isEmpty()) return 1
        var i = before.length
        while (i > 0 && before[i - 1].isWhitespace()) i--
        if (i > 0) {
            val wordy = before[i - 1].isLetterOrDigit()
            while (i > 0 && !before[i - 1].isWhitespace() && before[i - 1].isLetterOrDigit() == wordy) i--
        }
        return (before.length - i).coerceAtLeast(1)
    }

    /** True if a second space typed quickly after "x " should become ". ". */
    fun shouldDoubleSpace(beforeCursor: CharSequence?, msSinceLastSpace: Long): Boolean {
        if (msSinceLastSpace < 0 || msSinceLastSpace > DOUBLE_SPACE_MS) return false
        val b = beforeCursor ?: return false
        if (b.length < 2) return false
        val last = b[b.length - 1]
        val prev = b[b.length - 2]
        if (last != ' ') return false
        return prev.isLetterOrDigit() || prev == ')' || prev == ']' || prev == '"' || prev == '\'' || prev == '%'
    }

    fun moveTarget(current: Int, delta: Int, max: Int): Int =
        (current + delta).coerceIn(0, max.coerceAtLeast(0))

    /** Distance in dp the finger must travel on the space bar to move the cursor one character. */
    fun cursorStepDp(sensitivity: Int): Float = when (sensitivity.coerceIn(1, 5)) {
        1 -> 22f
        2 -> 17f
        3 -> 13f
        4 -> 10f
        else -> 7.5f
    }

    /** Pitch bias for key sounds: quick typing sounds a little brighter, slow typing a little deeper. */
    fun rhythmBias(intervalMs: Long): Float {
        if (intervalMs <= 0L) return 1f
        val speed = 1f - (intervalMs / 450f).coerceIn(0f, 1f)
        return 0.97f + 0.10f * speed
    }

    /** Lengths of the last word before the cursor and of the whitespace trailing it: (word, whitespace). */
    /** Parses "shortcut = expansion" lines; blank or malformed lines are ignored. */
    fun parseShortcuts(raw: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for (line in raw.lines()) {
            val eq = line.indexOf('=')
            if (eq <= 0) continue
            val key = line.substring(0, eq).trim().lowercase()
            val value = line.substring(eq + 1).trim().replace("\\n", "\n")
            if (key.isEmpty() || value.isEmpty() || key.any { it.isWhitespace() }) continue
            out[key] = value.take(300)
        }
        return out
    }

    /** If the word just typed is a shortcut, returns (length of that word, its expansion). */
    fun expandShortcut(before: CharSequence?, shortcuts: Map<String, String>): Pair<Int, String>? {
        if (before.isNullOrEmpty() || shortcuts.isEmpty()) return null
        var start = before.length
        while (start > 0 && !before[start - 1].isWhitespace()) start--
        val word = before.subSequence(start, before.length).toString()
        if (word.isEmpty()) return null
        val expansion = shortcuts[word.lowercase()] ?: return null
        return Pair(word.length, expansion)
    }

    /** True when the typing memory has been idle longer than the auto-wipe delay. */
    fun memoryExpired(lastWrite: Long, now: Long, wipeMs: Long): Boolean =
        wipeMs > 0L && lastWrite > 0L && now - lastWrite > wipeMs

    fun lastWordSpan(before: CharSequence?): Pair<Int, Int> {
        if (before == null || before.isEmpty()) return Pair(0, 0)
        var end = before.length
        while (end > 0 && before[end - 1].isWhitespace()) end--
        var start = end
        while (start > 0 && !before[start - 1].isWhitespace()) start--
        return Pair(end - start, before.length - end)
    }

    fun clipPreview(text: String, max: Int = 90): String =
        text.replace(Regex("\\s+"), " ").trim().take(max)
}
