package com.minimalkeyboard

/**
 * A "layout style": a complete look (palette, key colours and emblems), its own effects and a
 * title on the space bar. Hold Shift for two seconds to glide between them.
 */
enum class Skin(val title: String, val spaceTitle: String) {
    CLASSIC("Classic", "MINIMAL"),
    AUTOBOTS("Autobots", "ROLL OUT"),
    AVENGERS("Avengers", "ASSEMBLE"),
    HEIST("Heist", "BELLA CIAO"),
    DAILY("Daily", "Rimon"),
    CONSTELLATION("Constellation", "make a wish");

    companion object {
        fun fromIndex(i: Int): Skin = values().getOrElse(i) { CLASSIC }

        val titles: List<String> get() = values().map { it.title }
    }
}
