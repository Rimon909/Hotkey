package com.minimalkeyboard

import kotlin.math.max
import kotlin.math.min

/** The last [capacity] characters typed. Pure Kotlin, so it is unit-testable on the JVM. */
class MemoryBuffer(private val capacity: Int = 200) {
    private val sb = StringBuilder()

    fun set(text: String) {
        sb.setLength(0)
        sb.append(text)
        trim()
    }

    fun append(text: String) {
        if (text.isEmpty()) return
        sb.append(text)
        trim()
    }

    /** Removes the last [units] UTF-16 units (what a backspace took away). */
    fun backspace(units: Int) {
        val n = min(units, sb.length)
        if (n > 0) sb.setLength(sb.length - n)
    }

    fun clear() {
        sb.setLength(0)
    }

    fun text(): String = sb.toString()

    val length: Int get() = sb.length

    /**
     * Splits the memory into reading-order rows of at most [size] characters, aligned so the
     * last row ends at the newest character. At most [maxRows] rows are returned.
     */
    fun chunks(size: Int, maxRows: Int): List<String> {
        val out = ArrayList<String>()
        if (size <= 0) return out
        var end = sb.length
        while (end > 0 && out.size < maxRows) {
            var start = max(0, end - size)
            if (start > 0 && Character.isLowSurrogate(sb[start]) && Character.isHighSurrogate(sb[start - 1])) {
                start--
            }
            out.add(0, sb.substring(start, end))
            end = start
        }
        return out
    }

    private fun trim() {
        if (sb.length > capacity) {
            sb.delete(0, sb.length - capacity)
            if (sb.isNotEmpty() && Character.isLowSurrogate(sb[0])) sb.deleteCharAt(0)
        }
    }
}
