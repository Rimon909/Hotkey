package com.minimalkeyboard

import android.graphics.Path
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Per-key look inside a skin: face colours, label colour and a small emblem. */
class KeyLook(
    val face: Int,
    val faceDown: Int,
    val text: Int,
    val emblem: Int,
    val emblemColor: Int
)

/**
 * Original, simplified line-art emblems (robot helmets, a star, a bolt, ...) in the unit space
 * the other icons use. They are stylised stand-ins in team colours, not official artwork.
 */
object SkinArt {
    const val EMB_NONE = 0
    const val EMB_HORNS = 1
    const val EMB_CREST = 2
    const val EMB_FINS = 3
    const val EMB_ARC = 4
    const val EMB_STAR = 5
    const val EMB_BOLT = 6
    const val EMB_FIST = 7
    const val EMB_HOURGLASS = 8
    const val EMB_WEB = 9

    private fun helmet(p: Path) {
        p.moveTo(-0.62f, 0.95f)
        p.lineTo(-0.62f, -0.15f)
        p.lineTo(-0.34f, -0.55f)
        p.lineTo(0.34f, -0.55f)
        p.lineTo(0.62f, -0.15f)
        p.lineTo(0.62f, 0.95f)
        // visor
        p.moveTo(-0.42f, -0.12f)
        p.lineTo(0.42f, -0.12f)
        p.lineTo(0.42f, 0.14f)
        p.lineTo(-0.42f, 0.14f)
        p.close()
        // mouth plate
        p.moveTo(-0.28f, 0.52f)
        p.lineTo(0.28f, 0.52f)
        p.moveTo(-0.28f, 0.75f)
        p.lineTo(0.28f, 0.75f)
    }

    private val horns = Path().apply {
        helmet(this)
        moveTo(-0.34f, -0.55f)
        lineTo(-0.52f, -1f)
        moveTo(0.34f, -0.55f)
        lineTo(0.52f, -1f)
    }

    private val crest = Path().apply {
        helmet(this)
        moveTo(0f, -0.55f)
        lineTo(0f, -1f)
        moveTo(-0.62f, 0.2f)
        lineTo(-0.92f, 0.2f)
        moveTo(0.62f, 0.2f)
        lineTo(0.92f, 0.2f)
    }

    private val fins = Path().apply {
        helmet(this)
        moveTo(-0.62f, -0.15f)
        lineTo(-0.95f, -0.85f)
        moveTo(0.62f, -0.15f)
        lineTo(0.95f, -0.85f)
    }

    private val arc = Path().apply {
        addCircle(0f, 0f, 0.95f, Path.Direction.CW)
        addCircle(0f, 0f, 0.5f, Path.Direction.CW)
        moveTo(0f, -0.5f)
        lineTo(0f, -0.95f)
        moveTo(0.43f, 0.25f)
        lineTo(0.82f, 0.47f)
        moveTo(-0.43f, 0.25f)
        lineTo(-0.82f, 0.47f)
    }

    private val star = Path().apply {
        val quarter = PI.toFloat() / 2f
        val step = PI.toFloat() / 5f
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) 1f else 0.42f
            val a = -quarter + i * step
            val x = r * cos(a)
            val y = r * sin(a)
            if (i == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }

    private val bolt = Path().apply {
        moveTo(0.25f, -1f)
        lineTo(-0.5f, 0.1f)
        lineTo(-0.05f, 0.1f)
        lineTo(-0.3f, 1f)
        lineTo(0.55f, -0.2f)
        lineTo(0.05f, -0.2f)
        close()
    }

    private val fist = Path().apply {
        addRoundRect(RectF(-0.7f, -0.5f, 0.7f, 0.85f), 0.25f, 0.25f, Path.Direction.CW)
        moveTo(-0.35f, -0.5f)
        lineTo(-0.35f, -0.05f)
        moveTo(0f, -0.5f)
        lineTo(0f, -0.05f)
        moveTo(0.35f, -0.5f)
        lineTo(0.35f, -0.05f)
    }

    private val hourglass = Path().apply {
        moveTo(-0.7f, -0.95f)
        lineTo(0.7f, -0.95f)
        lineTo(-0.7f, 0.95f)
        lineTo(0.7f, 0.95f)
        close()
    }

    private val web = Path().apply {
        addCircle(0f, 0f, 0.95f, Path.Direction.CW)
        addCircle(0f, 0f, 0.5f, Path.Direction.CW)
        moveTo(-0.95f, 0f)
        lineTo(0.95f, 0f)
        moveTo(0f, -0.95f)
        lineTo(0f, 0.95f)
        moveTo(-0.67f, -0.67f)
        lineTo(0.67f, 0.67f)
        moveTo(0.67f, -0.67f)
        lineTo(-0.67f, 0.67f)
    }

    fun emblemPath(kind: Int): Path? = when (kind) {
        EMB_HORNS -> horns
        EMB_CREST -> crest
        EMB_FINS -> fins
        EMB_ARC -> arc
        EMB_STAR -> star
        EMB_BOLT -> bolt
        EMB_FIST -> fist
        EMB_HOURGLASS -> hourglass
        EMB_WEB -> web
        else -> null
    }

    fun emblemFilled(kind: Int): Boolean =
        kind == EMB_STAR || kind == EMB_BOLT || kind == EMB_HOURGLASS

    private fun c(v: Long): Int = v.toInt()

    // Autobot-style crew: yellow scout, red/blue leader, black bruiser, ...
    private val autobots: Map<Char, KeyLook> = mapOf(
        'b' to KeyLook(c(0xFFF5C400), c(0xFFD6A800), c(0xFF1B1B1B), EMB_HORNS, c(0xFF1B1B1B)),
        'o' to KeyLook(c(0xFFC62828), c(0xFFA11F1F), c(0xFFFFFFFF), EMB_CREST, c(0xFF8DB8FF)),
        'p' to KeyLook(c(0xFF1F4FBF), c(0xFF193F99), c(0xFFFFFFFF), EMB_CREST, c(0xFFFF8A80)),
        'i' to KeyLook(c(0xFF2B2F36), c(0xFF1F2227), c(0xFFFFFFFF), EMB_FINS, c(0xFFFF5252)),
        'j' to KeyLook(c(0xFFE6EDF8), c(0xFFCBD6E8), c(0xFF16233A), EMB_HORNS, c(0xFF2D6CDF)),
        'r' to KeyLook(c(0xFFF5F5F5), c(0xFFDADADA), c(0xFF2A1010), EMB_FINS, c(0xFFD32F2F)),
        'a' to KeyLook(c(0xFFE91E8C), c(0xFFC4177A), c(0xFFFFFFFF), EMB_FINS, c(0xFFFFD1E8)),
        'w' to KeyLook(c(0xFF2E9E4F), c(0xFF247F3F), c(0xFFFFFFFF), EMB_HORNS, c(0xFFC8F7D4)),
        'h' to KeyLook(c(0xFFFF7A1A), c(0xFFD96310), c(0xFF2A1400), EMB_CREST, c(0xFF2A1400))
    )

    // Earth's-mightiest-heroes crew: armour red/gold, shield blue, thunder, rage green, ...
    private val avengers: Map<Char, KeyLook> = mapOf(
        'i' to KeyLook(c(0xFFB71C1C), c(0xFF8E1616), c(0xFFFFD54F), EMB_ARC, c(0xFF9BE7FF)),
        'c' to KeyLook(c(0xFF1E48A8), c(0xFF173A8A), c(0xFFFFFFFF), EMB_STAR, c(0xFFFFFFFF)),
        't' to KeyLook(c(0xFF8A97B3), c(0xFF74819C), c(0xFF14203A), EMB_BOLT, c(0xFF1565C0)),
        'h' to KeyLook(c(0xFF2E7D32), c(0xFF25652A), c(0xFFFFFFFF), EMB_FIST, c(0xFFB9F6CA)),
        'w' to KeyLook(c(0xFF1A1A1E), c(0xFF111114), c(0xFFFF5252), EMB_HOURGLASS, c(0xFFFF5252)),
        's' to KeyLook(c(0xFFC62828), c(0xFFA11F1F), c(0xFFFFFFFF), EMB_WEB, c(0xFF4C7DFF))
    )

    fun look(skin: Skin, key: Key): KeyLook? {
        if (key.type != KeyType.CHAR || key.label.length != 1) return null
        val ch = key.label[0]
        return when (skin) {
            Skin.AUTOBOTS -> autobots[ch]
            Skin.AVENGERS -> avengers[ch]
            else -> null
        }
    }
}
