package com.minimalkeyboard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SkinTest {

    @Test
    fun sixLayoutStylesEachWithAnOwnSpaceTitle() {
        assertEquals(6, Skin.values().size)
        val titles = Skin.values().map { it.spaceTitle }
        assertEquals(titles.size, titles.toSet().size)
        assertEquals("Rimon", Skin.DAILY.spaceTitle)
    }

    @Test
    fun unknownIndexFallsBackToClassic() {
        assertEquals(Skin.CLASSIC, Skin.fromIndex(99))
        assertEquals(Skin.CLASSIC, Skin.fromIndex(-1))
        assertEquals(Skin.HEIST, Skin.fromIndex(Skin.HEIST.ordinal))
    }

    @Test
    fun autobotKeysHaveLooksForTheNamedCharacters() {
        val b = SkinArt.look(Skin.AUTOBOTS, Key(KeyType.CHAR, "b"))
        val o = SkinArt.look(Skin.AUTOBOTS, Key(KeyType.CHAR, "o"))
        val p = SkinArt.look(Skin.AUTOBOTS, Key(KeyType.CHAR, "p"))
        assertNotNull(b)
        assertNotNull(o)
        assertNotNull(p)
        assertNull(SkinArt.look(Skin.AUTOBOTS, Key(KeyType.CHAR, "q")))
        assertNull(SkinArt.look(Skin.CLASSIC, Key(KeyType.CHAR, "b")))
        assertNull(SkinArt.look(Skin.AUTOBOTS, Key(KeyType.SPACE)))
    }

    @Test
    fun avengerKeysCoverTheHeroes() {
        for (c in "ichtws") {
            assertNotNull(c.toString(), SkinArt.look(Skin.AVENGERS, Key(KeyType.CHAR, c.toString())))
        }
        assertTrue(SkinArt.look(Skin.AVENGERS, Key(KeyType.CHAR, "i"))!!.emblem == SkinArt.EMB_ARC)
    }
}
