package com.minimalkeyboard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryBufferTest {

    @Test
    fun keepsOnlyTheLastTwoHundredCharacters() {
        val buf = MemoryBuffer(200)
        buf.append("a".repeat(150))
        buf.append("b".repeat(150))
        assertEquals(200, buf.length)
        assertTrue(buf.text().endsWith("b".repeat(150)))
        assertTrue(buf.text().startsWith("a".repeat(50)))
    }

    @Test
    fun backspaceRemovesFromTheEnd() {
        val buf = MemoryBuffer(200)
        buf.append("hello")
        buf.backspace(2)
        assertEquals("hel", buf.text())
        buf.backspace(99)
        assertEquals("", buf.text())
    }

    @Test
    fun chunksAreInReadingOrderAndEndAtTheNewestCharacter() {
        val buf = MemoryBuffer(200)
        buf.append("abcdefghij")
        assertEquals(listOf("ab", "cdef", "ghij"), buf.chunks(4, 10))
    }

    @Test
    fun chunkRowsAreCapped() {
        val buf = MemoryBuffer(200)
        buf.append("x".repeat(200))
        val rows = buf.chunks(34, 6)
        assertEquals(6, rows.size)
        assertTrue(rows.all { it.length <= 34 })
        assertEquals("x".repeat(34), rows.last())
    }

    @Test
    fun setTrimsToCapacity() {
        val buf = MemoryBuffer(5)
        buf.set("abcdefgh")
        assertEquals("defgh", buf.text())
    }

    @Test
    fun clearEmptiesTheBuffer() {
        val buf = MemoryBuffer(10)
        buf.append("abc")
        buf.clear()
        assertEquals(0, buf.length)
        assertTrue(buf.chunks(4, 4).isEmpty())
    }
}
