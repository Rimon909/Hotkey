package com.minimalkeyboard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class KeyboardLayoutsTest {

    private fun weight(row: List<Key>): Float = row.sumOf { it.weight.toDouble() }.toFloat()

    @Test
    fun everyRowIsTenUnitsWide() {
        for (kind in LayoutKind.values()) {
            for (skin in Skin.values()) {
                for (globe in listOf(false, true)) {
                    for (page in Page.values()) {
                        val rows = KeyboardLayouts.rows(page, LayoutOptions(showGlobe = globe, kind = kind, skin = skin))
                        assertEquals(4, rows.size)
                        for (row in rows) assertEquals(10f, weight(row), 0.001f)
                    }
                }
            }
        }
    }

    @Test
    fun lettersPageHasAll26LettersOnce() {
        val letters = KeyboardLayouts.rows(Page.LETTERS).flatten().filter { it.isLetter }.map { it.label }
        assertEquals(26, letters.size)
        assertEquals(26, letters.toSet().size)
        assertTrue(letters.toSet() == ('a'..'z').map { it.toString() }.toSet())
    }

    @Test
    fun numbersPageHasAllDigits() {
        val labels = KeyboardLayouts.rows(Page.NUMBERS).flatten().map { it.label }
        for (d in '0'..'9') assertTrue(labels.contains(d.toString()))
    }

    @Test
    fun everyPageHasOneSpaceOneEnterOneBackspace() {
        for (page in Page.values()) {
            val keys = KeyboardLayouts.rows(page).flatten()
            assertEquals(1, keys.count { it.type == KeyType.SPACE })
            assertEquals(1, keys.count { it.type == KeyType.ENTER })
            assertEquals(1, keys.count { it.type == KeyType.BACKSPACE })
        }
    }

    @Test
    fun globeOptionAddsNextImeKey() {
        val without = KeyboardLayouts.rows(Page.LETTERS, LayoutOptions(showGlobe = false)).flatten()
        val with = KeyboardLayouts.rows(Page.LETTERS, LayoutOptions(showGlobe = true)).flatten()
        assertEquals(0, without.count { it.type == KeyType.NEXT_IME })
        assertEquals(1, with.count { it.type == KeyType.NEXT_IME })
    }

    @Test
    fun commaKeyCanBeReplacedForEmailFields() {
        val keys = KeyboardLayouts.rows(Page.LETTERS, LayoutOptions(commaKey = "@")).flatten()
        assertTrue(keys.any { it.type == KeyType.CHAR && it.label == "@" })
    }

    @Test
    fun topRowLettersCarryDigitAlternates() {
        val q = KeyboardLayouts.rows(Page.LETTERS)[0].first { it.label == "q" }
        assertEquals("1", q.alts.first())
        val e = KeyboardLayouts.rows(Page.LETTERS)[0].first { it.label == "e" }
        assertTrue(e.alts.contains("é"))
    }

    @Test
    fun spansFillTheWidthExactly() {
        val row = KeyboardLayouts.rows(Page.LETTERS)[2]
        val spans = KeyboardLayouts.spans(row, 1000f)
        val last = row.size - 1
        assertEquals(0f, spans[0], 0.001f)
        assertEquals(1000f, spans[2 * last] + spans[2 * last + 1], 0.01f)
    }

    @Test
    fun everyLayoutHasAll26LettersOnce() {
        for (kind in LayoutKind.values()) {
            val letters = KeyboardLayouts.rows(Page.LETTERS, LayoutOptions(kind = kind))
                .flatten().filter { it.isLetter }.map { it.label }
            assertEquals(kind.name, 26, letters.size)
            assertEquals(kind.name, 26, letters.toSet().size)
        }
    }

    @Test
    fun layoutKindsDiffer() {
        assertEquals("qwertzuiop", KeyboardLayouts.letterRows(LayoutKind.QWERTZ).first)
        assertEquals("azertyuiop", KeyboardLayouts.letterRows(LayoutKind.AZERTY).first)
        assertEquals("arstdhneio", KeyboardLayouts.letterRows(LayoutKind.COLEMAK).second)
        assertEquals(LayoutKind.QWERTY, LayoutKind.fromIndex(99))
    }

    @Test
    fun topRowDigitsFollowKeyPosition() {
        val az = KeyboardLayouts.rows(Page.LETTERS, LayoutOptions(kind = LayoutKind.AZERTY))[0]
        assertEquals("1", az.first { it.label == "a" }.alts.first())
        assertEquals("0", az.first { it.label == "p" }.alts.first())
    }

    @Test
    fun toolbarHasThirteenToolsAndNoEmoji() {
        assertEquals(13, KeyboardLayouts.toolbar.size)
        assertTrue(KeyboardLayouts.toolbar.all { it.type == KeyType.TOOL })
        val ids = KeyboardLayouts.toolbar.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertTrue(ids.containsAll(listOf("undo", "redo", "styles", "alchemy", "snippets")))
        assertTrue(!ids.contains("emoji"))
    }

    @Test
    fun periodKeyFeedsTheSevenItemDial() {
        val period = KeyboardLayouts.rows(Page.LETTERS)[3].first { it.label == "." }
        assertEquals(listOf("?", "!", ",", "@", "&", ":", "-"), period.alts)
    }

    @Test
    fun emojiKeySitsBesideTheSpaceBar() {
        for (globe in listOf(false, true)) {
            val bottom = KeyboardLayouts.rows(Page.LETTERS, LayoutOptions(showGlobe = globe))[3]
            val emoji = bottom.indexOfFirst { it.type == KeyType.EMOJI }
            val space = bottom.indexOfFirst { it.type == KeyType.SPACE }
            assertTrue(emoji >= 0)
            // emoji, comma, space: the emoji key is two keys to the left of the space bar
            assertEquals(space - 2, emoji)
        }
    }

    @Test
    fun dailyLayoutMakesCommonLettersWiderButKeepsEveryLetter() {
        val rows = KeyboardLayouts.rows(Page.LETTERS, LayoutOptions(skin = Skin.DAILY))
        val keys = rows.flatten()
        val e = keys.first { it.label == "e" }
        val q = keys.first { it.label == "q" }
        assertTrue(e.weight > q.weight)
        assertEquals(26, keys.filter { it.isLetter }.map { it.label }.toSet().size)
    }

    @Test
    fun classicLayoutKeepsEqualLetterWidths() {
        val top = KeyboardLayouts.rows(Page.LETTERS, LayoutOptions(skin = Skin.CLASSIC))[0]
        assertTrue(top.all { it.weight == 1f })
    }

    @Test
    fun compactToolbarPinsFiveToolsEndingWithMore() {
        val compact = KeyboardLayouts.compactToolbar
        assertEquals(5, compact.size)
        assertEquals("more", compact.last().id)
        assertTrue(compact.all { it.type == KeyType.TOOL })
    }

    @Test
    fun expandedToolbarAddsACollapseButtonInFront() {
        assertEquals(KeyboardLayouts.toolbar.size + 1, KeyboardLayouts.expandedToolbar.size)
        assertEquals("more", KeyboardLayouts.expandedToolbar.first().id)
    }

    @Test
    fun numberStripIsOneToZero() {
        assertEquals("1234567890", KeyboardLayouts.numberStrip.joinToString("") { it.label })
        assertTrue(KeyboardLayouts.numberStrip.all { it.type == KeyType.CHAR && it.alts.isEmpty() })
    }
}
