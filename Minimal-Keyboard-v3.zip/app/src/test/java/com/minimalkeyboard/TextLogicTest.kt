package com.minimalkeyboard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextLogicTest {

    @Test
    fun shiftCyclesOffOnceLockOff() {
        var s = ShiftState.OFF
        s = TextLogic.nextShift(s, 5000)
        assertEquals(ShiftState.ONCE, s)
        s = TextLogic.nextShift(s, 100) // quick second tap
        assertEquals(ShiftState.LOCK, s)
        s = TextLogic.nextShift(s, 5000)
        assertEquals(ShiftState.OFF, s)
    }

    @Test
    fun slowSecondShiftTapTurnsShiftOff() {
        assertEquals(ShiftState.OFF, TextLogic.nextShift(ShiftState.ONCE, 2000))
    }

    @Test
    fun backspaceAccelerates() {
        assertTrue(TextLogic.backspaceDelay(0) > TextLogic.backspaceDelay(10))
        assertTrue(TextLogic.backspaceDelay(10) > TextLogic.backspaceDelay(30))
        assertFalse(TextLogic.deletesWord(5))
        assertTrue(TextLogic.deletesWord(TextLogic.WORD_DELETE_AFTER))
    }

    @Test
    fun wordDeleteLength() {
        assertEquals(5, TextLogic.wordDeleteLength("hello"))
        assertEquals(5, TextLogic.wordDeleteLength("say hello"))
        assertEquals(7, TextLogic.wordDeleteLength("say hello  ")) // trailing spaces + word
        assertEquals(1, TextLogic.wordDeleteLength(""))
        assertEquals(1, TextLogic.wordDeleteLength(null))
        assertEquals(3, TextLogic.wordDeleteLength("ok..."))
    }

    @Test
    fun doubleSpaceBecomesPeriod() {
        assertTrue(TextLogic.shouldDoubleSpace("a ", 200))
        assertFalse(TextLogic.shouldDoubleSpace("a ", 900))
        assertFalse(TextLogic.shouldDoubleSpace(". ", 200))
        assertFalse(TextLogic.shouldDoubleSpace("  ", 200))
        assertFalse(TextLogic.shouldDoubleSpace(" ", 200))
        assertFalse(TextLogic.shouldDoubleSpace(null, 200))
    }

    @Test
    fun stepAccumulatorCountsWholeStepsAndKeepsRemainder() {
        val acc = StepAccumulator()
        assertEquals(0, acc.add(5f, 10f))
        assertEquals(1, acc.add(6f, 10f))   // 11 total -> 1 step, 1 left
        assertEquals(2, acc.add(19f, 10f))  // 20 total -> 2 steps
        assertEquals(-3, acc.add(-30f, 10f))
        acc.reset()
        assertEquals(0, acc.add(9.9f, 10f))
    }

    @Test
    fun moveTargetIsClamped() {
        assertEquals(0, TextLogic.moveTarget(2, -10, 20))
        assertEquals(20, TextLogic.moveTarget(18, 10, 20))
        assertEquals(7, TextLogic.moveTarget(5, 2, 20))
    }

    @Test
    fun sensitivityMonotonic() {
        for (s in 1..4) {
            assertTrue(TextLogic.cursorStepDp(s) > TextLogic.cursorStepDp(s + 1))
        }
    }

    @Test
    fun clipPreviewCollapsesWhitespace() {
        assertEquals("a b c", TextLogic.clipPreview("  a\n b\t c  "))
        assertEquals(5, TextLogic.clipPreview("abcdefghij", 5).length)
    }

    @Test
    fun rhythmBiasBrightensWithSpeed() {
        assertEquals(1f, TextLogic.rhythmBias(0L), 0.0001f)
        assertTrue(TextLogic.rhythmBias(60L) > TextLogic.rhythmBias(400L))
        assertTrue(TextLogic.rhythmBias(5000L) < 1f)
    }

    @Test
    fun lastWordSpanFindsWordAndTrailingSpace() {
        assertEquals(Pair(5, 0), TextLogic.lastWordSpan("hello world"))
        assertEquals(Pair(5, 2), TextLogic.lastWordSpan("hello world  "))
        assertEquals(Pair(0, 0), TextLogic.lastWordSpan(""))
        assertEquals(Pair(0, 3), TextLogic.lastWordSpan("   "))
        assertEquals(Pair(0, 0), TextLogic.lastWordSpan(null))
    }

    @Test
    fun parseShortcutsReadsKeyValueLines() {
        val map = TextLogic.parseShortcuts("omw = On my way!\nBRB=Be right back\nbad line\n= nothing\nempty =\nsig = Hi,\\nRimon")
        assertEquals(3, map.size)
        assertEquals("On my way!", map["omw"])
        assertEquals("Be right back", map["brb"])
        assertEquals("Hi,\nRimon", map["sig"])
    }

    @Test
    fun expandShortcutMatchesTheLastWordCaseInsensitively() {
        val map = mapOf("omw" to "On my way!")
        assertEquals(Pair(3, "On my way!"), TextLogic.expandShortcut("see you soon omw", map))
        assertEquals(Pair(3, "On my way!"), TextLogic.expandShortcut("OMW", map))
        assertNull(TextLogic.expandShortcut("see you omwx", map))
        assertNull(TextLogic.expandShortcut("omw ", map))
        assertNull(TextLogic.expandShortcut(null, map))
        assertNull(TextLogic.expandShortcut("omw", emptyMap()))
    }

    @Test
    fun memoryExpiresOnlyWhenIdleLongerThanTheWipeDelay() {
        assertTrue(TextLogic.memoryExpired(1_000L, 1_000L + 600_001L, 600_000L))
        assertTrue(!TextLogic.memoryExpired(1_000L, 1_000L + 599_999L, 600_000L))
        assertTrue(!TextLogic.memoryExpired(1_000L, 9_999_999L, 0L))
        assertTrue(!TextLogic.memoryExpired(0L, 9_999_999L, 600_000L))
    }
}
