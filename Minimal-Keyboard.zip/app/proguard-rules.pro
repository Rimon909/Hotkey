# No special rules needed: the IME service and activity are referenced from the manifest,
# and the app uses no reflection.
