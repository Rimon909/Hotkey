package com.minimalkeyboard

import android.content.ClipboardManager
import android.content.Context

/**
 * In-memory clipboard history (never written to disk). Items the source app flags as
 * sensitive (e.g. password managers) are skipped.
 */
class ClipboardStore(private val context: Context) {
    private val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    private val items = ArrayList<String>()
    private var started = false
    private val listener = ClipboardManager.OnPrimaryClipChangedListener { capture() }

    fun start() {
        if (started) return
        started = true
        try {
            manager.addPrimaryClipChangedListener(listener)
        } catch (e: Exception) {
            // Clipboard access can be restricted by the OS; history simply stays empty.
        }
        capture()
    }

    fun stop() {
        if (!started) return
        started = false
        try {
            manager.removePrimaryClipChangedListener(listener)
        } catch (e: Exception) {
            // ignore
        }
        items.clear()
    }

    fun snapshot(): List<String> = ArrayList(items)

    fun clear() {
        items.clear()
    }

    private fun capture() {
        try {
            val clip = manager.primaryClip ?: return
            if (clip.itemCount == 0) return
            val sensitive = clip.description?.extras?.getBoolean(SENSITIVE_EXTRA, false) ?: false
            if (sensitive) return
            val text = clip.getItemAt(0).coerceToText(context)?.toString()?.trim() ?: return
            if (text.isEmpty() || text.length > MAX_LENGTH) return
            items.remove(text)
            items.add(0, text)
            while (items.size > MAX_ITEMS) items.removeAt(items.size - 1)
        } catch (e: Exception) {
            // Reading the clipboard may be denied; ignore.
        }
    }

    companion object {
        private const val MAX_ITEMS = 8
        private const val MAX_LENGTH = 2000
        private const val SENSITIVE_EXTRA = "android.content.extra.IS_SENSITIVE"
    }
}
