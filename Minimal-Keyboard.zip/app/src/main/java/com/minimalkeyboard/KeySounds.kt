package com.minimalkeyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.util.Collections
import java.util.Random

enum class SoundCat { LETTER, SPACE, BACK, ENTER, MOD }

/**
 * Low-latency key sounds built on [SoundPool]. The pool is created lazily, decodes the
 * small bundled WAVs asynchronously, and is released when sound is disabled or the
 * service is destroyed.
 */
class KeySounds(private val context: Context) {

    private var pool: SoundPool? = null
    private val variants = HashMap<SoundCat, IntArray>()
    private val ready: MutableSet<Int> = Collections.synchronizedSet(HashSet<Int>())
    private val lastVariant = HashMap<SoundCat, Int>()
    private val random = Random()

    fun setEnabled(enabled: Boolean) {
        if (enabled) ensure() else release()
    }

    private fun ensure() {
        if (pool != null) return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder()
            .setMaxStreams(6)
            .setAudioAttributes(attrs)
            .build()
        p.setOnLoadCompleteListener { _, id, status ->
            if (status == 0) ready.add(id)
        }
        variants[SoundCat.LETTER] = intArrayOf(
            p.load(context, R.raw.key_letter_1, 1),
            p.load(context, R.raw.key_letter_2, 1),
            p.load(context, R.raw.key_letter_3, 1)
        )
        variants[SoundCat.SPACE] = intArrayOf(
            p.load(context, R.raw.key_space_1, 1),
            p.load(context, R.raw.key_space_2, 1)
        )
        variants[SoundCat.BACK] = intArrayOf(
            p.load(context, R.raw.key_back_1, 1),
            p.load(context, R.raw.key_back_2, 1)
        )
        variants[SoundCat.ENTER] = intArrayOf(
            p.load(context, R.raw.key_enter_1, 1)
        )
        variants[SoundCat.MOD] = intArrayOf(
            p.load(context, R.raw.key_mod_1, 1),
            p.load(context, R.raw.key_mod_2, 1)
        )
        pool = p
    }

    /** [volume] is 0..1. Each play picks a different variant and slightly varies pitch and level. */
    fun play(cat: SoundCat, volume: Float, repeat: Boolean) {
        val p = pool ?: return
        val ids = variants[cat] ?: return
        var idx = random.nextInt(ids.size)
        val previous = lastVariant[cat]
        if (ids.size > 1 && previous != null && idx == previous) {
            idx = (idx + 1 + random.nextInt(ids.size - 1)) % ids.size
        }
        val id = ids[idx]
        if (!ready.contains(id)) return
        lastVariant[cat] = idx

        val spread = if (cat == SoundCat.SPACE || cat == SoundCat.ENTER) 0.05f else 0.12f
        val rate = 1f - spread / 2f + random.nextFloat() * spread
        var level = volume * (0.86f + random.nextFloat() * 0.14f)
        if (repeat) level *= 0.6f
        level = level.coerceIn(0f, 1f)
        p.play(id, level, level, 1, 0, rate)
    }

    fun release() {
        pool?.release()
        pool = null
        variants.clear()
        ready.clear()
        lastVariant.clear()
    }
}
