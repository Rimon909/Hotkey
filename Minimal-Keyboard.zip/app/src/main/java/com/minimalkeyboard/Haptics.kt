package com.minimalkeyboard

import android.content.Context
import android.os.Build
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Short, configurable key haptics, independent of the system "touch vibration" setting. */
class Haptics(context: Context) {

    private val vibrator: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= 31) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            legacyVibrator(context)
        }
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    private fun legacyVibrator(context: Context): Vibrator? =
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    /** [strength] is 0..100. [light] is used for repeats and cursor steps. */
    fun tick(strength: Int, light: Boolean) {
        val v = vibrator ?: return
        if (strength <= 0) return
        val s = if (light) strength * 0.55f else strength.toFloat()
        val ms = (5f + s * 0.15f).toLong().coerceIn(4L, 22L)
        val amp = (35f + s * 2.2f).toInt().coerceIn(1, 255)
        try {
            val effect: VibrationEffect = if (v.hasAmplitudeControl()) {
                VibrationEffect.createOneShot(ms, amp)
            } else if (Build.VERSION.SDK_INT >= 29) {
                VibrationEffect.createPredefined(
                    if (light) VibrationEffect.EFFECT_TICK else VibrationEffect.EFFECT_CLICK
                )
            } else {
                VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE)
            }
            if (Build.VERSION.SDK_INT >= 33) {
                v.vibrate(effect, VibrationAttributes.createForUsage(VibrationAttributes.USAGE_TOUCH))
            } else {
                v.vibrate(effect)
            }
        } catch (e: Exception) {
            // Vibration is best-effort.
        }
    }
}
