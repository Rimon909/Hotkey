package com.minimalkeyboard

import android.graphics.Color

class Palette(
    val dark: Boolean,
    val bg: Int,
    val key: Int,
    val keyFunc: Int,
    val keyDown: Int,
    val keyFuncDown: Int,
    val text: Int,
    val textDim: Int,
    val shadow: Int,
    val highlight: Int,
    val accent: Int,
    val accentDown: Int,
    val onAccent: Int,
    val popup: Int
) {
    companion object {
        /** Deep graphite with restrained grey keys and a single antique-brass accent. */
        val DARK = Palette(
            dark = true,
            bg = 0xFF16171A.toInt(),
            key = 0xFF303236.toInt(),
            keyFunc = 0xFF232528.toInt(),
            keyDown = 0xFF42444A.toInt(),
            keyFuncDown = 0xFF30323A.toInt(),
            text = 0xFFEDEBE6.toInt(),
            textDim = 0xFF9C9B97.toInt(),
            shadow = 0x66000000,
            highlight = 0x24FFFFFF,
            accent = 0xFFC9A66B.toInt(),
            accentDown = 0xFFA88A55.toInt(),
            onAccent = 0xFF1B1A17.toInt(),
            popup = 0xFF3A3C42.toInt()
        )

        /** Warm ivory with soft neutral keys and delicate warm shadows. */
        val LIGHT = Palette(
            dark = false,
            bg = 0xFFEFE9DC.toInt(),
            key = 0xFFFBF8F1.toInt(),
            keyFunc = 0xFFE2DBCB.toInt(),
            keyDown = 0xFFE9E2D2.toInt(),
            keyFuncDown = 0xFFD5CDB9.toInt(),
            text = 0xFF2A2723.toInt(),
            textDim = 0xFF857F73.toInt(),
            shadow = 0x33503C14,
            highlight = 0xCCFFFFFF.toInt(),
            accent = 0xFF8C6A33.toInt(),
            accentDown = 0xFF74562A.toInt(),
            onAccent = 0xFFFBF8F1.toInt(),
            popup = 0xFFFBF8F1.toInt()
        )
    }
}

internal fun withAlpha(color: Int, a: Float): Int {
    val na = (Color.alpha(color) * a.coerceIn(0f, 1f)).toInt()
    return (color and 0x00FFFFFF) or (na shl 24)
}

internal fun lerpColor(a: Int, b: Int, t: Float): Int {
    if (t <= 0f) return a
    if (t >= 1f) return b
    val u = 1f - t
    return Color.argb(
        (Color.alpha(a) * u + Color.alpha(b) * t).toInt(),
        (Color.red(a) * u + Color.red(b) * t).toInt(),
        (Color.green(a) * u + Color.green(b) * t).toInt(),
        (Color.blue(a) * u + Color.blue(b) * t).toInt()
    )
}
