package com.minimalkeyboard

/** Pure text/gesture logic, kept free of Android types so it can be unit-tested. */

enum class ShiftState { OFF, ONCE, LOCK }

class StepAccumulator {
    private var accum = 0f

    /** Adds [dx] pixels of movement and returns how many whole [step]s were crossed (signed). */
    fun add(dx: Float, step: Float): Int {
        if (step <= 0f) return 0
        accum += dx
        val n = (accum / step).toInt()
        accum -= n * step
        return n
    }

    fun reset() {
        accum = 0f
    }
}

object TextLogic {
    const val DOUBLE_TAP_MS = 350L
    const val DOUBLE_SPACE_MS = 400L
    const val BACKSPACE_INITIAL_DELAY = 380L
    const val WORD_DELETE_AFTER = 22

    fun nextShift(current: ShiftState, sinceLastTapMs: Long): ShiftState = when (current) {
        ShiftState.OFF -> ShiftState.ONCE
        ShiftState.ONCE -> if (sinceLastTapMs in 0..DOUBLE_TAP_MS) ShiftState.LOCK else ShiftState.OFF
        ShiftState.LOCK -> ShiftState.OFF
    }

    fun backspaceDelay(repeatCount: Int): Long = when {
        repeatCount < 6 -> 90L
        repeatCount < 16 -> 55L
        else -> 35L
    }

    fun deletesWord(repeatCount: Int): Boolean = repeatCount >= WORD_DELETE_AFTER

    /** Number of UTF-16 units to delete to remove the word (or punctuation run) before the cursor. */
    fun wordDeleteLength(before: CharSequence?): Int {
        if (before == null || before.isEmpty()) return 1
        var i = before.length
        while (i > 0 && before[i - 1].isWhitespace()) i--
        if (i > 0) {
            val wordy = before[i - 1].isLetterOrDigit()
            while (i > 0 && !before[i - 1].isWhitespace() && before[i - 1].isLetterOrDigit() == wordy) i--
        }
        return (before.length - i).coerceAtLeast(1)
    }

    /** True if a second space typed quickly after "x " should become ". ". */
    fun shouldDoubleSpace(beforeCursor: CharSequence?, msSinceLastSpace: Long): Boolean {
        if (msSinceLastSpace < 0 || msSinceLastSpace > DOUBLE_SPACE_MS) return false
        val b = beforeCursor ?: return false
        if (b.length < 2) return false
        val last = b[b.length - 1]
        val prev = b[b.length - 2]
        if (last != ' ') return false
        return prev.isLetterOrDigit() || prev == ')' || prev == ']' || prev == '"' || prev == '\'' || prev == '%'
    }

    fun moveTarget(current: Int, delta: Int, max: Int): Int =
        (current + delta).coerceIn(0, max.coerceAtLeast(0))

    /** Distance in dp the finger must travel on the space bar to move the cursor one character. */
    fun cursorStepDp(sensitivity: Int): Float = when (sensitivity.coerceIn(1, 5)) {
        1 -> 22f
        2 -> 17f
        3 -> 13f
        4 -> 10f
        else -> 7.5f
    }

    fun clipPreview(text: String, max: Int = 90): String =
        text.replace(Regex("\\s+"), " ").trim().take(max)
}
