package com.minimalkeyboard

import android.content.Context
import android.content.SharedPreferences

/** Cached view of the persisted user preferences. Call [reload] when the keyboard opens. */
class KeyboardPrefs(context: Context) {
    private val store: SharedPreferences = shared(context)

    var effects = true
    var sound = true
    var soundVolume = 70
    var haptic = true
    var hapticStrength = 45
    var openingAnimation = true
    var theme = THEME_SYSTEM
    var heightMode = HEIGHT_NORMAL
    var showToolbar = true
    var autoCapitalize = true
    var doubleSpacePeriod = true
    var longPressAlternates = true
    var cursorSensitivity = 3
    var respectSilentMode = true

    /** Master switch ("disable all effects") overrides every individual effect. */
    val soundActive: Boolean get() = effects && sound
    val hapticActive: Boolean get() = effects && haptic && hapticStrength > 0
    val openingActive: Boolean get() = effects && openingAnimation

    init {
        reload()
    }

    fun reload() {
        effects = store.getBoolean(K_EFFECTS, true)
        sound = store.getBoolean(K_SOUND, true)
        soundVolume = store.getInt(K_SOUND_VOLUME, 70).coerceIn(0, 100)
        haptic = store.getBoolean(K_HAPTIC, true)
        hapticStrength = store.getInt(K_HAPTIC_STRENGTH, 45).coerceIn(0, 100)
        openingAnimation = store.getBoolean(K_OPENING, true)
        theme = store.getInt(K_THEME, THEME_SYSTEM)
        heightMode = store.getInt(K_HEIGHT, HEIGHT_NORMAL)
        showToolbar = store.getBoolean(K_TOOLBAR, true)
        autoCapitalize = store.getBoolean(K_AUTOCAP, true)
        doubleSpacePeriod = store.getBoolean(K_DOUBLE_SPACE, true)
        longPressAlternates = store.getBoolean(K_LONG_PRESS, true)
        cursorSensitivity = store.getInt(K_SENSITIVITY, 3).coerceIn(1, 5)
        respectSilentMode = store.getBoolean(K_SILENT, true)
    }

    companion object {
        const val FILE = "minimal_keyboard_prefs"

        const val K_EFFECTS = "effects_enabled"
        const val K_SOUND = "sound_enabled"
        const val K_SOUND_VOLUME = "sound_volume"
        const val K_HAPTIC = "haptic_enabled"
        const val K_HAPTIC_STRENGTH = "haptic_strength"
        const val K_OPENING = "opening_animation"
        const val K_THEME = "theme"
        const val K_HEIGHT = "key_height"
        const val K_TOOLBAR = "show_toolbar"
        const val K_AUTOCAP = "auto_capitalize"
        const val K_DOUBLE_SPACE = "double_space_period"
        const val K_LONG_PRESS = "long_press_alternates"
        const val K_SENSITIVITY = "cursor_sensitivity"
        const val K_SILENT = "respect_silent_mode"

        const val THEME_SYSTEM = 0
        const val THEME_LIGHT = 1
        const val THEME_DARK = 2

        const val HEIGHT_COMPACT = 0
        const val HEIGHT_NORMAL = 1
        const val HEIGHT_TALL = 2

        fun shared(context: Context): SharedPreferences =
            context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    }
}
