# Minimal Keyboard

A minimalist Android keyboard (Kotlin, `InputMethodService`, min API 26) with a signature
opening animation, original synthetic typewriter sounds and fast text editing.

## Build with GitHub Actions
1. Create a repo on GitHub and upload `Minimal-Keyboard.zip` (the files sit at the zip root, so they land at the repo root: `app/`, `settings.gradle.kts`, ...).
2. In the repo choose **Add file > Create new file**, type `.github/workflows/build.yml` as the name (typing the slashes creates the folders), paste the contents of the separate `build.yml` file, and commit.
3. The build starts automatically on that commit. Open **Actions > Build Minimal Keyboard**; you can also start it with *Run workflow*.
4. When it finishes, download **Minimal-Keyboard-debug-apk** from the run's *Artifacts* section and unzip it.

> `gradle-wrapper.jar` is a binary that could not be bundled from the environment this project was
> generated in. The workflow detects this and generates the wrapper itself, so CI needs nothing from
> you. For local builds, run once: `gradle wrapper --gradle-version 8.9` (then `./gradlew assembleDebug`).

## Install
1. Copy `app-debug.apk` to the phone and open it (allow "install unknown apps" when asked).
2. Open **Minimal Keyboard**, tap **Enable keyboard**, switch it on, then **Choose keyboard**.

## Features
- **Opening animation**: keys fly in from the four corners (~620 ms, staggered, no bounce); only plays when the keyboard appears, never on layout changes; keys are usable immediately.
- **Sound**: 10 original synthetic samples (`tools/generate_sounds.py`), separate sets for letters, space, backspace, enter and modifiers, with random variant, pitch and level variation.
- **Haptics / effects**: independent sound and haptic controls, strengths, and a master "Typing effects" switch that disables everything.
- **Space bar**: tap = space; slide = move cursor; long-press then slide = select text. Sensitivity is adjustable.
- Backspace hold-to-repeat (accelerates, then deletes by word), shift / caps lock (double-tap), numbers and symbols pages, long-press alternates (accents, digits, punctuation), double-space period, auto-capitalise.
- Toolbar: select all, copy, cut, paste, in-memory clipboard history, settings, hide.
- Light (warm ivory) and dark (graphite) themes, follow-system option, three key heights.

## Notes and limits
- No internet permission, no analytics, no text logging. Clipboard history is memory-only and skips items flagged sensitive.
- Cursor and selection use `InputConnection.setSelection`; editors that reject it fall back to arrow keys.
- **Swipe typing is not included**: it needs a dictionary/language model to be useful, and a placeholder would be misleading.
- Gesture-navigation bottom insets rely on the framework for target SDK 34; a hook for edge-to-edge (target 35+) is included. Not tested on physical devices.
- English (US) layout only.
