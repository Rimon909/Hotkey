#!/usr/bin/env python3
"""
Generates the original synthetic typewriter-style key sounds in app/src/main/res/raw/.
Everything is synthesised from noise bursts, decaying sine "thunks" and inharmonic metallic
partials - no samples, nothing copyrighted. Requires only numpy:  python3 tools/generate_sounds.py
"""
import math
import os
import wave

import numpy as np

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "res", "raw")


def lp(x, fc):
    a = 1.0 - math.exp(-2.0 * math.pi * fc / SR)
    y = np.empty_like(x)
    acc = 0.0
    for i in range(len(x)):
        acc += a * (x[i] - acc)
        y[i] = acc
    return y


def hp(x, fc):
    return x - lp(x, fc)


def burst(rng, n, tau, hp_fc, lp_fc):
    t = np.arange(n) / SR
    noise = hp(lp(rng.standard_normal(n), lp_fc), hp_fc)
    return noise * np.exp(-t / tau)


def thunk(n, f_start, f_end, tau):
    t = np.arange(n) / SR
    f = f_end + (f_start - f_end) * np.exp(-t / 0.018)
    phase = 2.0 * math.pi * np.cumsum(f) / SR
    return np.sin(phase) * np.exp(-t / tau)


def metal(n, freqs, amps, tau):
    t = np.arange(n) / SR
    out = np.zeros(n)
    for i, (f, a) in enumerate(zip(freqs, amps)):
        out += a * np.sin(2.0 * math.pi * f * t) * np.exp(-t / (tau / (1.0 + 0.35 * i)))
    return out


def add_at(buf, sig, at_s):
    off = int(SR * at_s)
    if off >= len(buf):
        return
    m = min(len(sig), len(buf) - off)
    buf[off:off + m] += sig[:m]


def finish(sig, peak=0.85):
    fade = int(SR * 0.008)
    sig[-fade:] *= np.linspace(1.0, 0.0, fade)
    sig = sig / (np.max(np.abs(sig)) + 1e-9) * peak
    return sig


def write(name, sig):
    path = os.path.join(OUT, name + ".wav")
    pcm = (np.clip(sig, -1, 1) * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    print("wrote", name, "%.0f ms" % (1000.0 * len(sig) / SR))


def letter(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.14)
    s = np.zeros(n)
    s += 1.0 * burst(rng, n, 0.0022, 1400, 7000)
    s += 0.75 * thunk(n, rng.uniform(165, 215), rng.uniform(105, 135), 0.028)
    freqs = [rng.uniform(2200, 2500), rng.uniform(3600, 4000), rng.uniform(5000, 5600)]
    s += 0.22 * metal(n, freqs, [1.0, 0.6, 0.35], 0.014)
    add_at(s, 0.35 * burst(rng, n, 0.0018, 900, 5000), rng.uniform(0.009, 0.015))
    return finish(s)


def space(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.20)
    s = np.zeros(n)
    s += 0.6 * burst(rng, n, 0.004, 300, 3500)
    s += 1.0 * thunk(n, rng.uniform(100, 125), 68, 0.06)
    s += 0.08 * metal(n, [rng.uniform(1700, 1900), rng.uniform(2900, 3200)], [1.0, 0.5], 0.02)
    add_at(s, 0.25 * burst(rng, n, 0.0015, 800, 4500), 0.018)
    add_at(s, 0.2 * burst(rng, n, 0.0015, 800, 4500), 0.034)
    return finish(s)


def back(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.15)
    s = np.zeros(n)
    s += 0.8 * burst(rng, n, 0.002, 1200, 6500)
    s += 0.45 * thunk(n, rng.uniform(200, 235), 150, 0.02)
    second = 0.6 * burst(rng, n, 0.002, 1500, 7000) + 0.4 * thunk(n, rng.uniform(250, 285), 190, 0.018)
    add_at(s, second, rng.uniform(0.032, 0.040))
    s += 0.12 * metal(n, [rng.uniform(2800, 3200), rng.uniform(4300, 4800)], [1.0, 0.6], 0.012)
    return finish(s)


def enter(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.5)
    s = np.zeros(n)
    s += 0.8 * burst(rng, n, 0.004, 400, 5000)
    s += 1.0 * thunk(n, 95, 60, 0.08)
    t = 0.05
    gap = 0.018
    while t < 0.22:
        add_at(s, 0.3 * burst(rng, n, 0.0012, 1800, 7500), t)
        t += gap
        gap = max(0.009, gap * 0.9)
    add_at(s, 0.18 * metal(n, [2600, 3900, 5230], [1.0, 0.55, 0.3], 0.16), 0.24)
    return finish(s)


def mod(seed):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.09)
    s = np.zeros(n)
    s += 0.8 * burst(rng, n, 0.003, 500, 3000)
    s += 0.55 * thunk(n, rng.uniform(125, 145), 100, 0.02)
    s += 0.06 * metal(n, [rng.uniform(1400, 1600)], [1.0], 0.01)
    return finish(s)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    for i in (1, 2, 3):
        write("key_letter_%d" % i, letter(100 + i))
    for i in (1, 2):
        write("key_space_%d" % i, space(200 + i))
        write("key_back_%d" % i, back(300 + i))
        write("key_mod_%d" % i, mod(500 + i))
    write("key_enter_1", enter(400))
