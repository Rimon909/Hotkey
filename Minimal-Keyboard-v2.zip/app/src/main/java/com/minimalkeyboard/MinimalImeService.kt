package com.minimalkeyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MinimalImeService : InputMethodService(), KeyboardListener {

    private lateinit var prefs: KeyboardPrefs
    private lateinit var sounds: KeySounds
    private lateinit var haptics: Haptics
    private lateinit var clipStore: ClipboardStore
    private lateinit var memory: TypingMemory
    private lateinit var audio: AudioManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var keyboardView: KeyboardView? = null

    // Selection as last reported by the editor (kept optimistically up to date for gestures).
    private var selStart = -1
    private var selEnd = -1
    private var gestureAnchor = -1
    private var gestureActive = -1

    private var lastSpaceTime = 0L
    private var passwordLike = false

    // typing rhythm, margin bell and odometer
    private var lastStrike = 0L
    private var charsOnLine = 0
    private var bellRung = false
    private var pendingStrikes = 0L

    // text removed by the current backspace press, so a slide into the typing memory can undo it
    private val burst = StringBuilder()

    // ------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        prefs = KeyboardPrefs(this)
        sounds = KeySounds(this)
        haptics = Haptics(this)
        clipStore = ClipboardStore(this)
        memory = TypingMemory(this)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        clipStore.start()
    }

    override fun onDestroy() {
        flushStrikes()
        memory.flush()
        sounds.release()
        clipStore.stop()
        mainHandler.removeCallbacksAndMessages(null)
        keyboardView = null
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val view = KeyboardView(this, prefs, this)
        view.applyTheme(currentPalette())
        keyboardView = view
        return view
    }

    /** A clean keyboard in landscape too: no full-screen extract UI. */
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        prefs.reload()
        sounds.setPack(prefs.soundPack)
        sounds.setEnabled(prefs.soundActive)

        // Decide "password-like" first, before any early return, so a stale value from the previous
        // field can never let the paper strip read text from a password field.
        val type = info?.inputType ?: 0
        val cls = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        val isText = cls == InputType.TYPE_CLASS_TEXT
        val numeric = cls == InputType.TYPE_CLASS_NUMBER ||
            cls == InputType.TYPE_CLASS_PHONE ||
            cls == InputType.TYPE_CLASS_DATETIME
        passwordLike = (isText && (
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            )) || (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)

        val view = keyboardView ?: return
        val palette = currentPalette()
        view.applyTheme(palette)
        view.applyPrefs()
        applySystemBars(palette)

        if (info == null) return

        val comma = when {
            isText && (variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS) -> "@"
            isText && variation == InputType.TYPE_TEXT_VARIATION_URI -> "/"
            else -> ","
        }
        val options = LayoutOptions(
            showGlobe = offerGlobe(),
            commaKey = comma,
            kind = LayoutKind.fromIndex(prefs.layoutKind),
            skin = Skin.fromIndex(prefs.skin)
        )
        view.configureForInput(if (numeric) Page.NUMBERS else Page.LETTERS, options, enterLabelFor(info))

        if (!restarting) {
            view.resetShift()
            charsOnLine = 0
            bellRung = false
        }
        selStart = info.initialSelStart
        selEnd = info.initialSelEnd
        lastSpaceTime = 0L
        updateAutoShift()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        keyboardView?.cancelAllTouches()
        gestureAnchor = -1
        gestureActive = -1
        flushStrikes()
        memory.flush()
    }

    /** The signature opening animation plays only when the keyboard window actually appears. */
    override fun onWindowShown() {
        super.onWindowShown()
        val started = keyboardView?.playOpening() ?: false
        if (started && prefs.soundActive && prefs.shuffleSound && soundAllowed()) {
            sounds.play(SoundCat.RIFFLE, soundVolume() * 0.6f, false, 1f)
        }
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        keyboardView?.onHidden()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val palette = currentPalette()
        keyboardView?.applyTheme(palette)
        applySystemBars(palette)
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        selStart = newSelStart
        selEnd = newSelEnd
        if (gestureAnchor >= 0) {
            // Keep the moving end of a gesture selection in sync with what the editor really did.
            if (newSelStart == gestureAnchor) gestureActive = newSelEnd
            else if (newSelEnd == gestureAnchor) gestureActive = newSelStart
            pushSelectionPreview()
        }
        refreshPaper()
    }

    // ------------------------------------------------------------ helpers

    private fun systemDark(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun currentPalette(): Palette =
        Palette.resolve(Skin.fromIndex(prefs.skin), prefs.theme, systemDark())

    private fun applySystemBars(palette: Palette) {
        try {
            val w = window?.window ?: return
            w.navigationBarColor = palette.bg
            val decor = w.decorView
            var flags = decor.systemUiVisibility
            flags = if (palette.dark) {
                flags and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            } else {
                flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            decor.systemUiVisibility = flags
        } catch (e: Exception) {
            // Cosmetic only.
        }
    }

    private fun offerGlobe(): Boolean = try {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.enabledInputMethodList.size > 1
    } catch (e: Exception) {
        false
    }

    private fun enterLabelFor(info: EditorInfo): String? {
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return null
        val custom = info.actionLabel
        if (custom != null) return custom.toString()
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "Go"
            EditorInfo.IME_ACTION_SEARCH -> "Search"
            EditorInfo.IME_ACTION_SEND -> "Send"
            EditorInfo.IME_ACTION_NEXT -> "Next"
            EditorInfo.IME_ACTION_DONE -> "Done"
            EditorInfo.IME_ACTION_PREVIOUS -> "Prev"
            else -> null
        }
    }

    private fun updateAutoShift() {
        refreshPaper()
        val view = keyboardView ?: return
        val info = currentInputEditorInfo
        if (!prefs.autoCapitalize || passwordLike || info == null) {
            view.setAutoCapitalized(false)
            return
        }
        val ic = currentInputConnection ?: return
        val caps = ic.getCursorCapsMode(info.inputType) != 0
        view.setAutoCapitalized(caps)
    }

    /** Feeds the typewriter paper strip. Never reads text in password fields. */
    private fun refreshPaper() {
        val view = keyboardView ?: return
        if (!prefs.paperStrip) return
        if (passwordLike) {
            view.setPaperText("")
            return
        }
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: ""
        view.setPaperText(before.replace('\n', '\u23CE'))
    }

    private fun remember(text: CharSequence) {
        if (prefs.typingMemory && !passwordLike) memory.append(text.toString())
    }

    private fun forget(units: Int) {
        if (prefs.typingMemory && !passwordLike) memory.backspace(units)
    }

    /** Puts back what the current backspace press just deleted (used when it turns into a slide). */
    private fun restoreBurst() {
        if (burst.isEmpty()) return
        val text = burst.toString()
        burst.setLength(0)
        val ic = currentInputConnection ?: return
        ic.commitText(text, 1)
        remember(text)
        updateAutoShift()
    }

    private fun showMemory() {
        restoreBurst()
        val items: List<String> =
            if (prefs.typingMemory && !passwordLike) memory.chunks(34, 6) else emptyList()
        keyboardView?.showList(
            KeyboardView.PANEL_MEMORY, items, "Insert all", "memory_insert_all", "Clear", "clear_memory"
        )
    }

    private fun insertMemory() {
        if (!prefs.typingMemory || passwordLike) return
        val text = memory.text()
        if (text.isEmpty()) return
        val ic = currentInputConnection ?: return
        ic.commitText(text, 1)
        lastSpaceTime = 0L
        updateAutoShift()
    }

    private fun pushSelectionPreview() {
        val text = currentInputConnection?.getSelectedText(0)
        keyboardView?.setSelectionPreview(text?.toString() ?: "")
    }

    private fun sendKeyDownUp(code: Int, meta: Int = 0) {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0, meta))
    }

    private fun clipboard(): ClipboardManager =
        getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    private fun flushStrikes() {
        if (pendingStrikes > 0L) {
            prefs.addStrikes(pendingStrikes)
            pendingStrikes = 0L
        }
    }

    /** Margin bell: like a real typewriter, a bell rings as the line gets long. */
    private fun typed(n: Int) {
        charsOnLine += n
        if (prefs.bell && prefs.effects && !bellRung && charsOnLine >= BELL_COLUMN) {
            bellRung = true
            if (prefs.soundActive && soundAllowed()) sounds.play(SoundCat.BELL, soundVolume(), false, 1f)
            if (prefs.hapticActive) {
                haptics.tick(prefs.hapticStrength, false)
                mainHandler.postDelayed({ haptics.tick(prefs.hapticStrength, true) }, 90L)
            }
        }
    }

    // ------------------------------------------------------------ KeyboardListener

    override fun onText(text: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(text, 1)
        lastSpaceTime = 0L
        remember(text)
        typed(text.length)
        updateAutoShift()
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        typed(1)
        if (prefs.doubleSpacePeriod && !passwordLike && lastSpaceTime != 0L) {
            val before = ic.getTextBeforeCursor(2, 0)
            if (TextLogic.shouldDoubleSpace(before, now - lastSpaceTime)) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                ic.endBatchEdit()
                forget(1)
                remember(". ")
                lastSpaceTime = 0L
                updateAutoShift()
                return
            }
        }
        ic.commitText(" ", 1)
        remember(" ")
        lastSpaceTime = now
        updateAutoShift()
    }

    override fun onBackspace(repeatCount: Int) {
        val ic = currentInputConnection ?: return
        if (repeatCount == 0) burst.setLength(0)
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            burst.insert(0, selected)
            ic.commitText("", 1)
        } else if (TextLogic.deletesWord(repeatCount)) {
            val before = ic.getTextBeforeCursor(64, 0)
            if (before.isNullOrEmpty()) {
                sendKeyDownUp(KeyEvent.KEYCODE_DEL)
            } else {
                val n = TextLogic.wordDeleteLength(before)
                burst.insert(0, before.subSequence(before.length - n, before.length))
                ic.deleteSurroundingText(n, 0)
                forget(n)
            }
        } else {
            val before = ic.getTextBeforeCursor(2, 0)
            if (before.isNullOrEmpty()) {
                // Editors without text access (or an empty field) still get a real DEL key.
                sendKeyDownUp(KeyEvent.KEYCODE_DEL)
            } else {
                // Struck-through / underlined letters are a letter plus a combining mark.
                val last = before[before.length - 1].code
                val n = if (before.length >= 2 && last in 0x0300..0x036F) 2 else 1
                val pair = before.length >= 2 &&
                    Character.isLowSurrogate(before[before.length - 1]) &&
                    Character.isHighSurrogate(before[before.length - 2])
                val units = if (n == 2 || pair) 2 else 1
                burst.insert(0, before.subSequence(before.length - units, before.length))
                ic.deleteSurroundingTextInCodePoints(n, 0)
                forget(units)
            }
        }
        lastSpaceTime = 0L
        charsOnLine = max(0, charsOnLine - 1)
        if (charsOnLine < BELL_COLUMN - 10) bellRung = false
        updateAutoShift()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        if (info == null || (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) {
            sendKeyDownUp(KeyEvent.KEYCODE_ENTER)
        } else if (info.actionLabel != null) {
            ic.performEditorAction(info.actionId)
        } else {
            val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
            if (action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
                sendKeyDownUp(KeyEvent.KEYCODE_ENTER)
            } else {
                ic.performEditorAction(action)
            }
        }
        lastSpaceTime = 0L
        charsOnLine = 0
        bellRung = false
        remember("\n")
        // The editor handles key events asynchronously; re-check capitalisation shortly after.
        mainHandler.postDelayed({ updateAutoShift() }, 40L)
    }

    override fun onSelectionGesture(active: Boolean) {
        if (active) {
            gestureAnchor = selStart
            gestureActive = selEnd
            pushSelectionPreview()
        } else {
            gestureAnchor = -1
            gestureActive = -1
        }
    }

    override fun onCursorMove(delta: Int, select: Boolean) {
        val ic = currentInputConnection ?: return
        if (delta == 0) return
        if (selStart < 0 || selEnd < 0) {
            dpadMove(delta, select)
            return
        }
        val from = when {
            select -> gestureActive
            delta < 0 -> selStart
            else -> selEnd
        }
        if (from < 0) {
            dpadMove(delta, select)
            return
        }
        var target = max(0, from + delta)
        if (target > selEnd) {
            // Probe how much text actually exists after the cursor so we never run past the end.
            val available = ic.getTextAfterCursor(target - selEnd, 0)?.length ?: 0
            target = min(target, selEnd + available)
        }
        if (target == from) return

        val a: Int
        val b: Int
        if (select) {
            val anchor = if (gestureAnchor >= 0) gestureAnchor else from
            a = min(anchor, target)
            b = max(anchor, target)
            gestureActive = target
        } else {
            a = target
            b = target
        }
        if (ic.setSelection(a, b)) {
            selStart = a
            selEnd = b
        } else {
            // Some editors refuse setSelection; arrow keys are the portable fallback.
            dpadMove(delta, select)
        }
    }

    override fun onLineMove(delta: Int, select: Boolean) {
        if (delta == 0) return
        val code = if (delta < 0) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN
        val meta = if (select) KeyEvent.META_SHIFT_ON else 0
        repeat(min(abs(delta), 4)) { sendKeyDownUp(code, meta) }
    }

    private fun dpadMove(delta: Int, select: Boolean) {
        val code = if (delta < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        val meta = if (select) KeyEvent.META_SHIFT_ON else 0
        repeat(min(abs(delta), 8)) { sendKeyDownUp(code, meta) }
    }

    override fun onTool(id: String) {
        when (id) {
            "undo" -> undoRedo(false)
            "redo" -> undoRedo(true)
            "select_all" -> selectAll()
            "copy" -> copySelection(false)
            "cut" -> {
                copySelection(true)
                updateAutoShift()
            }
            "paste" -> paste()
            "clipboard" ->
                keyboardView?.showList(KeyboardView.PANEL_CLIP, clipStore.snapshot(), "Clear history", "clear_clips")
            "snippets" ->
                keyboardView?.showList(KeyboardView.PANEL_SNIPPETS, snippetList(), "Edit snippets", "edit_snippets")
            "edit_snippets" -> openSettings()
            "memory" -> showMemory()
            "memory_insert_all" -> insertMemory()
            "clear_memory" -> memory.clear()
            "hand" -> {
                prefs.saveOneHand((prefs.oneHand + 1) % 3)
                keyboardView?.applyPrefs()
            }
            "settings" -> openSettings()
            "hide" -> requestHideSelf(0)
            else -> if (id.startsWith("alchemy:")) alchemy(id.removePrefix("alchemy:"))
        }
    }

    override fun onClipPick(text: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(text, 1)
        lastSpaceTime = 0L
        remember(text)
        typed(text.length)
        updateAutoShift()
    }

    override fun onClipClear() {
        clipStore.clear()
    }

    override fun onNextIme() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (Build.VERSION.SDK_INT >= 28) {
            if (!switchToNextInputMethod(false)) imm.showInputMethodPicker()
        } else {
            imm.showInputMethodPicker()
        }
    }

    override fun onFeedback(type: KeyType, repeat: Boolean) {
        val counts = type == KeyType.CHAR || type == KeyType.SPACE ||
            type == KeyType.BACKSPACE || type == KeyType.ENTER
        if (counts) {
            pendingStrikes++
            if (pendingStrikes >= 40L) flushStrikes()
        }
        if (!prefs.effects) return
        if (prefs.soundActive && soundAllowed()) {
            var tempo = 1f
            if (type == KeyType.CHAR || type == KeyType.SPACE || type == KeyType.BACKSPACE) {
                val now = SystemClock.uptimeMillis()
                tempo = TextLogic.rhythmBias(if (lastStrike == 0L) 0L else now - lastStrike)
                lastStrike = now
            }
            val cat = if (type == KeyType.ENTER && Skin.fromIndex(prefs.skin) == Skin.HEIST) {
                SoundCat.KACHING
            } else {
                categoryFor(type)
            }
            sounds.play(cat, soundVolume(), repeat, tempo)
        }
        if (prefs.hapticActive) haptics.tick(prefs.hapticStrength, repeat)
    }

    override fun onHapticStep() {
        if (prefs.effects && prefs.hapticActive) haptics.tick(prefs.hapticStrength, true)
    }

    override fun onUiEvent(open: Boolean) {
        if (!prefs.effects || !prefs.soundActive || !soundAllowed()) return
        sounds.play(if (open) SoundCat.OPEN else SoundCat.CLOSE, soundVolume() * 0.7f, false, 1f)
    }

    override fun onSkinChanged() {
        val palette = currentPalette()
        keyboardView?.applyTheme(palette)
        applySystemBars(palette)
    }

    private fun categoryFor(type: KeyType): SoundCat = when (type) {
        KeyType.CHAR -> SoundCat.LETTER
        KeyType.SPACE -> SoundCat.SPACE
        KeyType.BACKSPACE -> SoundCat.BACK
        KeyType.ENTER -> SoundCat.ENTER
        KeyType.EMO_GRID, KeyType.EMO_TAB, KeyType.STYLE_ITEM, KeyType.ALCHEMY_ITEM -> SoundCat.POP
        else -> SoundCat.MOD
    }

    private fun soundVolume(): Float {
        val v = prefs.soundVolume / 100f
        return (v * v * 0.6f + v * 0.4f).coerceIn(0f, 1f)
    }

    private fun soundAllowed(): Boolean =
        !prefs.respectSilentMode || audio.ringerMode == AudioManager.RINGER_MODE_NORMAL

    // ------------------------------------------------------------ editing shortcuts

    private fun snippetList(): List<String> =
        prefs.snippets.split('\n').map { it.trim() }.filter { it.isNotEmpty() }.take(6)

    private fun undoRedo(redo: Boolean) {
        val ic = currentInputConnection ?: return
        val id = if (redo) android.R.id.redo else android.R.id.undo
        if (!ic.performContextMenuAction(id)) {
            val meta = KeyEvent.META_CTRL_ON or (if (redo) KeyEvent.META_SHIFT_ON else 0)
            sendKeyDownUp(KeyEvent.KEYCODE_Z, meta)
        }
        mainHandler.postDelayed({ updateAutoShift() }, 40L)
    }

    /** Applies a text transformation to the selection, or to the last word before the cursor. */
    private fun alchemy(opName: String) {
        val op = try {
            AlchemyOp.valueOf(opName)
        } catch (e: IllegalArgumentException) {
            return
        }
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText(TextAlchemy.apply(op, selected.toString()), 1)
        } else {
            val before = ic.getTextBeforeCursor(64, 0)?.toString() ?: ""
            val span = TextLogic.lastWordSpan(before)
            val wordLen = span.first
            val wsLen = span.second
            if (wordLen > 0) {
                val word = before.substring(before.length - wsLen - wordLen, before.length - wsLen)
                val ws = before.substring(before.length - wsLen)
                ic.beginBatchEdit()
                ic.deleteSurroundingText(wordLen + wsLen, 0)
                ic.commitText(TextAlchemy.apply(op, word) + ws, 1)
                ic.endBatchEdit()
            }
        }
        updateAutoShift()
    }

    private fun selectAll() {
        val ic = currentInputConnection ?: return
        if (!ic.performContextMenuAction(android.R.id.selectAll)) {
            sendKeyDownUp(KeyEvent.KEYCODE_A, KeyEvent.META_CTRL_ON)
        }
    }

    private fun copySelection(cut: Boolean) {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            clipboard().setPrimaryClip(ClipData.newPlainText("text", selected.toString()))
            if (cut) ic.commitText("", 1)
        } else {
            ic.performContextMenuAction(if (cut) android.R.id.cut else android.R.id.copy)
        }
    }

    private fun paste() {
        val ic = currentInputConnection ?: return
        val clip = clipboard().primaryClip
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this) else null
        if (!text.isNullOrEmpty()) {
            ic.commitText(text, 1)
            lastSpaceTime = 0L
            remember(text)
            updateAutoShift()
        } else {
            ic.performContextMenuAction(android.R.id.paste)
        }
    }

    private fun openSettings() {
        val intent = Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        requestHideSelf(0)
    }

    companion object {
        private const val BELL_COLUMN = 60
    }
}
