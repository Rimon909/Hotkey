package com.minimalkeyboard

/** Pure layout model (no Android dependencies, so it is unit-testable on the JVM). */

enum class KeyType {
    CHAR, SHIFT, BACKSPACE, ENTER, SPACE,
    MODE_NUMBERS, MODE_LETTERS, MODE_SYMBOLS, NEXT_IME, SPACER,
    TOOL, CLIP_ITEM, PANEL_BACK, PANEL_ACTION, PAD,
    EMO_TAB, EMO_GRID, STYLE_ITEM, ALCHEMY_ITEM, EMOJI
}

enum class Page { LETTERS, NUMBERS, SYMBOLS }

enum class LayoutKind {
    QWERTY, QWERTZ, AZERTY, COLEMAK;

    companion object {
        fun fromIndex(i: Int): LayoutKind = values().getOrElse(i) { QWERTY }
    }
}

class Key(
    val type: KeyType,
    val label: String = "",
    val weight: Float = 1f,
    val alts: List<String> = emptyList(),
    val id: String = label
) {
    val isLetter: Boolean
        get() = type == KeyType.CHAR && label.length == 1 && label[0].isLetter()
}

class LayoutOptions(
    val showGlobe: Boolean = false,
    val commaKey: String = ",",
    val kind: LayoutKind = LayoutKind.QWERTY,
    val skin: Skin = Skin.CLASSIC
) {
    override fun equals(other: Any?): Boolean =
        other is LayoutOptions && other.showGlobe == showGlobe &&
            other.commaKey == commaKey && other.kind == kind && other.skin == skin

    override fun hashCode(): Int =
        31 * (31 * (31 * showGlobe.hashCode() + commaKey.hashCode()) + kind.hashCode()) + skin.hashCode()
}

object KeyboardLayouts {

    private val accents = mapOf(
        'a' to "à á â ä æ ã å ā",
        'e' to "è é ê ë ē ė ę",
        'i' to "ì í î ï ī į",
        'o' to "ò ó ô ö œ õ ø ō",
        'u' to "ù ú û ü ū",
        'c' to "ç ć č",
        'n' to "ñ ń",
        's' to "ß ś š",
        'y' to "ý ÿ",
        'z' to "ž ź ż",
        'l' to "ł"
    )

    private val symbolAlts = mapOf(
        "1" to "¹ ½ ⅓ ¼ ⅛",
        "2" to "² ⅔",
        "3" to "³ ¾ ⅜",
        "4" to "⁴",
        "5" to "⁵ ⅝",
        "6" to "⁶",
        "7" to "⁷ ⅞",
        "8" to "⁸ ∞",
        "9" to "⁹",
        "0" to "° ⁰ ∅",
        "\$" to "£ € ¥ ¢ ₹",
        "-" to "– — •",
        "&" to "§",
        "(" to "[ { <",
        ")" to "] } >",
        "/" to "\\ |",
        "\"" to "“ ” „ « »",
        "'" to "‘ ’ ‚ ‹ ›",
        "!" to "¡",
        "?" to "¿",
        "." to "? ! , @ & : -",
        "," to "; : ' \" ( ) - ! ?",
        "@" to "# &",
        "%" to "‰"
    )

    private fun letterAlts(c: Char, digit: String?): List<String> {
        val out = ArrayList<String>()
        if (digit != null) out.add(digit)
        accents[c]?.let { out.addAll(it.split(' ')) }
        return out
    }

    private fun altsFor(label: String): List<String> =
        symbolAlts[label]?.split(' ') ?: emptyList()

    private fun charKey(label: String, alts: List<String> = emptyList(), weight: Float = 1f): Key =
        Key(KeyType.CHAR, label, weight, alts)

    /** Top row: the key's position decides the digit available on long-press. */
    private fun topRowKeys(chars: String): List<Key> =
        chars.mapIndexed { i, c -> charKey(c.toString(), letterAlts(c, ((i + 1) % 10).toString())) }

    private fun letterKeys(chars: String): List<Key> =
        chars.map { charKey(it.toString(), letterAlts(it, null)) }

    private fun symbolKeys(chars: String): List<Key> =
        chars.map { charKey(it.toString(), altsFor(it.toString())) }

    private fun spacer(weight: Float): Key = Key(KeyType.SPACER, "", weight)

    /** Letter rows (top, middle, bottom) for each layout; every layout holds all 26 letters. */
    fun letterRows(kind: LayoutKind): Triple<String, String, String> = when (kind) {
        LayoutKind.QWERTY -> Triple("qwertyuiop", "asdfghjkl", "zxcvbnm")
        LayoutKind.QWERTZ -> Triple("qwertzuiop", "asdfghjkl", "yxcvbnm")
        LayoutKind.AZERTY -> Triple("azertyuiop", "qsdfghjklm", "wxcvbn")
        LayoutKind.COLEMAK -> Triple("qwfpgjluy;", "arstdhneio", "zxcvbkm")
    }

    private fun middleRow(chars: String): List<Key> {
        val keys = letterKeys(chars)
        return if (chars.length < 10) listOf(spacer(0.5f)) + keys + spacer(0.5f) else keys
    }

    private fun thirdRow(chars: String): List<Key> {
        val edge = (10f - chars.length) / 2f
        return listOf(Key(KeyType.SHIFT, "", edge)) + letterKeys(chars) + Key(KeyType.BACKSPACE, "", edge)
    }

    /** Bottom row: the emoji key now sits right next to the space bar, where thumbs expect it. */
    private fun bottomRow(mode: Key, o: LayoutOptions): List<Key> {
        val row = ArrayList<Key>()
        if (o.showGlobe) {
            row.add(Key(mode.type, mode.label, 1.3f))
            row.add(Key(KeyType.NEXT_IME, "", 0.9f))
            row.add(Key(KeyType.EMOJI, "", 1f))
            row.add(charKey(o.commaKey, altsFor(o.commaKey), 0.9f))
            row.add(Key(KeyType.SPACE, "", 3.2f))
            row.add(charKey(".", altsFor("."), 0.9f))
            row.add(Key(KeyType.ENTER, "", 1.8f))
        } else {
            row.add(Key(mode.type, mode.label, 1.4f))
            row.add(Key(KeyType.EMOJI, "", 1f))
            row.add(charKey(o.commaKey, altsFor(o.commaKey), 1f))
            row.add(Key(KeyType.SPACE, "", 3.9f))
            row.add(charKey(".", altsFor("."), 1f))
            row.add(Key(KeyType.ENTER, "", 1.7f))
        }
        return row
    }

    // ---- the Daily layout: the most used letters are a little wider and bigger

    private const val DAILY_COMMON = "etaoinsrh"

    private fun dailyWeight(c: Char): Float = if (DAILY_COMMON.indexOf(c) >= 0) 1.15f else 0.95f

    private fun reweighted(keys: List<Key>): List<Key> =
        keys.map { Key(it.type, it.label, dailyWeight(it.label[0]), it.alts, it.id) }

    /** Scales a row so it is exactly ten units wide, whatever the individual weights are. */
    private fun normalized(row: List<Key>): List<Key> {
        var total = 0f
        for (k in row) total += k.weight
        if (total <= 0f) return row
        val f = 10f / total
        return row.map { Key(it.type, it.label, it.weight * f, it.alts, it.id) }
    }

    private fun dailyLetterRows(top: String, middle: String, bottom: String): List<List<Key>> {
        val topKeys = reweighted(topRowKeys(top))
        val midKeys = reweighted(letterKeys(middle))
        val midRow = if (middle.length < 10) listOf(spacer(0.5f)) + midKeys + spacer(0.5f) else midKeys
        val edge = (10f - bottom.length) / 2f
        val third = listOf(Key(KeyType.SHIFT, "", edge)) + reweighted(letterKeys(bottom)) + Key(KeyType.BACKSPACE, "", edge)
        return listOf(normalized(topKeys), normalized(midRow), normalized(third))
    }

    fun rows(page: Page, o: LayoutOptions = LayoutOptions()): List<List<Key>> = when (page) {
        Page.LETTERS -> {
            val (top, middle, bottom) = letterRows(o.kind)
            val bottomKeys = bottomRow(Key(KeyType.MODE_NUMBERS, "?123"), o)
            if (o.skin == Skin.DAILY) {
                val d = dailyLetterRows(top, middle, bottom)
                listOf(d[0], d[1], d[2], bottomKeys)
            } else {
                listOf(topRowKeys(top), middleRow(middle), thirdRow(bottom), bottomKeys)
            }
        }
        Page.NUMBERS -> listOf(
            symbolKeys("1234567890"),
            symbolKeys("@#\$_&-+()/"),
            listOf(Key(KeyType.MODE_SYMBOLS, "=\\<", 1.5f)) + symbolKeys("*\"':;!?") + Key(KeyType.BACKSPACE, "", 1.5f),
            bottomRow(Key(KeyType.MODE_LETTERS, "ABC"), o)
        )
        Page.SYMBOLS -> listOf(
            symbolKeys("~`|•√π÷×¶∆"),
            symbolKeys("£¢€¥^°={}\\"),
            listOf(Key(KeyType.MODE_NUMBERS, "?123", 1.5f)) + symbolKeys("<>[]%©®") + Key(KeyType.BACKSPACE, "", 1.5f),
            bottomRow(Key(KeyType.MODE_LETTERS, "ABC"), o)
        )
    }

    /** Offsets and widths for a row: [x0, w0, x1, w1, ...] filling exactly [width]. */
    fun spans(row: List<Key>, width: Float): FloatArray {
        var total = 0f
        for (k in row) total += k.weight
        val out = FloatArray(row.size * 2)
        var x = 0f
        for ((i, k) in row.withIndex()) {
            val w = width * k.weight / total
            out[2 * i] = x
            out[2 * i + 1] = w
            x += w
        }
        return out
    }

    /** Scrollable toolbar, most-used tools first. */
    val toolbar: List<Key> = listOf(
        "undo", "redo", "select_all", "copy", "cut", "paste", "clipboard",
        "styles", "alchemy", "snippets", "hand", "settings", "hide"
    ).map { Key(KeyType.TOOL, "", 1f, emptyList(), it) }
}
