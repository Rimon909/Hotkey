package com.minimalkeyboard

import android.content.Context

/**
 * Remembers the last 200 characters typed so they can be recovered ("black box recorder").
 * Stored only in this app's private preferences, never sent anywhere, and never fed from
 * password fields (the service decides that). Clearing from Settings is picked up through a
 * timestamp so the live keyboard service forgets too.
 */
class TypingMemory(context: Context) {
    private val store = KeyboardPrefs.shared(context)
    private val buffer = MemoryBuffer(CAPACITY)
    private var seenClear = store.getLong(KeyboardPrefs.K_MEMORY_CLEARED, 0L)
    private var dirty = false
    private var pending = 0

    init {
        buffer.set(store.getString(KeyboardPrefs.K_MEMORY_TEXT, "") ?: "")
    }

    private fun sync() {
        val stamp = store.getLong(KeyboardPrefs.K_MEMORY_CLEARED, 0L)
        if (stamp != seenClear) {
            seenClear = stamp
            buffer.clear()
            dirty = false
            pending = 0
        }
    }

    fun append(text: String) {
        sync()
        buffer.append(text)
        touch(text.length)
    }

    fun backspace(units: Int) {
        sync()
        buffer.backspace(units)
        touch(units)
    }

    fun text(): String {
        sync()
        return buffer.text()
    }

    fun chunks(size: Int, maxRows: Int): List<String> {
        sync()
        return buffer.chunks(size, maxRows)
    }

    fun clear() {
        buffer.clear()
        dirty = false
        pending = 0
        store.edit().remove(KeyboardPrefs.K_MEMORY_TEXT).apply()
    }

    fun flush() {
        if (!dirty) return
        store.edit().putString(KeyboardPrefs.K_MEMORY_TEXT, buffer.text()).apply()
        dirty = false
        pending = 0
    }

    private fun touch(n: Int) {
        dirty = true
        pending += n
        if (pending >= 40) flush()
    }

    companion object {
        const val CAPACITY = 200
    }
}
